# Stage A VCXPROJ Element Inventory v0.1

Generated mechanically from the three supplied project files. No project file was modified.

## Inspector - `Mpeg2BlockInspector.vcxproj`

Element records: **120**

| Line | Element | Context | Attributes | Value |
|---:|---|---|---|---|
| 3 | `ItemGroup` |  | `Label=ProjectConfigurations` | `` |
| 4 | `ProjectConfiguration` | ItemGroup[Label=ProjectConfigurations] | `Include=Debug\|Win32` | `` |
| 5 | `Configuration` | ItemGroup[Label=ProjectConfigurations] | `` | `Debug` |
| 6 | `Platform` | ItemGroup[Label=ProjectConfigurations] | `` | `Win32` |
| 8 | `ProjectConfiguration` | ItemGroup[Label=ProjectConfigurations] | `Include=Release\|Win32` | `` |
| 9 | `Configuration` | ItemGroup[Label=ProjectConfigurations] | `` | `Release` |
| 10 | `Platform` | ItemGroup[Label=ProjectConfigurations] | `` | `Win32` |
| 12 | `ProjectConfiguration` | ItemGroup[Label=ProjectConfigurations] | `Include=Debug\|x64` | `` |
| 13 | `Configuration` | ItemGroup[Label=ProjectConfigurations] | `` | `Debug` |
| 14 | `Platform` | ItemGroup[Label=ProjectConfigurations] | `` | `x64` |
| 16 | `ProjectConfiguration` | ItemGroup[Label=ProjectConfigurations] | `Include=Release\|x64` | `` |
| 17 | `Configuration` | ItemGroup[Label=ProjectConfigurations] | `` | `Release` |
| 18 | `Platform` | ItemGroup[Label=ProjectConfigurations] | `` | `x64` |
| 21 | `PropertyGroup` |  | `Label=Globals` | `` |
| 22 | `VCProjectVersion` | PropertyGroup[Label=Globals] | `` | `18.0` |
| 23 | `ProjectGuid` | PropertyGroup[Label=Globals] | `` | `{F4B1A357-B93C-7AAB-3946-9C7A95523C9B}` |
| 24 | `Keyword` | PropertyGroup[Label=Globals] | `` | `Win32Proj` |
| 26 | `Import` |  | `Project=$(VCTargetsPath)\Microsoft.Cpp.Default.props` | `` |
| 27 | `PropertyGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'; Label=Configuration` | `` |
| 28 | `ConfigurationType` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'] | `` | `Application` |
| 29 | `UseDebugLibraries` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'] | `` | `true` |
| 30 | `PlatformToolset` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'] | `` | `v145` |
| 32 | `PropertyGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'; Label=Configuration` | `` |
| 33 | `ConfigurationType` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] | `` | `Application` |
| 34 | `UseDebugLibraries` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] | `` | `false` |
| 35 | `PlatformToolset` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] | `` | `v145` |
| 37 | `PropertyGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'; Label=Configuration` | `` |
| 38 | `ConfigurationType` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `Application` |
| 39 | `UseDebugLibraries` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `true` |
| 40 | `PlatformToolset` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `v145` |
| 42 | `PropertyGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Release\|x64'; Label=Configuration` | `` |
| 43 | `ConfigurationType` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `Application` |
| 44 | `UseDebugLibraries` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `false` |
| 45 | `PlatformToolset` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `v145` |
| 47 | `Import` |  | `Project=$(VCTargetsPath)\Microsoft.Cpp.props` | `` |
| 48 | `ImportGroup` |  | `Label=ExtensionSettings` | `` |
| 50 | `ImportGroup` |  | `Label=Shared` | `` |
| 52 | `ImportGroup` |  | `Label=PropertySheets; Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'` | `` |
| 53 | `Import` | ImportGroup[Label=PropertySheets][Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'] | `Project=$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props; Condition=exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props'); Label=LocalAppDataPlatform` | `` |
| 55 | `ImportGroup` |  | `Label=PropertySheets; Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'` | `` |
| 56 | `Import` | ImportGroup[Label=PropertySheets][Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] | `Project=$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props; Condition=exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props'); Label=LocalAppDataPlatform` | `` |
| 58 | `ImportGroup` |  | `Label=PropertySheets; Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'` | `` |
| 59 | `Import` | ImportGroup[Label=PropertySheets][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `Project=$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props; Condition=exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props'); Label=LocalAppDataPlatform` | `` |
| 61 | `ImportGroup` |  | `Label=PropertySheets; Condition='$(Configuration)\|$(Platform)'=='Release\|x64'` | `` |
| 62 | `Import` | ImportGroup[Label=PropertySheets][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `Project=$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props; Condition=exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props'); Label=LocalAppDataPlatform` | `` |
| 64 | `PropertyGroup` |  | `Label=UserMacros` | `` |
| 65 | `PropertyGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'` | `` |
| 66 | `LinkIncremental` | PropertyGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'] | `` | `true` |
| 68 | `PropertyGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'` | `` |
| 69 | `LinkIncremental` | PropertyGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `false` |
| 71 | `PropertyGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'` | `` |
| 72 | `LinkIncremental` | PropertyGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] | `` | `true` |
| 74 | `PropertyGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Release\|x64'` | `` |
| 75 | `LinkIncremental` | PropertyGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `false` |
| 77 | `ItemDefinitionGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'` | `` |
| 78 | `Manifest` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'] | `` | `` |
| 79 | `EnableSegmentHeap` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'] / Manifest | `` | `true` |
| 81 | `ClCompile` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'] | `` | `` |
| 82 | `PreprocessorDefinitions` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'] / ClCompile | `` | `WIN32;_DEBUG;_CONSOLE;%(PreprocessorDefinitions)` |
| 83 | `WarningLevel` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'] / ClCompile | `` | `Level3` |
| 85 | `Link` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'] | `` | `` |
| 86 | `GenerateDebugInformation` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'] / Link | `` | `true` |
| 87 | `SubSystem` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|Win32'] / Link | `` | `Console` |
| 90 | `ItemDefinitionGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'` | `` |
| 91 | `Manifest` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] | `` | `` |
| 92 | `EnableSegmentHeap` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] / Manifest | `` | `true` |
| 94 | `ClCompile` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] | `` | `` |
| 95 | `PreprocessorDefinitions` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] / ClCompile | `` | `WIN32;NDEBUG;_CONSOLE;%(PreprocessorDefinitions)` |
| 96 | `WarningLevel` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] / ClCompile | `` | `Level3` |
| 98 | `Link` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] | `` | `` |
| 99 | `GenerateDebugInformation` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] / Link | `` | `true` |
| 100 | `SubSystem` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] / Link | `` | `Console` |
| 101 | `EnableCOMDATFolding` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] / Link | `` | `true` |
| 102 | `OptimizeReferences` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|Win32'] / Link | `` | `true` |
| 105 | `ItemDefinitionGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'` | `` |
| 106 | `Manifest` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `` |
| 107 | `EnableSegmentHeap` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Manifest | `` | `true` |
| 109 | `ClCompile` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `` |
| 110 | `PreprocessorDefinitions` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `_CRT_SECURE_NO_WARNINGS;%(PreprocessorDefinitions)` |
| 111 | `WarningLevel` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `Level3` |
| 112 | `SDLCheck` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `false` |
| 114 | `Link` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `` |
| 115 | `GenerateDebugInformation` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Link | `` | `true` |
| 116 | `SubSystem` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Link | `` | `Console` |
| 119 | `ItemDefinitionGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Release\|x64'` | `` |
| 120 | `Manifest` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `` |
| 121 | `EnableSegmentHeap` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Manifest | `` | `true` |
| 123 | `ClCompile` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `` |
| 124 | `PreprocessorDefinitions` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `_CRT_SECURE_NO_WARNINGS;%(PreprocessorDefinitions)` |
| 125 | `WarningLevel` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `Level3` |
| 126 | `SDLCheck` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `false` |
| 128 | `Link` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `` |
| 129 | `GenerateDebugInformation` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `true` |
| 130 | `SubSystem` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `Console` |
| 131 | `EnableCOMDATFolding` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `true` |
| 132 | `OptimizeReferences` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `true` |
| 135 | `ItemGroup` |  | `` | `` |
| 136 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\display.c` | `` |
| 137 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\getbits.c` | `` |
| 138 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\getblk.c` | `` |
| 139 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\gethdr.c` | `` |
| 140 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\getpic.c` | `` |
| 141 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\getvlc.c` | `` |
| 142 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\idct.c` | `` |
| 143 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\idctref.c` | `` |
| 144 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\motion.c` | `` |
| 145 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\mpeg2dec.c` | `` |
| 146 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\recon.c` | `` |
| 147 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\spatscal.c` | `` |
| 148 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\store.c` | `` |
| 149 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\subspic.c` | `` |
| 150 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\systems.c` | `` |
| 151 | `ClCompile` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\verify.c` | `` |
| 153 | `ItemGroup` |  | `` | `` |
| 154 | `ClInclude` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\config.h` | `` |
| 155 | `ClInclude` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\getvlc.h` | `` |
| 156 | `ClInclude` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\global.h` | `` |
| 157 | `ClInclude` | ItemGroup | `Include=..\..\src\Mpeg2BlockInspector\mpeg2dec.h` | `` |
| 159 | `Import` |  | `Project=$(VCTargetsPath)\Microsoft.Cpp.targets` | `` |
| 160 | `ImportGroup` |  | `Label=ExtensionTargets` | `` |

## CNR3_selftest - `cnr3_cache_core_selftest.vcxproj`

Element records: **107**

| Line | Element | Context | Attributes | Value |
|---:|---|---|---|---|
| 3 | `ItemGroup` |  | `Label=ProjectConfigurations` | `` |
| 4 | `ProjectConfiguration` | ItemGroup[Label=ProjectConfigurations] | `Include=Debug\|x64` | `` |
| 5 | `Configuration` | ItemGroup[Label=ProjectConfigurations] | `` | `Debug` |
| 6 | `Platform` | ItemGroup[Label=ProjectConfigurations] | `` | `x64` |
| 8 | `ProjectConfiguration` | ItemGroup[Label=ProjectConfigurations] | `Include=Release\|x64` | `` |
| 9 | `Configuration` | ItemGroup[Label=ProjectConfigurations] | `` | `Release` |
| 10 | `Platform` | ItemGroup[Label=ProjectConfigurations] | `` | `x64` |
| 13 | `ItemGroup` |  | `` | `` |
| 14 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_cache_core.cpp` | `` |
| 15 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_cache_core_selftest.cpp` | `` |
| 16 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_cache_core_selftest_main.cpp` | `` |
| 17 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_cache_diagnostics.cpp` | `` |
| 18 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_diagnostics.cpp` | `` |
| 19 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_frame_processing.cpp` | `` |
| 20 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_owned_frame_ref.cpp` | `` |
| 21 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_response_tables.cpp` | `` |
| 23 | `ItemGroup` |  | `` | `` |
| 24 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_build_config.h` | `` |
| 25 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_cache_core.h` | `` |
| 26 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_cache_core_selftest.h` | `` |
| 27 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_cache_diagnostics.h` | `` |
| 28 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_common.h` | `` |
| 29 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_diagnostics.h` | `` |
| 30 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_frame_processing.h` | `` |
| 31 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_owned_frame_ref.h` | `` |
| 32 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_plugin_internal.h` | `` |
| 33 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_response_tables.h` | `` |
| 34 | `ClInclude` | ItemGroup | `Include=..\..\third_party\vapoursynth\include\VapourSynth4.h` | `` |
| 35 | `ClInclude` | ItemGroup | `Include=..\..\third_party\vapoursynth\include\VSHelper4.h` | `` |
| 37 | `PropertyGroup` |  | `Label=Globals` | `` |
| 38 | `VCProjectVersion` | PropertyGroup[Label=Globals] | `` | `18.0` |
| 39 | `Keyword` | PropertyGroup[Label=Globals] | `` | `Win32Proj` |
| 40 | `ProjectGuid` | PropertyGroup[Label=Globals] | `` | `{b5dcad45-31bb-48c8-81a3-52d3b6e6b451}` |
| 41 | `RootNamespace` | PropertyGroup[Label=Globals] | `` | `cnr3_cache_core_selftest` |
| 42 | `WindowsTargetPlatformVersion` | PropertyGroup[Label=Globals] | `` | `10.0.28000.0` |
| 44 | `Import` |  | `Project=$(VCTargetsPath)\Microsoft.Cpp.Default.props` | `` |
| 45 | `PropertyGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'; Label=Configuration` | `` |
| 46 | `ConfigurationType` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `Application` |
| 47 | `UseDebugLibraries` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `true` |
| 48 | `PlatformToolset` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `v145` |
| 49 | `CharacterSet` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `Unicode` |
| 50 | `PreferredToolArchitecture` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `x64` |
| 52 | `PropertyGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Release\|x64'; Label=Configuration` | `` |
| 53 | `ConfigurationType` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `Application` |
| 54 | `UseDebugLibraries` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `false` |
| 55 | `PlatformToolset` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `v145` |
| 56 | `WholeProgramOptimization` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `true` |
| 57 | `CharacterSet` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `Unicode` |
| 58 | `PreferredToolArchitecture` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `x64` |
| 60 | `Import` |  | `Project=$(VCTargetsPath)\Microsoft.Cpp.props` | `` |
| 61 | `ImportGroup` |  | `Label=ExtensionSettings` | `` |
| 63 | `ImportGroup` |  | `Label=Shared` | `` |
| 65 | `ImportGroup` |  | `Label=PropertySheets; Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'` | `` |
| 66 | `Import` | ImportGroup[Label=PropertySheets][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `Project=$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props; Condition=exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props'); Label=LocalAppDataPlatform` | `` |
| 68 | `ImportGroup` |  | `Label=PropertySheets; Condition='$(Configuration)\|$(Platform)'=='Release\|x64'` | `` |
| 69 | `Import` | ImportGroup[Label=PropertySheets][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `Project=$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props; Condition=exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props'); Label=LocalAppDataPlatform` | `` |
| 71 | `PropertyGroup` |  | `Label=UserMacros` | `` |
| 72 | `ItemDefinitionGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'` | `` |
| 73 | `ClCompile` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `` |
| 74 | `WarningLevel` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `Level3` |
| 75 | `SDLCheck` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `true` |
| 76 | `PreprocessorDefinitions` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `NOMINMAX;_DEBUG;CNR3_SELFTEST_CONSOLE;_CONSOLE;%(PreprocessorDefinitions)` |
| 77 | `ConformanceMode` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `true` |
| 78 | `LanguageStandard` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `stdcpp20` |
| 79 | `PrecompiledHeader` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `NotUsing` |
| 80 | `AdditionalIncludeDirectories` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `$(SolutionDir)..\..\third_party\vapoursynth\include;%(AdditionalIncludeDirectories)` |
| 81 | `FavorSizeOrSpeed` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `Speed` |
| 82 | `Optimization` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `Disabled` |
| 83 | `EnableEnhancedInstructionSet` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `AdvancedVectorExtensions2` |
| 84 | `InlineFunctionExpansion` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `AnySuitable` |
| 85 | `IntrinsicFunctions` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `true` |
| 86 | `WholeProgramOptimization` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `false` |
| 87 | `DebugInformationFormat` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `ProgramDatabase` |
| 89 | `Link` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `` |
| 90 | `SubSystem` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Link | `` | `Console` |
| 91 | `GenerateDebugInformation` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Link | `` | `true` |
| 92 | `EnableUAC` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Link | `` | `false` |
| 93 | `OutputFile` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Link | `` | `$(OutDir)cnr3_cache_core_selftest.exe` |
| 94 | `LinkTimeCodeGeneration` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Link | `` | `Default` |
| 96 | `Manifest` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `` |
| 97 | `EnableSegmentHeap` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Manifest | `` | `true` |
| 100 | `ItemDefinitionGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Release\|x64'` | `` |
| 101 | `ClCompile` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `` |
| 102 | `WarningLevel` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `Level3` |
| 103 | `IntrinsicFunctions` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `true` |
| 104 | `SDLCheck` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `true` |
| 105 | `PreprocessorDefinitions` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `NOMINMAX;NDEBUG;CNR3_SELFTEST_CONSOLE;_CONSOLE;%(PreprocessorDefinitions)` |
| 106 | `ConformanceMode` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `true` |
| 107 | `LanguageStandard` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `stdcpp20` |
| 108 | `PrecompiledHeader` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `NotUsing` |
| 109 | `AdditionalIncludeDirectories` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `$(SolutionDir)..\..\third_party\vapoursynth\include;%(AdditionalIncludeDirectories)` |
| 110 | `FavorSizeOrSpeed` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `Speed` |
| 111 | `Optimization` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `MaxSpeed` |
| 112 | `EnableEnhancedInstructionSet` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `AdvancedVectorExtensions2` |
| 113 | `InlineFunctionExpansion` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `AnySuitable` |
| 114 | `WholeProgramOptimization` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `true` |
| 115 | `DebugInformationFormat` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `ProgramDatabase` |
| 117 | `Link` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `` |
| 118 | `SubSystem` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `Console` |
| 119 | `GenerateDebugInformation` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `true` |
| 120 | `EnableUAC` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `false` |
| 121 | `OutputFile` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `$(OutDir)cnr3_cache_core_selftest.exe` |
| 122 | `LinkTimeCodeGeneration` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `UseLinkTimeCodeGeneration` |
| 124 | `Manifest` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `` |
| 125 | `EnableSegmentHeap` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Manifest | `` | `true` |
| 128 | `Import` |  | `Project=$(VCTargetsPath)\Microsoft.Cpp.targets` | `` |
| 129 | `ImportGroup` |  | `Label=ExtensionTargets` | `` |

## CNR3_DLL - `cnr3.vcxproj`

Element records: **116**

| Line | Element | Context | Attributes | Value |
|---:|---|---|---|---|
| 3 | `ItemGroup` |  | `Label=ProjectConfigurations` | `` |
| 4 | `ProjectConfiguration` | ItemGroup[Label=ProjectConfigurations] | `Include=Debug\|x64` | `` |
| 5 | `Configuration` | ItemGroup[Label=ProjectConfigurations] | `` | `Debug` |
| 6 | `Platform` | ItemGroup[Label=ProjectConfigurations] | `` | `x64` |
| 8 | `ProjectConfiguration` | ItemGroup[Label=ProjectConfigurations] | `Include=Release\|x64` | `` |
| 9 | `Configuration` | ItemGroup[Label=ProjectConfigurations] | `` | `Release` |
| 10 | `Platform` | ItemGroup[Label=ProjectConfigurations] | `` | `x64` |
| 13 | `ItemGroup` |  | `` | `` |
| 14 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_arAllFramesReady.cpp` | `` |
| 15 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_arInitial.cpp` | `` |
| 16 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_cache_core.cpp` | `` |
| 17 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_cache_core_selftest.cpp` | `` |
| 18 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_cache_diagnostics.cpp` | `` |
| 19 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_diagnostics.cpp` | `` |
| 20 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_frame_processing.cpp` | `` |
| 21 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_instance_config.cpp` | `` |
| 22 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_memory_diagnostics.cpp` | `` |
| 23 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_owned_frame_ref.cpp` | `` |
| 24 | `ClCompile` | ItemGroup | `Include=..\..\src\cnr3_response_tables.cpp` | `` |
| 25 | `ClCompile` | ItemGroup | `Include=..\..\src\vapoursynth-Cnr3.cpp` | `` |
| 26 | `ExcludedFromBuild` | ItemGroup / ClCompile | `Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'` | `false` |
| 27 | `ExcludedFromBuild` | ItemGroup / ClCompile | `Condition='$(Configuration)\|$(Platform)'=='Release\|x64'` | `false` |
| 30 | `ItemGroup` |  | `` | `` |
| 31 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_build_config.h` | `` |
| 32 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_cache_core.h` | `` |
| 33 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_cache_core_selftest.h` | `` |
| 34 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_cache_diagnostics.h` | `` |
| 35 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_common.h` | `` |
| 36 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_diagnostics.h` | `` |
| 37 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_frame_processing.h` | `` |
| 38 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_instance_config.h` | `` |
| 39 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_memory_diagnostics.h` | `` |
| 40 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_owned_frame_ref.h` | `` |
| 41 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_plugin_internal.h` | `` |
| 42 | `ClInclude` | ItemGroup | `Include=..\..\src\cnr3_response_tables.h` | `` |
| 43 | `ClInclude` | ItemGroup | `Include=..\..\third_party\vapoursynth\include\VapourSynth4.h` | `` |
| 44 | `ClInclude` | ItemGroup | `Include=..\..\third_party\vapoursynth\include\VSHelper4.h` | `` |
| 46 | `PropertyGroup` |  | `Label=Globals` | `` |
| 47 | `VCProjectVersion` | PropertyGroup[Label=Globals] | `` | `18.0` |
| 48 | `Keyword` | PropertyGroup[Label=Globals] | `` | `Win32Proj` |
| 49 | `ProjectGuid` | PropertyGroup[Label=Globals] | `` | `{c127294b-e66d-4272-8ba0-e4eb4ba169d6}` |
| 50 | `RootNamespace` | PropertyGroup[Label=Globals] | `` | `cnr3` |
| 51 | `WindowsTargetPlatformVersion` | PropertyGroup[Label=Globals] | `` | `10.0.28000.0` |
| 53 | `Import` |  | `Project=$(VCTargetsPath)\Microsoft.Cpp.Default.props` | `` |
| 54 | `PropertyGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'; Label=Configuration` | `` |
| 55 | `ConfigurationType` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `DynamicLibrary` |
| 56 | `UseDebugLibraries` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `true` |
| 57 | `PlatformToolset` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `v145` |
| 58 | `CharacterSet` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `Unicode` |
| 59 | `PreferredToolArchitecture` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `x64` |
| 61 | `PropertyGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Release\|x64'; Label=Configuration` | `` |
| 62 | `ConfigurationType` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `DynamicLibrary` |
| 63 | `UseDebugLibraries` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `false` |
| 64 | `PlatformToolset` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `v145` |
| 65 | `WholeProgramOptimization` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `true` |
| 66 | `CharacterSet` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `Unicode` |
| 67 | `PreferredToolArchitecture` | PropertyGroup[Label=Configuration][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `x64` |
| 69 | `Import` |  | `Project=$(VCTargetsPath)\Microsoft.Cpp.props` | `` |
| 70 | `ImportGroup` |  | `Label=ExtensionSettings` | `` |
| 72 | `ImportGroup` |  | `Label=Shared` | `` |
| 74 | `ImportGroup` |  | `Label=PropertySheets; Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'` | `` |
| 75 | `Import` | ImportGroup[Label=PropertySheets][Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `Project=$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props; Condition=exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props'); Label=LocalAppDataPlatform` | `` |
| 77 | `ImportGroup` |  | `Label=PropertySheets; Condition='$(Configuration)\|$(Platform)'=='Release\|x64'` | `` |
| 78 | `Import` | ImportGroup[Label=PropertySheets][Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `Project=$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props; Condition=exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props'); Label=LocalAppDataPlatform` | `` |
| 80 | `PropertyGroup` |  | `Label=UserMacros` | `` |
| 81 | `ItemDefinitionGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'` | `` |
| 82 | `ClCompile` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `` |
| 83 | `WarningLevel` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `Level3` |
| 84 | `SDLCheck` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `true` |
| 85 | `PreprocessorDefinitions` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `NOMINMAX;_DEBUG;CNR3_EXPORTS;_WINDOWS;_USRDLL;%(PreprocessorDefinitions)` |
| 86 | `ConformanceMode` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `true` |
| 87 | `LanguageStandard` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `stdcpp20` |
| 88 | `PrecompiledHeader` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `NotUsing` |
| 89 | `AdditionalIncludeDirectories` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `$(SolutionDir)..\..\third_party\vapoursynth\include;%(AdditionalIncludeDirectories)` |
| 90 | `FavorSizeOrSpeed` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `Speed` |
| 91 | `Optimization` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `Disabled` |
| 92 | `EnableEnhancedInstructionSet` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `AdvancedVectorExtensions2` |
| 93 | `InlineFunctionExpansion` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `AnySuitable` |
| 94 | `IntrinsicFunctions` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `true` |
| 95 | `WholeProgramOptimization` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `false` |
| 96 | `DebugInformationFormat` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / ClCompile | `` | `ProgramDatabase` |
| 98 | `Link` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `` |
| 99 | `SubSystem` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Link | `` | `Windows` |
| 100 | `GenerateDebugInformation` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Link | `` | `true` |
| 101 | `EnableUAC` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Link | `` | `false` |
| 102 | `OutputFile` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Link | `` | `$(OutDir)cnr3.dll` |
| 103 | `LinkTimeCodeGeneration` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Link | `` | `Default` |
| 105 | `Manifest` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] | `` | `` |
| 106 | `EnableSegmentHeap` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Debug\|x64'] / Manifest | `` | `true` |
| 109 | `ItemDefinitionGroup` |  | `Condition='$(Configuration)\|$(Platform)'=='Release\|x64'` | `` |
| 110 | `ClCompile` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `` |
| 111 | `WarningLevel` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `Level3` |
| 112 | `IntrinsicFunctions` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `true` |
| 113 | `SDLCheck` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `true` |
| 114 | `PreprocessorDefinitions` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `NOMINMAX;NDEBUG;CNR3_EXPORTS;_WINDOWS;_USRDLL;%(PreprocessorDefinitions)` |
| 115 | `ConformanceMode` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `true` |
| 116 | `LanguageStandard` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `stdcpp20` |
| 117 | `PrecompiledHeader` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `NotUsing` |
| 118 | `AdditionalIncludeDirectories` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `$(SolutionDir)..\..\third_party\vapoursynth\include;%(AdditionalIncludeDirectories)` |
| 119 | `FavorSizeOrSpeed` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `Speed` |
| 120 | `Optimization` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `MaxSpeed` |
| 121 | `EnableEnhancedInstructionSet` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `AdvancedVectorExtensions2` |
| 122 | `InlineFunctionExpansion` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `AnySuitable` |
| 123 | `WholeProgramOptimization` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `true` |
| 124 | `DebugInformationFormat` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / ClCompile | `` | `ProgramDatabase` |
| 126 | `Link` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `` |
| 127 | `SubSystem` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `Windows` |
| 128 | `GenerateDebugInformation` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `true` |
| 129 | `EnableUAC` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `false` |
| 130 | `OutputFile` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `$(OutDir)cnr3.dll` |
| 131 | `LinkTimeCodeGeneration` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `UseLinkTimeCodeGeneration` |
| 132 | `EnableCOMDATFolding` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Link | `` | `false` |
| 134 | `Manifest` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] | `` | `` |
| 135 | `EnableSegmentHeap` | ItemDefinitionGroup[Condition='$(Configuration)\|$(Platform)'=='Release\|x64'] / Manifest | `` | `true` |
| 138 | `Import` |  | `Project=$(VCTargetsPath)\Microsoft.Cpp.targets` | `` |
| 139 | `ImportGroup` |  | `Label=ExtensionTargets` | `` |

