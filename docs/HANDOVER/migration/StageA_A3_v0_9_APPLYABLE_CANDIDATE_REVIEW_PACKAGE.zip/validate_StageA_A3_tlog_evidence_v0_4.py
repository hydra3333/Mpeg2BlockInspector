#!/usr/bin/env python3
import argparse
import csv

LIBS = (
    "LIBS=kernel32.lib;user32.lib;gdi32.lib;winspool.lib;comdlg32.lib;"
    "advapi32.lib;shell32.lib;ole32.lib;oleaut32.lib;uuid.lib;odbc32.lib;odbccp32.lib"
)

def die(msg):
    print("FAIL:", msg)
    raise SystemExit(1)

ap = argparse.ArgumentParser()
ap.add_argument("--tokens", default="StageA_A3_checkpoint_tokens_generated_v0_4.csv")
args = ap.parse_args()

try:
    rows = list(csv.DictReader(open(args.tokens, newline="", encoding="utf-8")))
except FileNotFoundError:
    die("tlog-derived token CSV missing")

for cfg in ("Debug|x64", "Release|x64"):
    ts = [r["token"] for r in rows if r["configuration"] == cfg and r["tool"] == "LINK"]
    if LIBS not in ts:
        die(f"default library list absent from measured {cfg} LINK tokens")

for cfg, tool in (
    ("Debug|x64", "CL"),
    ("Release|x64", "CL"),
    ("Debug|x64", "LINK"),
    ("Release|x64", "LINK"),
):
    n = sum(1 for r in rows if r["configuration"] == cfg and r["tool"] == tool)
    if not n:
        die(f"no measured tokens for {cfg} {tool}")

print(
    f"PASS: measured token evidence present ({len(rows)} tokens), "
    "including default library lists."
)
print(
    "NOTE: final candidate generator must map every measured token exactly once "
    "to pin-table coverage."
)
