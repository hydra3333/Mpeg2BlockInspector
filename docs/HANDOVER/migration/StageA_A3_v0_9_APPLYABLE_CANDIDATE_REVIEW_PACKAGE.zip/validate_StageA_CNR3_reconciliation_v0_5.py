#!/usr/bin/env python3
import csv, sys
from collections import Counter

REC='StageA_CNR3_113_row_reconciliation_v0_5.csv'
SRC='StageA_CNR3_113_row_source_reference_v0_1.csv'
KEY=('project','source_line','configuration','tool_group','setting')
VOCAB={
'REUSE UNCHANGED','REUSE WITH NAME/PATH ADJUSTMENT','NOT APPLICABLE TO THIS PROJECT',
'DELIBERATELY DIFFERENT','DEFAULT IN CNR3 - LEAVE AT DEFAULT',
'USER/MACHINE-LOCAL - RECORD BUT DO NOT COPY','PROVISIONAL - TECHNICAL DEVELOPMENT DECISION NOT YET FINAL'}

def load(p):
    with open(p,newline='',encoding='ascii') as f: return list(csv.DictReader(f))
def key(r): return tuple(r[k] for k in KEY)
def die(msg): print('FAIL:',msg); raise SystemExit(1)
R=load(REC); S=load(SRC)
if len(R)!=113: die(f'reconciliation rows={len(R)}, expected 113')
if len(S)!=113: die(f'source rows={len(S)}, expected 113')
for name,rows in [('reconciliation',R),('source',S)]:
    ks=[key(x) for x in rows]
    dup=[k for k,n in Counter(ks).items() if n>1]
    if dup: die(f'{name} duplicate keys: {dup[:3]}')
counts=Counter(r['project'] for r in R)
if counts!={'CNR3_selftest':56,'CNR3_DLL':57}: die(f'project counts={dict(counts)}')
SM={key(r):r for r in S}
for r in R:
    k=key(r)
    if k not in SM: die(f'key absent from source: {k}')
    if r['cnr3_value']!=SM[k]['cnr3_value']: die(f'cnr3 value mismatch {k}: {r["cnr3_value"]!r} != {SM[k]["cnr3_value"]!r}')
    if r['disposition'] not in VOCAB: die(f'bad disposition {k}: {r["disposition"]!r}')
    if not r['inspector_v0_4_target_value'].strip(): die(f'blank target {k}')
    if not r['reason'].strip(): die(f'blank reason {k}')
if set(SM)!=set(key(r) for r in R): die('source/reconciliation key sets differ')
print('PASS: 113 rows; 56 self-test + 57 DLL; no duplicates; source-reference key/value match; vocabulary/target/reason complete.')
