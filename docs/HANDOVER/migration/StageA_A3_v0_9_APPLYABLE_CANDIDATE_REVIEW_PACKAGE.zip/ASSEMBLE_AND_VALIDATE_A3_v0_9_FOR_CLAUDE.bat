@echo off
setlocal
cd /d "%~dp0"
python assemble_and_validate_A3_v0_9_for_Claude.py
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
  echo FAIL: A3 v0.9 local assembly/validation failed with RC=%RC%.
  exit /b %RC%
)
echo PASS: A3 v0.9 local assembly/validation completed.
exit /b 0
