#!/usr/bin/env python3
import argparse, csv, re
from pathlib import Path
import xml.etree.ElementTree as ET

def local(tag):
    return tag.rsplit("}", 1)[-1]

def toolset_folder(path):
    for part in path.parts:
        if re.fullmatch(r"v\d{3}", part, re.I):
            return part.lower()
    return ""

def datasource_children(owner):
    """
    Visual Studio rule XAML normally nests DataSource under wrapper elements:
      <Rule.DataSource><DataSource .../></Rule.DataSource>
      <BoolProperty.DataSource><DataSource .../></BoolProperty.DataSource>
    Return only DataSource elements owned by this Rule/property, not arbitrary
    deeper descendants belonging to nested properties.
    """
    found = []
    for child in owner:
        lname = local(child.tag)
        if lname == "DataSource":
            found.append(child)
            continue
        if lname.endswith(".DataSource"):
            for gc in child:
                if local(gc.tag) == "DataSource":
                    found.append(gc)
    return found

def ds_record(ds):
    a = ds.attrib
    persistence = a.get("Persistence", "")
    item_type = a.get("ItemType", "")
    label = a.get("Label", "")
    has_cfg = a.get("HasConfigurationCondition", "")
    source_type = a.get("SourceType", "")

    if item_type:
        placement = f"ItemDefinitionGroup/{item_type}"
    elif label:
        placement = f"PropertyGroup[{label}]"
    elif persistence == "ProjectFile":
        placement = "PropertyGroup"
    elif persistence:
        placement = f"Persistence[{persistence}]"
    else:
        placement = "UNSPECIFIED"

    return {
        "persistence": persistence,
        "item_type": item_type,
        "label": label,
        "has_configuration_condition": has_cfg,
        "source_type": source_type,
        "placement": placement,
    }

ap = argparse.ArgumentParser(
    description="Scan installed VS/MSBuild C++ rule XML with exact toolset, rule, value and DataSource placement evidence."
)
ap.add_argument("--vs-install", required=True)
ap.add_argument("--out", default="StageA_A3_VS_rule_properties_generated_v0_3.csv")
args = ap.parse_args()

root = Path(args.vs_install) / "MSBuild" / "Microsoft" / "VC"
if not root.is_dir():
    raise SystemExit(f"FAIL: VC MSBuild rule root not found: {root}")

rows = []
for path in root.rglob("*.xml"):
    try:
        tree = ET.parse(path)
    except Exception:
        continue

    rr = tree.getroot()
    if local(rr.tag) != "Rule":
        continue

    rule_name = rr.attrib.get("Name", "")
    rule_ds_elems = datasource_children(rr)
    rule_ds = [ds_record(x) for x in rule_ds_elems]

    for prop in rr:
        ptype = local(prop.tag)
        if not ptype.endswith("Property") or "Name" not in prop.attrib:
            continue

        enum_values = []
        for child in prop:
            if local(child.tag) == "EnumValue" and child.attrib.get("Name"):
                enum_values.append(child.attrib["Name"])

        prop_ds_elems = datasource_children(prop)
        prop_ds = [ds_record(x) for x in prop_ds_elems]

        inherited = False
        if prop_ds:
            effective = prop_ds
        elif rule_ds:
            effective = rule_ds
            inherited = True
        else:
            effective = [{
                "persistence": "",
                "item_type": "",
                "label": "",
                "has_configuration_condition": "",
                "source_type": "",
                "placement": "UNSPECIFIED",
            }]

        for ds in effective:
            rows.append({
                "toolset_folder": toolset_folder(path),
                "rule_file": str(path),
                "rule_name": rule_name,
                "property_type": ptype,
                "property_name": prop.attrib["Name"],
                "enum_values": ";".join(enum_values),
                "switch": prop.attrib.get("Switch", ""),
                "reverse_switch": prop.attrib.get("ReverseSwitch", ""),
                "datasource_scope": "rule-inherited" if inherited else ("property" if prop_ds else "none"),
                "persistence": ds["persistence"],
                "item_type": ds["item_type"],
                "label": ds["label"],
                "has_configuration_condition": ds["has_configuration_condition"],
                "source_type": ds["source_type"],
                "placement": ds["placement"],
            })

if not rows:
    raise SystemExit("FAIL: no property definitions found in rule XML")

fields = [
    "toolset_folder", "rule_file", "rule_name", "property_type", "property_name",
    "enum_values", "switch", "reverse_switch", "datasource_scope",
    "persistence", "item_type", "label", "has_configuration_condition",
    "source_type", "placement"
]

with open(args.out, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=fields, lineterminator="\r\n")
    w.writeheader()
    w.writerows(rows)

by_toolset = {}
unspec = {}
for r in rows:
    t = r["toolset_folder"]
    by_toolset[t] = by_toolset.get(t, 0) + 1
    if r["placement"] == "UNSPECIFIED":
        unspec[t] = unspec.get(t, 0) + 1

counts = ", ".join(f"{k or '<none>'}={v}" for k, v in sorted(by_toolset.items()))
ucounts = ", ".join(f"{k or '<none>'}={v}" for k, v in sorted(unspec.items())) or "none"
print(f"PASS: wrote {len(rows)} recognized property/DataSource definitions from {root} to {args.out}")
print(f"Toolset-folder counts: {counts}")
print(f"UNSPECIFIED placement counts: {ucounts}")
