# Stage A A3 v0.9 - APPLYABLE CANDIDATE REVIEW PACKAGE

**DO NOT APPLY YET.**

Current published repository baseline observed after the VapourSynth-header commit:

```text
34e8a46 Add vapoursynth include files ready for use with DLL building
```

That commit does not alter the Stage A inspector project. The A3 project comparison therefore remains against the frozen A1 x64-only project baseline.

## Candidate

```text
Mpeg2BlockInspector_A3_APPLYABLE_CANDIDATE_v0_9.vcxproj
SHA-256 ebfcde82405fd2dc25aa7a14a160f89375465d545927b3e4583e7a40fd1af668
```

A1 project baseline:

```text
SHA-256 87acd9ad1c94e5545f84fe57857c076781ca499523d2a80545919ae571dc7a57
```

## Difference from Claude-reviewed v0.8

The project-file diff is intentionally only:

```text
remove Debug Link/ManifestInput
remove Release Link/ManifestInput
```

`Manifest/EnableSegmentHeap=true` remains in both configurations and is now the single owner of the segment-heap manifest input.

Pin rows `LD_maninput` and `LR_maninput` are re-pointed to that Manifest setting.

The predicted delta also carries Claude U2:

```text
Debug CL: /Gy- /GF-
Debug LINK: /OPT:NOREF /OPT:NOICF /LARGEADDRESSAWARE /TSAWARE
Release LINK: /LARGEADDRESSAWARE /TSAWARE
```

and documents explicitly pinned default enum values expected to emit no switch.

## Local evidence required

ChatGPT does not recreate Dave's three machine-generated evidence files:

```text
StageA_A3_VS_rule_properties_generated_v0_3.csv
StageA_A3_checkpoint_tokens_generated_v0_4.csv
StageA_A3_tlog_pin_reconciliation_generated_v0_1.csv
```

Extract this package as a sibling under the existing `A3_v0_7_PRE_CANDIDATE` tree, then run:

```text
ASSEMBLE_AND_VALIDATE_A3_v0_9_FOR_CLAUDE.bat
```

The assembler:

1. verifies the candidate/A1 hashes;
2. finds/copies those three unchanged local evidence files;
3. reruns candidate structure, pin-table, CNR3, strict v180 XML recognition, tlog evidence and tlog-pin reconciliation validators;
4. verifies the regenerated 86-row reconciliation is byte-identical to the previous local evidence;
5. writes `PACKAGE_SHA256_READY.txt`;
6. creates `StageA_A3_v0_9_READY_FOR_CLAUDE.zip`.

No production repository file is changed.

Send that exact READY ZIP to Claude for the requested short v0.9-vs-v0.8 review. Only after Claude accepts the exact candidate and Dave ratifies the exact SHA may A3 be copied into the production project and the full Stage A gate run.
