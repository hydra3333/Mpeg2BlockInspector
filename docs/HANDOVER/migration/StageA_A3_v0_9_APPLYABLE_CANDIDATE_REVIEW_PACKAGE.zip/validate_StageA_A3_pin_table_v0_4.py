#!/usr/bin/env python3
import argparse,csv
REQ=['key','source','configuration','item','checkpoint_value','a3_value','coverage_kind','xml_or_exception','evidence_source','notes']
KINDS={'XML','ADDITIONAL_OPTIONS','DELIBERATE_CHANGE','DELIBERATE_EXCEPTION','TOOL_SEMANTIC'}
def die(m): print('FAIL:',m); raise SystemExit(1)
a=argparse.ArgumentParser()
a.add_argument('--pin-table',default='StageA_A3_pin_table_v0_8.csv')
x=a.parse_args()
with open(x.pin_table,newline='',encoding='ascii') as f:
    rr=csv.DictReader(f); rows=list(rr)
    if rr.fieldnames!=REQ: die(f'columns={rr.fieldnames!r}')
keys=[r['key'] for r in rows]
if len(keys)!=len(set(keys)): die('duplicate pin-table keys')
for r in rows:
    for c in REQ[:-1]:
        if not r[c].strip(): die(f'blank {c} for {r["key"]}')
    if r['coverage_kind'] not in KINDS: die(f'bad coverage_kind {r["key"]}: {r["coverage_kind"]}')
print(f'PASS: {len(rows)} structural pin rows; no duplicate keys/blanks; no pending coverage kinds.')
