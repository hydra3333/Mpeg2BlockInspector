#!/usr/bin/env python3
import argparse, csv, re
from collections import defaultdict

def fail(msg):
    print("FAIL:", msg)
    raise SystemExit(1)

def canon_measured(tool, token):
    t = token.strip()
    lo = t.lower()

    if tool == "CL":
        if lo.startswith("/d "):
            return "/d " + t[3:].strip().lower()
        if lo.startswith("/fo<path>"):
            return "/fo<path>"
        if lo.startswith("/fd<path>"):
            return "/fd<path>"
        return lo

    if tool == "LINK":
        if lo.startswith("libs="):
            libs = [x.strip().lower() for x in t[5:].split(";") if x.strip()]
            return "libs=" + ";".join(libs)
        if lo.startswith("/manifestuac:"):
            # Normalize the measured semantic content rather than quote style.
            if "asInvoker".lower() not in lo or "uiaccess='false'" not in lo:
                # Some command-line renderings omit single quotes around false.
                if "asInvoker".lower() not in lo or "uiaccess=false" not in lo:
                    return lo
            return "/manifestuac:asinvoker:uiaccess=false"
        for pfx in ("/out:<path>", "/pdb:<path>", "/implib:<path>", "/manifestinput:<path>"):
            if lo.startswith(pfx):
                return pfx
        return lo

    return lo

def canon_pin_item(tool, item):
    s = item.strip()
    lo = s.lower()

    if tool == "CL":
        if lo == "/fo...":
            return "/fo<path>"
        if lo == "/fd...":
            return "/fd<path>"
        if lo.startswith("/d "):
            return "/d " + s[3:].strip().lower()
        return lo

    if tool == "LINK":
        if lo.startswith("kernel32.lib "):
            libs = [x.lower() for x in s.split()]
            return "libs=" + ";".join(libs)
        if lo == "/out:...":
            return "/out:<path>"
        if lo == "/pdb:...":
            return "/pdb:<path>"
        if lo == "/implib:...":
            return "/implib:<path>"
        if lo.startswith("/manifestinput:..."):
            return "/manifestinput:<path>"
        if lo.startswith("/manifestuac "):
            return "/manifestuac:asinvoker:uiaccess=false"
        return lo

    return lo

ap = argparse.ArgumentParser(
    description=(
        "Mechanically reconcile tlog-derived checkpoint CL/LINK tokens against "
        "the Stage A A3 pin table. Every measured token must map exactly once."
    )
)
ap.add_argument("--tokens", default="StageA_A3_checkpoint_tokens_generated_v0_4.csv")
ap.add_argument("--pin-table", default="StageA_A3_pin_table_v0_6.csv")
ap.add_argument("--out", default="StageA_A3_tlog_pin_reconciliation_generated_v0_1.csv")
args = ap.parse_args()

tokens = list(csv.DictReader(open(args.tokens, newline="", encoding="utf-8")))
pins = list(csv.DictReader(open(args.pin_table, newline="", encoding="ascii")))

checkpoint_pins = [
    r for r in pins if r["source"] in ("checkpoint CL", "checkpoint LINK")
]

pin_index = defaultdict(list)
for r in checkpoint_pins:
    tool = "CL" if r["source"] == "checkpoint CL" else "LINK"
    key = (r["configuration"], tool, canon_pin_item(tool, r["item"]))
    pin_index[key].append(r)

recon = []
matched_pin_keys = set()
errors = []

for tr in tokens:
    cfg = tr["configuration"]
    tool = tr["tool"]
    token = tr["token"]
    c = canon_measured(tool, token)
    candidates = pin_index.get((cfg, tool, c), [])

    if len(candidates) != 1:
        errors.append(
            f"measured token maps to {len(candidates)} pin rows: "
            f"{cfg} {tool} {token!r} -> {c!r}; "
            f"candidates={[r['key'] for r in candidates]}"
        )
        continue

    r = candidates[0]
    if r["key"] in matched_pin_keys:
        errors.append(
            f"pin row {r['key']} matched more than one measured token"
        )
        continue

    matched_pin_keys.add(r["key"])
    recon.append({
        "configuration": cfg,
        "tool": tool,
        "ordinal": tr["ordinal"],
        "measured_token": token,
        "canonical_token": c,
        "pin_key": r["key"],
        "pin_item": r["item"],
        "coverage_kind": r["coverage_kind"],
        "evidence_class": "native_tlog",
    })

# All checkpoint rows not matched by tlog must be explicitly classified as
# detailed-log-only evidence. For this checkpoint, those are the MSBuild
# error-reporting switches omitted from native command tlogs.
unmatched = [r for r in checkpoint_pins if r["key"] not in matched_pin_keys]
for r in unmatched:
    ev = r["evidence_source"].lower()
    if "detailed msbuild log" not in ev or "native .command.1.tlog omits" not in ev:
        errors.append(
            f"checkpoint pin row not covered by native tlog and not explicitly "
            f"classified detailed-log-only: {r['key']} {r['item']}"
        )
        continue
    if "errorreport" not in r["item"].lower():
        errors.append(
            f"unexpected detailed-log-only checkpoint row: {r['key']} {r['item']}"
        )
        continue

    tool = "CL" if r["source"] == "checkpoint CL" else "LINK"
    recon.append({
        "configuration": r["configuration"],
        "tool": tool,
        "ordinal": "",
        "measured_token": "",
        "canonical_token": canon_pin_item(tool, r["item"]),
        "pin_key": r["key"],
        "pin_item": r["item"],
        "coverage_kind": r["coverage_kind"],
        "evidence_class": "detailed_msbuild_log_only",
    })

# Require the exact expected accounting for this preserved checkpoint:
# 82 native-tlog tokens + 4 detailed-log-only error-reporting pins = 86 rows.
native_count = sum(1 for r in recon if r["evidence_class"] == "native_tlog")
supp_count = sum(1 for r in recon if r["evidence_class"] == "detailed_msbuild_log_only")

if native_count != len(tokens):
    errors.append(
        f"native reconciliation count {native_count} != measured token count {len(tokens)}"
    )
if supp_count != 4:
    errors.append(
        f"expected exactly 4 detailed-log-only error-reporting rows, found {supp_count}"
    )
if len(checkpoint_pins) != native_count + supp_count:
    errors.append(
        f"checkpoint pin accounting mismatch: {len(checkpoint_pins)} pin rows vs "
        f"{native_count}+{supp_count} reconciled rows"
    )

if errors:
    for e in errors:
        print("UNRESOLVED:", e)
    fail(f"{len(errors)} tlog/pin reconciliation issue(s)")

fields = [
    "configuration", "tool", "ordinal", "measured_token", "canonical_token",
    "pin_key", "pin_item", "coverage_kind", "evidence_class",
]
with open(args.out, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=fields, lineterminator="\r\n")
    w.writeheader()
    w.writerows(recon)

print(
    f"PASS: {native_count} native-tlog tokens map exactly once to {native_count} pin rows."
)
print(
    f"PASS: {supp_count} additional checkpoint pins are explicitly classified "
    "as detailed-MSBuild-log-only error-reporting evidence."
)
print(
    f"PASS: all {len(checkpoint_pins)} checkpoint CL/LINK pin rows are accounted for exactly once."
)
print(f"PASS: wrote reconciliation evidence to {args.out}")
