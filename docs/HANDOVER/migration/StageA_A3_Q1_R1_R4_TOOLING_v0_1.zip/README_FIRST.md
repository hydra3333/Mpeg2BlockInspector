# Stage A A3 Q1 R1/R4 local tooling v0.1

This is an evidence-tooling update only. It is NOT an applyable A3 candidate.

It responds to:
`Claude_REVIEW_OF_StageA_A3_S13_Q1_Local_Evidence_v0_1.md`

## R1 changes

The scanner now records:
- toolset folder (`v180`, `v170`, etc.);
- rule/tool name;
- property type and enum values;
- switch/reverse switch;
- resolved DataSource evidence:
  - Persistence;
  - ItemType;
  - Label;
  - placement.

The strict validator requires:
- `v180` only;
- correct rule/tool;
- exact property name;
- enum/bool value validity;
- correct MSBuild placement.

The pin table draft also corrects:
- LINK `/ERRORREPORT:QUEUE`:
  `Link/LinkErrorReporting=QueueForNextLogin`;
- Spectre Disabled:
  `Configuration/SpectreMitigation=false`, subject to strict DataSource placement proof;
- CFG/CET/Zc:inline/manifest mappings already established by local evidence;
- R2 Full PDB:
  `Link/GenerateDebugInformation=DebugFull`;
- R3 High Entropy VA:
  explicit `/HIGHENTROPYVA` through `AdditionalOptions`, never an invented `HighEntropyVA` XML element.

## Still intentionally pending

`CLD_fd` and `CLR_fd` remain `S13_PENDING` until the exact compiler `/Fd`
project value is captured/confirmed.

The tlog-derived expected-key evidence (R4) is also still required before a
final applyable A3 candidate can be generated.

## Run in ordinary cmd.exe

From the A3 pre-candidate working directory, copy these three files into that
directory, then run:

`python scan_VS2026_rule_properties_v0_2.py --vs-install "C:\Program Files\Microsoft Visual Studio\18\Community"`

Then:

`python validate_StageA_A3_xml_recognition_v0_2.py --allow-s13-pending`

Return the complete console output and the generated
`StageA_A3_VS_rule_properties_generated_v0_2.csv`.
