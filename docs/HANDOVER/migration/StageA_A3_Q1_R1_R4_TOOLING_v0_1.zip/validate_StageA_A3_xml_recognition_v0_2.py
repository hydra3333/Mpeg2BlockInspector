#!/usr/bin/env python3
import argparse, csv, re
from collections import defaultdict

def die(msg):
    print("FAIL:", msg)
    raise SystemExit(1)

ap = argparse.ArgumentParser(
    description="Strict A3 XML recognition validator: v180 + rule/tool + name + enum/bool value + MSBuild placement."
)
ap.add_argument("--pin-table", default="StageA_A3_pin_table_v0_3.csv")
ap.add_argument("--rule-scan", default="StageA_A3_VS_rule_properties_generated_v0_2.csv")
ap.add_argument("--toolset-folder", default="v180")
ap.add_argument("--allow-s13-pending", action="store_true")
args = ap.parse_args()

rows = list(csv.DictReader(open(args.pin_table, newline="", encoding="ascii")))
rules = list(csv.DictReader(open(args.rule_scan, newline="", encoding="utf-8")))

# Only the installed VS2026 rule generation may satisfy the proof.
rules = [r for r in rules if r["toolset_folder"].lower() == args.toolset_folder.lower()]
if not rules:
    die(f"no rule rows for required toolset folder {args.toolset_folder}")

index = defaultdict(list)
for r in rules:
    index[r["property_name"]].append(r)

def expected_rule_and_placement(group):
    if group == "ClCompile":
        return "CL", lambda r: r["item_type"].lower() == "clcompile"
    if group == "Link":
        return "Link", lambda r: r["item_type"].lower() == "link"
    if group == "Configuration":
        return None, lambda r: r["label"].lower() == "configuration" and not r["item_type"]
    return None, None

unresolved = []
checked = 0

for row in rows:
    kind = row["coverage_kind"]
    if kind == "S13_PENDING":
        if not args.allow_s13_pending:
            unresolved.append((row["key"], row["xml_or_exception"], "S13_PENDING remains"))
        continue
    if kind != "XML":
        continue

    spec = row["xml_or_exception"]
    parts = re.split(r";\s*(?=[A-Za-z]+/)", spec)

    for part in parts:
        if "/" not in part:
            unresolved.append((row["key"], part, "no Group/Property form"))
            continue

        group, rest = part.split("/", 1)
        group = group.strip()
        if " includes " in rest:
            prop, value = rest.split(" includes ", 1)
            mode = "includes"
        elif "=" in rest:
            prop, value = rest.split("=", 1)
            mode = "equals"
        else:
            prop, value, mode = rest, None, "exists"

        prop = prop.strip()
        value = value.strip() if value is not None else None
        expected_rule, placement_pred = expected_rule_and_placement(group)
        if placement_pred is None:
            unresolved.append((row["key"], part, f"unknown XML placement group {group!r}"))
            continue

        candidates = []
        for r in index.get(prop, []):
            if expected_rule is not None and r["rule_name"] != expected_rule:
                continue
            if not placement_pred(r):
                continue
            candidates.append(r)

        if not candidates:
            seen = index.get(prop, [])
            details = "; ".join(
                f"{r['rule_name']}@{r['placement']}:{r['property_type']}"
                for r in seen[:8]
            ) or "property absent"
            unresolved.append((
                row["key"], part,
                f"no {args.toolset_folder} match for tool/placement; seen {details}"
            ))
            continue

        # Validate value spelling for enums and bools.
        value_ok = False
        reasons = []
        for r in candidates:
            ptype = r["property_type"]
            enums = [v for v in r["enum_values"].split(";") if v]
            if mode in ("exists", "includes"):
                value_ok = True
                break
            if ptype == "EnumProperty":
                if value in enums:
                    value_ok = True
                    break
                reasons.append(f"enum={enums}")
            elif ptype == "BoolProperty":
                if value.lower() in ("true", "false"):
                    value_ok = True
                    break
                reasons.append("bool requires true/false")
            else:
                # String/int/list properties: recognition + placement is what can be
                # proved by rule XML; exact evaluated value is separately gated.
                value_ok = True
                break

        if not value_ok:
            unresolved.append((
                row["key"], part,
                f"value {value!r} invalid for matched property ({'; '.join(reasons)})"
            ))
            continue

        checked += 1

if unresolved:
    for key, spec, why in unresolved:
        print("UNRESOLVED:", key, spec, why, sep=" | ")
    die(f"{len(unresolved)} strict XML recognition/placement items unresolved")

print(
    f"PASS: {checked} XML pin targets recognized in {args.toolset_folder} "
    "with correct rule/tool, property name, enum/bool value and DataSource placement."
)
