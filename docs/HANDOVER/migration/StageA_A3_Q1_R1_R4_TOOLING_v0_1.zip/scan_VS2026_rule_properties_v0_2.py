#!/usr/bin/env python3
import argparse, csv, re
from pathlib import Path
import xml.etree.ElementTree as ET

def local(tag):
    return tag.rsplit("}", 1)[-1]

def direct_datasources(elem):
    out = []
    for child in elem:
        if local(child.tag) == "DataSource":
            out.append(dict(child.attrib))
    return out

def toolset_folder(path):
    for part in path.parts:
        if re.fullmatch(r"v\d{3}", part, re.I):
            return part.lower()
    return ""

ap = argparse.ArgumentParser(
    description="Scan installed VS/MSBuild Visual C++ rule XML with tool/rule/value/DataSource placement evidence."
)
ap.add_argument("--vs-install", required=True)
ap.add_argument("--out", default="StageA_A3_VS_rule_properties_generated_v0_2.csv")
args = ap.parse_args()

root = Path(args.vs_install) / "MSBuild" / "Microsoft" / "VC"
if not root.is_dir():
    raise SystemExit(f"FAIL: VC MSBuild rule root not found: {root}")

rows = []
for path in root.rglob("*.xml"):
    try:
        tree = ET.parse(path)
    except Exception:
        continue
    rr = tree.getroot()
    if local(rr.tag) != "Rule":
        continue

    rule_name = rr.attrib.get("Name", "")
    rule_ds = direct_datasources(rr)

    for prop in rr.iter():
        ptype = local(prop.tag)
        if not ptype.endswith("Property") or "Name" not in prop.attrib:
            continue

        enum_values = []
        for child in prop:
            if local(child.tag) == "EnumValue" and child.attrib.get("Name"):
                enum_values.append(child.attrib["Name"])

        prop_ds = direct_datasources(prop)
        ds_list = prop_ds if prop_ds else rule_ds
        if not ds_list:
            ds_list = [{}]

        for ds in ds_list:
            item_type = ds.get("ItemType", "")
            label = ds.get("Label", "")
            persistence = ds.get("Persistence", "")
            if item_type:
                placement = f"ItemDefinitionGroup/{item_type}"
            elif label:
                placement = f"PropertyGroup[{label}]"
            else:
                placement = "UNSPECIFIED"

            rows.append({
                "toolset_folder": toolset_folder(path),
                "rule_file": str(path),
                "rule_name": rule_name,
                "property_type": ptype,
                "property_name": prop.attrib["Name"],
                "enum_values": ";".join(enum_values),
                "switch": prop.attrib.get("Switch", ""),
                "reverse_switch": prop.attrib.get("ReverseSwitch", ""),
                "datasource_scope": "property" if prop_ds else ("rule" if rule_ds else "none"),
                "persistence": persistence,
                "item_type": item_type,
                "label": label,
                "placement": placement,
            })

if not rows:
    raise SystemExit("FAIL: no property definitions found in rule XML")

fields = [
    "toolset_folder", "rule_file", "rule_name", "property_type", "property_name",
    "enum_values", "switch", "reverse_switch", "datasource_scope",
    "persistence", "item_type", "label", "placement"
]
with open(args.out, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=fields, lineterminator="\r\n")
    w.writeheader()
    w.writerows(rows)

by_toolset = {}
for r in rows:
    by_toolset[r["toolset_folder"]] = by_toolset.get(r["toolset_folder"], 0) + 1
counts = ", ".join(f"{k or '<none>'}={v}" for k, v in sorted(by_toolset.items()))
print(f"PASS: wrote {len(rows)} recognized property/DataSource definitions from {root} to {args.out}")
print(f"Toolset-folder counts: {counts}")
