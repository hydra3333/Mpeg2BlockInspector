# Stage A A3 Q1/R4 native tlog parser fix v0.1

This package fixes the v0.7 extractor's incorrect assumption that native
`.command.1.tlog` payload records contain a literal `cl.exe` or `link.exe`
executable name.

Dave's preserved Debug CL tlog proves the native format is alternating:

- tracker-key record beginning with `^`;
- raw compiler argument record beginning with switches such as `/c /ZI ...`.

The corrected extractor:

1. decodes the preserved UTF-16 tlogs;
2. ignores `^` tracker-key records;
3. recognizes CL/LINK raw argument payload records without requiring an exe name;
4. parses every payload record;
5. removes source/object/resource operands and normalizes path-valued switches;
6. requires all records for a tool/configuration to normalize identically;
7. preserves the measured default linker library list as one `LIBS=...` token;
8. writes CRLF CSV.

This is evidence tooling only. It does not modify the repository.

## Run from ordinary cmd.exe

python extract_StageA_A3_checkpoint_tlog_tokens_v0_2.py --debug-cl "%TEMP%\mpeg2deblock_stageA_checkpoint\evidence\Debug_CL.command.1.tlog" --release-cl "%TEMP%\mpeg2deblock_stageA_checkpoint\evidence\Release_CL.command.1.tlog" --debug-link "%TEMP%\mpeg2deblock_stageA_checkpoint\evidence\Debug_link.command.1.tlog" --release-link "%TEMP%\mpeg2deblock_stageA_checkpoint\evidence\Release_link.command.1.tlog" --out "StageA_A3_checkpoint_tokens_generated_v0_2.csv"

Then:

python validate_StageA_A3_tlog_evidence_v0_2.py --tokens "StageA_A3_checkpoint_tokens_generated_v0_2.csv"

Return both complete outputs.
