# Stage A A3 v0.2 - Pre-A3 Command Lines and Predicted Delta

## Measured pre-A3 checkpoint command lines

These are transcribed from the checkpoint evidence. The review package assembly BAT also copies the original command tlogs byte-for-byte so Claude can verify the transcription.

### Debug CL
```text
C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\HostX86\x64\CL.exe /c /ZI /JMC /nologo /W3 /WX- /diagnostics:column /sdl- /Od /D _CRT_SECURE_NO_WARNINGS /Gm- /EHsc /RTC1 /MDd /GS /fp:precise /Zc:wchar_t /Zc:forScope /Zc:inline /Fo"Mpeg2Blo.F4B1A357\x64\Debug\\" /Fd"Mpeg2Blo.F4B1A357\x64\Debug\vc145.pdb" /external:W3 /Gd /TC /FC /errorReport:queue ...all 16 C files...
```

### Debug LINK
```text
C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\HostX86\x64\link.exe /ERRORREPORT:QUEUE /OUT:"...\x64\Debug\Mpeg2BlockInspector.exe" /INCREMENTAL:NO /NOLOGO kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /MANIFEST /MANIFESTUAC:"level='asInvoker' uiAccess='false'" /manifest:embed /manifestinput:"...\Include\Manifest\segmentheap.manifest" /DEBUG /PDB:"...\x64\Debug\Mpeg2BlockInspector.pdb" /SUBSYSTEM:CONSOLE /TLBID:1 /DYNAMICBASE /NXCOMPAT /IMPLIB:"...\x64\Debug\Mpeg2BlockInspector.lib" /MACHINE:X64 ...
```

### Release CL
```text
C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\HostX86\x64\CL.exe /c /Zi /nologo /W3 /WX- /diagnostics:column /sdl- /O2 /D _CRT_SECURE_NO_WARNINGS /Gm- /EHsc /MD /GS /fp:precise /Zc:wchar_t /Zc:forScope /Zc:inline /Fo"Mpeg2Blo.F4B1A357\x64\Release\\" /Fd"Mpeg2Blo.F4B1A357\x64\Release\vc145.pdb" /external:W3 /Gd /TC /FC /errorReport:queue ...all 16 C files...
```

### Release LINK
```text
C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\HostX86\x64\link.exe /ERRORREPORT:QUEUE /OUT:"...\x64\Release\Mpeg2BlockInspector.exe" /INCREMENTAL:NO /NOLOGO kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /MANIFEST /MANIFESTUAC:"level='asInvoker' uiAccess='false'" /manifest:embed /manifestinput:"...\Include\Manifest\segmentheap.manifest" /DEBUG /PDB:"...\x64\Release\Mpeg2BlockInspector.pdb" /SUBSYSTEM:CONSOLE /OPT:REF /OPT:ICF /TLBID:1 /DYNAMICBASE /NXCOMPAT /IMPLIB:"...\x64\Release\Mpeg2BlockInspector.lib" /MACHINE:X64 ...
```

## Predicted A3 command-line/behavior delta

Pinning may make switches that were previously implied/defaulted appear explicitly. Those are intended semantic no-ops. The post-A3 detailed log remains authoritative.

### Deliberate behavior changes

- tool host: `HostX86\x64` -> `HostX64\x64` from `PreferredToolArchitecture=x64`; target remains x64.
- Debug `/ZI` -> `/Zi` (`DebugInformationFormat=ProgramDatabase`).
- Debug explicitly gains `/Ot /Ob2 /Oi` under ratified D3; `/Oi` is expected to eliminate the two `strcat` C4013 warnings.
- Release gains `/GL` and link gains `/LTCG`; these are the actual D1 Release optimization behavior changes.

### Explicit pins of already-effective behavior

- Debug/Release runtime `/MDd` / `/MD`; `/GS`; `/fp:precise`; `/TC`; `/Gd`; `/EHsc`; `/Zc:wchar_t`; `/Zc:forScope`; `/Zc:inline`; warning level and SDL state.
- x64 ISA floor is explicitly `/arch:SSE2`; this pins the existing x64 default and keeps AVX2 off.
- Release `/O2` is retained. Current Microsoft documentation states `/O2` is equivalent to `/Og /Oi /Ot /Oy /Ob2 /GF /Gy`, with `/Oy` x86-specific; therefore explicit `/Oi /Ot /Ob2 /GF /Gy` pins existing Release semantics rather than adding new behavior.
- UAC `asInvoker`, ASLR `/DYNAMICBASE`, DEP `/NXCOMPAT`, `/MACHINE:X64`, `/TLBID:1`, console subsystem, output name and segment-heap manifest state are pinned.

## Microsoft documentation checked 2026-10-09

- /O1, /O2: https://learn.microsoft.com/en-us/cpp/build/reference/o1-o2-minimize-size-maximize-speed
- /GL: https://learn.microsoft.com/en-us/cpp/build/reference/gl-whole-program-optimization
- /arch (x64): https://learn.microsoft.com/en-us/cpp/build/reference/arch-x64
- MSBuild CL task: https://learn.microsoft.com/en-us/visualstudio/msbuild/cl-task
- MSBuild Link task: https://learn.microsoft.com/en-us/visualstudio/msbuild/link-task
- /MANIFESTUAC: https://learn.microsoft.com/en-us/cpp/build/reference/manifestuac-embeds-uac-information-in-manifest

## Post-A3 acceptance rule

Do not accept this prediction as proof. After application, compare the exact post-A3 CL/LINK tlogs against the pre-A3 originals. Every semantic change must be either a ratified deliberate change above or an explicit pin of the measured behavior. Any other difference stops the gate.
