@echo off
setlocal EnableExtensions

for /f "delims=" %%I in ('git rev-parse --show-toplevel 2^>nul') do set "REPOROOT=%%I"
if not defined REPOROOT (
  echo ERROR: Run this from somewhere inside the VapourSynth-mpeg2Deblock Git repository.
  exit /b 1
)

set "PKG=%~dp0"
set "EVID=%PKG%evidence"
if not exist "%EVID%" mkdir "%EVID%"

set "CHK=%TEMP%\mpeg2deblock_stageA_checkpoint"
if not exist "%CHK%\StageA_checkpoint_Debug_x64.log" (
  echo ERROR: checkpoint Debug log not found under "%CHK%".
  exit /b 1
)
if not exist "%CHK%\StageA_checkpoint_Release_x64.log" (
  echo ERROR: checkpoint Release log not found under "%CHK%".
  exit /b 1
)

copy /b /y "%CHK%\StageA_checkpoint_Debug_x64.log" "%EVID%\StageA_checkpoint_Debug_x64.log" >nul || exit /b 1
copy /b /y "%CHK%\StageA_checkpoint_Release_x64.log" "%EVID%\StageA_checkpoint_Release_x64.log" >nul || exit /b 1
if exist "%CHK%\evidence\*" xcopy /e /i /y "%CHK%\evidence\*" "%EVID%\" >nul || exit /b 1

pushd "%REPOROOT%" || exit /b 1

git show --name-status --format=fuller 837df123ebfe0fa083fec9d6de8969bd180f9ac0 > "%EVID%\A2_git_show_name_status.txt" || goto :fail

git ls-files -- ^
 "VHSC_samples/TEST_2A_A001.idx" ^
 "VHSC_samples/TEST_2A_A001_blocky.idx" ^
 "VHSC_samples/TEST_4A_A003.idx" ^
 "VHSC_samples/LG_576i_4_EP.idx" ^
 "VHSC_samples/LG_576i_3_LP.idx" ^
 "VHSC_samples/LG_576i_5_MLS.idx" > "%EVID%\Six_gated_idx_git_tracking.txt" || goto :fail

for %%F in (
 "VHSC_samples\TEST_2A_A001.idx"
 "VHSC_samples\TEST_2A_A001_blocky.idx"
 "VHSC_samples\TEST_4A_A003.idx"
 "VHSC_samples\LG_576i_4_EP.idx"
 "VHSC_samples\LG_576i_3_LP.idx"
 "VHSC_samples\LG_576i_5_MLS.idx"
) do @certutil -hashfile "%%~F" SHA256 >> "%EVID%\Six_gated_idx_SHA256_current.txt" || goto :fail

git status --short > "%EVID%\git_status_short_before_A3.txt" || goto :fail
git status --short --ignored > "%EVID%\git_status_short_ignored_before_A3.txt" || goto :fail

git diff --name-status pre-stageA-vs-normalization -- "src\Mpeg2BlockInspector" "tools\Stage1_Inspector_Analyzer_v0_2.py" > "%EVID%\frozen_source_diff_vs_preStageA.txt" || goto :fail

certutil -hashfile "vs\VapourSynth-mpeg2deblock\Mpeg2BlockInspector.vcxproj" SHA256 > "%EVID%\current_A1_project_SHA256.txt" || goto :fail
certutil -hashfile "vs\VapourSynth-mpeg2deblock\VapourSynth-mpeg2deblock.slnx" SHA256 > "%EVID%\current_slnx_SHA256.txt" || goto :fail
certutil -hashfile "vs\VapourSynth-mpeg2deblock\x64\Release\Mpeg2BlockInspector.exe" SHA256 > "%EVID%\checkpoint_Release_EXE_SHA256_recheck.txt" || goto :fail

set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
  echo ERROR: vswhere not found: "%VSWHERE%"
  goto :fail
)
for /f "usebackq delims=" %%I in (`"%VSWHERE%" -latest -products * -requires Microsoft.Component.MSBuild Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSINSTALL=%%I"
for /f "usebackq delims=" %%I in (`"%VSWHERE%" -latest -products * -requires Microsoft.Component.MSBuild Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -find MSBuild\**\Bin\MSBuild.exe`) do set "MSBUILD=%%I"
(
 echo VSINSTALL=%VSINSTALL%
 echo MSBUILD=%MSBUILD%
) > "%EVID%\VS_MSBuild_discovery.txt"
if not defined VSINSTALL goto :fail
if not defined MSBUILD goto :fail
"%MSBUILD%" -version -nologo > "%EVID%\MSBuild_version_current.txt" || goto :fail

python "%PKG%validate_StageA_CNR3_reconciliation_v0_2.py" > "%EVID%\reconciliation_validator_local.txt" || goto :fail

popd

set "READY=%~dp0..\StageA_A3_v0_2_Review_Package_READY.zip"
if exist "%READY%" del "%READY%"
powershell -NoProfile -Command "Compress-Archive -Path '%PKG%*' -DestinationPath '%READY%' -CompressionLevel Optimal" || exit /b 1

echo.
echo PASS: local evidence assembled.
echo READY package: "%READY%"
exit /b 0

:fail
set "RC=%ERRORLEVEL%"
if "%RC%"=="0" set "RC=1"
popd 2>nul
echo ERROR: evidence assembly failed, rc=%RC%.
exit /b %RC%
