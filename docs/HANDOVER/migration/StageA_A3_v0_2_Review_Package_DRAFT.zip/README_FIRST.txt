Stage A A3 v0.2 DRAFT review package

Candidate SHA-256: a59788b492534334b86befdf440b5cae5a7687829e84f57377637f759044108a

DO NOT APPLY the candidate yet.

Recommended placement for Dave:
  E:\SOFTWARE-Win11\MULTIMEDIA\VapourSynth-mpeg2Deblock\A3_v0_2_review

Keep this draft package OUTSIDE the active Git repository so its files do not pollute git status.

From a CMD whose current directory is somewhere INSIDE the active VapourSynth-mpeg2Deblock Git repository, run the assembly BAT by its full path. The BAT intentionally uses the current working directory to discover the repository with git rev-parse.

The BAT:
1. copies the pre-A3 checkpoint detailed logs and evidence from %%TEMP%%;
2. records A2 git show --name-status, six tracked-index provenance/hashes, frozen-source diff, Git status, toolchain/vswhere evidence and current hashes;
3. reruns the 113-row reconciliation validator; and
4. creates StageA_A3_v0_2_Review_Package_READY.zip one directory above this extracted folder.

Send the READY zip to Claude for cold review.
Apply nothing until Claude review + Dave ratification.
