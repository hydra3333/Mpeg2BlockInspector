# Stage A A3 Q1/R4 tlog parser fix v0.2

This corrects one Windows ctypes defect in v0.1.

## Defect

`CommandLineToArgvW` returns `LPWSTR*`, but the previous script did not
declare the function's `restype`. ctypes therefore treated the result as a
plain integer, causing:

`TypeError: 'int' object is not subscriptable`

The preserved checkpoint tlogs are not at fault.

## Fix

The extractor now explicitly declares:

- `CommandLineToArgvW.argtypes`
- `CommandLineToArgvW.restype = POINTER(c_wchar_p)`
- `LocalFree.argtypes/restype`

The tlog parsing, normalization and consistency checks are otherwise
unchanged.

## Run from ordinary cmd.exe

python extract_StageA_A3_checkpoint_tlog_tokens_v0_3.py --debug-cl "%TEMP%\mpeg2deblock_stageA_checkpoint\evidence\Debug_CL.command.1.tlog" --release-cl "%TEMP%\mpeg2deblock_stageA_checkpoint\evidence\Release_CL.command.1.tlog" --debug-link "%TEMP%\mpeg2deblock_stageA_checkpoint\evidence\Debug_link.command.1.tlog" --release-link "%TEMP%\mpeg2deblock_stageA_checkpoint\evidence\Release_link.command.1.tlog" --out "StageA_A3_checkpoint_tokens_generated_v0_3.csv"

Then:

python validate_StageA_A3_tlog_evidence_v0_3.py --tokens "StageA_A3_checkpoint_tokens_generated_v0_3.csv"

Return both complete outputs.
