#!/usr/bin/env python3
import argparse
import csv
import ctypes
import os
import re
import shlex
from pathlib import Path

def fail(msg):
    print("FAIL:", msg)
    raise SystemExit(1)

def decode(path):
    b = Path(path).read_bytes()
    if b.startswith(b"\xff\xfe"):
        return b[2:].decode("utf-16le", "replace")
    if b.startswith(b"\xfe\xff"):
        return b[2:].decode("utf-16be", "replace")
    if b[:200].count(0) > 20:
        return b.decode("utf-16le", "replace")
    for enc in ("utf-8", "cp1252"):
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            pass
    return b.decode("latin1", "replace")

def argv_win(s):
    if os.name != "nt":
        return shlex.split(s, posix=False)

    # ctypes defaults a function result to c_int unless restype is declared.
    # CommandLineToArgvW actually returns LPWSTR*, so without this declaration
    # a 64-bit pointer is truncated/treated as an int and is not subscriptable.
    shell32 = ctypes.WinDLL("shell32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    shell32.CommandLineToArgvW.argtypes = [
        ctypes.c_wchar_p,
        ctypes.POINTER(ctypes.c_int),
    ]
    shell32.CommandLineToArgvW.restype = ctypes.POINTER(ctypes.c_wchar_p)

    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p

    n = ctypes.c_int(0)
    p = shell32.CommandLineToArgvW(s, ctypes.byref(n))
    if not p:
        err = ctypes.get_last_error()
        raise OSError(err, "CommandLineToArgvW failed")

    try:
        return [p[i] for i in range(n.value)]
    finally:
        kernel32.LocalFree(ctypes.cast(p, ctypes.c_void_p))

def payload_lines(path, tool):
    lines = []
    for raw in decode(path).splitlines():
        s = raw.strip().lstrip("\ufeff")
        if not s or s.startswith("^"):
            continue
        lines.append(s)

    if not lines:
        fail(f"no non-tracker payload records found in {path}")

    # Native .command.1.tlog records normally contain raw arguments only,
    # with no cl.exe/link.exe executable token. Also accept detailed-log-like
    # lines containing an executable so the parser remains diagnostic-friendly.
    if tool == "CL":
        matched = [
            s for s in lines
            if re.search(r"(^|\s)/c(?:\s|$)", s, re.I)
            or re.search(r"(^|[\\/])cl\.exe(?:\"|\s|$)", s, re.I)
        ]
    else:
        matched = [
            s for s in lines
            if re.search(r"(^|\s)/(?:out:|machine:|subsystem:|errorreport:)", s, re.I)
            or re.search(r"(^|[\\/])link\.exe(?:\"|\s|$)", s, re.I)
        ]

    if not matched:
        sample = " || ".join(lines[:3])
        fail(f"no recognizable {tool} payload record found in {path}; first payloads: {sample}")

    return matched

def normalize(tool, args):
    out = []
    libs = []
    i = 0

    while i < len(args):
        a = args[i].strip('"')
        lo = a.lower()

        if lo.endswith(("cl.exe", "link.exe")):
            i += 1
            continue

        if tool == "CL" and lo == "/d" and i + 1 < len(args):
            out.append("/D " + args[i + 1].strip('"'))
            i += 2
            continue

        if tool == "LINK" and lo.endswith(".lib"):
            libs.append(a.lower())
            i += 1
            continue

        # Remove source/object/resource path operands. Their membership is
        # separately controlled by the project; this evidence is for switches.
        if lo.endswith((".c", ".cpp", ".obj", ".res")):
            i += 1
            continue
        if "\\" in a and not a.startswith("/"):
            i += 1
            continue

        repl = None
        for pfx in ("/fo", "/fd", "/out:", "/pdb:", "/implib:", "/manifestinput:"):
            if lo.startswith(pfx):
                canon = pfx.upper().replace("/FO", "/Fo").replace("/FD", "/Fd")
                repl = canon + "<PATH>"
                break

        if repl:
            out.append(repl)
        else:
            out.append(a)
        i += 1

    if libs:
        pos = next((j for j, v in enumerate(out) if v.upper() == "/MANIFEST"), len(out))
        out.insert(pos, "LIBS=" + ";".join(libs))

    return out

def measured_tokens(path, tool):
    payloads = payload_lines(path, tool)
    normalized = [normalize(tool, argv_win(s)) for s in payloads]

    first = normalized[0]
    for idx, cur in enumerate(normalized[1:], 2):
        if cur != first:
            fail(
                f"{tool} payload records in {path} do not normalize identically; "
                f"record 1 differs from record {idx}"
            )

    print(f"EVIDENCE: {tool} {path}: {len(payloads)} payload record(s), {len(first)} normalized token(s)")
    return first

ap = argparse.ArgumentParser(
    description="Extract normalized Stage A checkpoint CL/LINK switch tokens from native UTF-16 .command.1.tlog records."
)
for name in ("debug_cl", "release_cl", "debug_link", "release_link"):
    ap.add_argument("--" + name.replace("_", "-"), required=True)
ap.add_argument("--out", default="StageA_A3_checkpoint_tokens_generated_v0_2.csv")
args = ap.parse_args()

jobs = [
    ("Debug|x64", "CL", args.debug_cl),
    ("Release|x64", "CL", args.release_cl),
    ("Debug|x64", "LINK", args.debug_link),
    ("Release|x64", "LINK", args.release_link),
]

rows = []
for cfg, tool, path in jobs:
    tokens = measured_tokens(path, tool)
    for ordinal, token in enumerate(tokens, 1):
        rows.append({
            "configuration": cfg,
            "tool": tool,
            "ordinal": ordinal,
            "token": token,
        })

with open(args.out, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(
        f,
        fieldnames=["configuration", "tool", "ordinal", "token"],
        lineterminator="\r\n",
    )
    w.writeheader()
    w.writerows(rows)

print(f"PASS: wrote {len(rows)} measured checkpoint command tokens to {args.out}")
