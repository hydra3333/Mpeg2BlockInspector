# A3 v0.10 - final gate evidence summary for Claude

Filename: A3_v0_10_FINAL_GATE_SUMMARY_v0_1.md
Version: 0.1
Date: 2026-10-10
Author: ChatGPT (migration chat)
Review status: Submitted for Claude independent review; NOT a Stage A closure decision
Authority: Dave ratifies. Production project remains unchanged during this review.

## 1. Review decision requested

Please cold-review the attached A3 v0.10 evidence against the ratified
Stage A gate, including Dave's specifically approved v0.10 six-index waiver.
Decide whether the evidence supports closing A3 / Stage A, or identify
bounded, necessary exceptions. Do not silently mark the waived test PASS.

## 2. Scope / change

A3 v0.10 uses a ratified and applied production Mpeg2BlockInspector.vcxproj
SHA-256 73e9019cda7d1061ecdb06526c60f4ee84baa4c385b7ca0dde4269544e4fdb46.
The incremental v0.9 -> v0.10 candidate introduces two empty
LinkTimeCodeGenerationObjectFile properties, eliminating unwanted /LTCGOUT
while retaining Release /GL and /LTCG. No source or analyzer edits.
Fixed Stage A Visual Studio 2026 Community MSBuild installation is retained
for gate comparability. Stage C/D dynamic toolchain discovery is future work.

## 3. Gate matrix and evidence provenance

A. Native Debug and Release full rebuilds: PASS. The uploaded ZIP contains
   both MSBuild logs. Independent inspection of the ZIP finds Build succeeded,
   17 warnings, 0 errors in each configuration. User reported RC=0.
B. Four native Debug/Release CL/LINK tlogs: PRESENT, each copied externally.
   User previously reported byte-exact fc /b comparison of all four copies
   against original tlogs; the original tlogs are not included in this ZIP.
C. W1 command token gate: PASS as reported by user/existing checker:
   W1_CHECKER_RC=0, counts Debug CL 33, Debug LINK 23, Release CL 32,
   Release LINK 25. ZIP contains the post-token CSV. Independent inspection
   confirms 113 tokens and no /LTCGOUT. The W1 checker console transcript and
   checkpoint CSV are NOT in this evidence ZIP; preserve the reported outcome.
D. HostX64: PASS. Uploaded logs explicitly contain HostX64\x64\CL.exe
   and HostX64\x64\link.exe in both configurations. No x86 host evidence.
E. Warning comparison: PASS. Prior attached v0.9 and v0.10 log excerpts
   were compared by code, source filename, source line/column and message.
   In both builds each configuration has 17 unique warnings:
   C4013 x8, C4101 x1, C4996 x8. Each appears twice in the full
   MSBuild log (compiler and summary). Both v0.10 logs are included here;
   the v0.9 logs are not included in this ZIP.
F. W2 PE/security: PASS. ZIP includes the four dumpbin inspection outputs,
   manifest extraction log and extracted manifest XML. Independent check:
   PE32+, x64 8664; Large Address Aware; High Entropy VA; Dynamic Base;
   NX; CFG; Terminal Server Aware; CET; nonzero security cookie;
   Guard CF function count 37 and instrumented/FID flags; RSDS CodeView
   PDB filename Mpeg2BlockInspector.pdb (no full path); KERNEL32.dll only
   in imports/dependents (no VC/UCRT runtime DLL); embedded manifest
   asInvoker/uiAccess=false and SegmentHeap. mt.exe exit RC=0 reported.
G. SHA-256 inventory: COMPLETE, per user's certutil outputs (listed below).
   No built executable is included in this evidence ZIP for independent
   hash recomputation. Hashes were collected on Dave's working machine.
H. Frozen sources/analyzer: PASS, based on exact baseline SHA-256 matches
   reported by Dave, and git diff --exit-code pre-stageA-vs-normalization
   for the three protected files returned 0. No further source inspection
   is authorised absent a concrete new finding.
I. Six-index behavioural regression: EXPLICITLY WAIVED FOR v0.10 by Dave.
   This is NOT PASS. Six-index regression previously passed for v0.9.
   Reason: v0.10 only removes an unintended /LTCGOUT file-output option;
   no intentional compiler/code-generation settings or source changes.
   Claude is to review the rationale. Future toolset/compiler or code-
   generation-relevant changes retain six-index regression requirements.
J. Build hygiene / Git status: PASS per Dave's command outputs:
   git status --short empty, 8 expected ignored build/scratch paths;
   no *.iobj or *.ipdb found. Ignored files not deleted.

## 4. SHA-256 evidence reported by Dave

Debug Mpeg2BlockInspector.exe:
  df92319fc0d39d9b09d8de82dd059324adca0eedae8f5e404aa6460d8cd1a0cc
Release Mpeg2BlockInspector.exe:
  fc168013f74074e3921dc781f6b2db69a9e67f7df80396dd2ab1fcc146c1ad48
Mpeg2BlockInspector.vcxproj:
  73e9019cda7d1061ecdb06526c60f4ee84baa4c385b7ca0dde4269544e4fdb46
VapourSynth-mpeg2Deblock.slnx:
  fa24efcd73401a38604e2f4228b07d8b960abcbfb66da22c02908e9d1cdb0754
Mpeg2BlockInspector.vcxproj.filters:
  a5a794a321f79122f6221a3f37669466417326a78126af4f3a2d9e8953c85269
Frozen getpic.c:
  e80239cfe73a0c04490a9bf131714861254ed1d7d095b052aac616a887ef0eca
Frozen mpeg2dec.c:
  8e6053ccb3a40be8c0d985f2e35124bf728d1f61df9b6d0c01b71e13e13b0947
Frozen Stage1_Inspector_Analyzer_v0_2.py:
  8e0d58305ee4fe518c25b67bdbe74acc4fb392486f23e6137862d916e5e02cda

The project SHA matches the exact ratified v0.10 candidate. The SLNX
hash matches the previously recorded Windows working-copy hash.
Line-ending differences in downloadable repository ZIPs are NOT accepted
as substitutes for Windows working-copy hashes.

## 5. Uploaded evidence ZIP integrity and inventory

Uploaded archive A3_v0_10_CLAUDE_EVIDENCE.zip: 46,828 bytes,
13 member files; ZIP CRC test PASS. Folder A3_v0_10_POST_APPLY_GATE
contains:
- StageA_A3_v0_10_post_tokens_v0_1.csv
- Debug/Debug_CL.command.1.tlog
- Debug/Debug_link.command.1.tlog
- Debug/StageA_A3_v0_10_Debug_x64.log
- Release/Release_CL.command.1.tlog
- Release/Release_link.command.1.tlog
- Release/StageA_A3_v0_10_Release_x64.log
- Release/StageA_A3_v0_10_Release_headers.txt
- Release/StageA_A3_v0_10_Release_loadconfig.txt
- Release/StageA_A3_v0_10_Release_imports.txt
- Release/StageA_A3_v0_10_Release_dependents.txt
- Release/StageA_A3_v0_10_Release_embedded_manifest.xml
- Release/StageA_A3_v0_10_Release_manifest_extract.log (0 bytes; RC=0)

## 6. Scope boundary / future policy

Stage A remains OPEN pending Claude's final gate review and Dave's
ratification. The production .vcxproj MUST NOT be changed during this gate.
Dave's policy: newest RELEASED, installed and updated VS installation;
previews excluded; Build Tools eligible (-products *); one vswhere discovery
root; 64-bit MSBuild (Bin\amd64), HostX64\x64 compilers/linkers, x64 target,
x64 Python/helpers and CI runners, discover/verify/record.
Current production project PlatformToolset=v145 stays unchanged through A3.
The post-Stage-A reviewed candidate will implement newest installed MSVC
toolset (minimum v145), using the Visual Studio-designated current MSVC
build without a project VCToolsVersion override. The intended project
DefaultPlatformToolset mechanism and guard are still UNVERIFIED pending
local proof. GitHub Actions needs 64-bit MSBuild and -noAutoResponse, clean
environment/ancestor auto-import guards, and mandatory CLI switch, host,
imports and change-triggered six-index checks, without supplying an
independent set of CL/LINK flags.
Routine local building should be through the VS2026 solution/project, not
manual command-line builds, as clarified by Dave.

## 7. Review documentation

All five current controlling documents from the H1-corrected package
are included under Documents. Every Claude review to which the document
changes respond is supplied under Reviews; ChatGPT's cold review is also
included. The document set records K1-K4, H1, and the Stage C toolchain
policy; this summary records later A3 gate results without silently changing
the ratified production build during the gate.
