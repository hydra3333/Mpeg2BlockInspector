# README consistency assessment - Stage A close-out

Date: 2026-10-10
Status: SNAPSHOT CONSISTENCY PASS; LIVE REPOSITORY README CHECK STILL REQUIRED

Scope: README.md extracted from user-provided VapourSynth-mpeg2Deblock-main.zip,
compared against the matching ZIP project configuration and accepted A3 v0.10
build/security evidence. This archive does not establish the bytes of the
live Windows working-copy README or its exact Git HEAD revision.

Checks:
- PASS: README explicitly requires Windows x64.
- PASS: README explicitly requires AVX2.
- PASS: README describes no VC++ redist for Release.
- PASS: README says Spectre not required.
- PASS: README names actual umbrella SLNX.
- PASS: README says local build through Visual Studio Release/Debug x64.
- PASS: README says build settings live in project.
- PASS: Archive snapshot project is x64 host both configurations.
- PASS: Archive snapshot project pins v145 until post-A3 follow-up.
- PASS: Archive snapshot project Release static CRT.
- PASS: Archive snapshot project explicitly disables Spectre.
- PASS: Accepted Release dumpbin evidence has KERNEL32 imports only.

Additional accepted gate observations:
- Release imports/dependencies list only KERNEL32.dll; the no-redist README claim is consistent with the accepted Release linkage.
- The Release PE evidence confirms x64/PE32+, CET, CFG, ASLR, NX, /GS cookie, and embedded manifest.
- Neither README nor the ZIP should be treated as a byte-hash authority for the live production .vcxproj or .slnx (Git Windows CRLF differences).
- README makes no claim of floating toolset generation, correctly leaving the current v145 pin to the project.

Remaining live check BEFORE commit/push:
- On Dave's Windows working tree, compare README.md to the accepted build/configuration and confirm it has no stale Spectre prerequisites, no erroneous toolset-auto-selection claim and no unsupported release/distribution statement.
- Record the live README Git status/diff before staging; verify staged README changes deliberately.
- Any discrepancy blocks repository close-out until corrected and reviewed; do not silently modify the build.

No live README Git check, Git commit, push or tag was performed in this environment.
