# Stage 1 proving-workflow candidate: Claude findings S1/S2 applied

Date: 2026-10-10

This patch updates the v0.2 proving workflow reviewed in
`Claude_REVIEW_OF_ChatGPT_Step1_Proving_Workflow_v0_1.md`.

Two and only two lines of `prove-project-build-windows-x64.yml` differ from the
reviewed candidate:

- S1 MUST: correct the PowerShell/.NET regular expression for actual HostX64
  compiler/linker invocation paths.
- S2 SHOULD: write the MSBuild file logger at `Verbosity=detailed`, rather than
  `diagnostic`, to avoid uploading the environment dump from diagnostic logs.

The existing log file names continue to end in `_diagnostic.log` solely to keep
this correction limited to exactly those two code lines. The file logger now
writes DETAILED logs regardless of the name. Renaming files can wait.

S3 (64-bit MSBuild property-function fallback) and optional O-a to O-d are
not changed by this patch. The unverified bitness probe remains fail-closed;
if it fails on the runner, investigate and correct it from real evidence.

Claude explicitly states no further candidate review is needed if S1 and S2
are the only changes. No GitHub runner execution is claimed. Dave's sole
active development branch is `main`; workflow_dispatch is the ONLY trigger.

Repository destinations:
- `.github/workflows/prove-project-build-windows-x64.yml`
- `.github/workflows/expected_a3_v0_10_switches.csv`
- `docs/HANDOVER/migration/Migration_Status.md`

After committing the two workflow-related files to `main`, dispatch the
workflow manually on `main` and provide the run's console log and the
`stage-a3-project-owned-msbuild-proof` evidence artifact for gate review.
This proving workflow does not publish a release.
