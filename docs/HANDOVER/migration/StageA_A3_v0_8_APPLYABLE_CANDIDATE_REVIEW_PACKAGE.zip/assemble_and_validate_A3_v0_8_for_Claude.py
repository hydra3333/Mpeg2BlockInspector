#!/usr/bin/env python3
import hashlib, os, shutil, subprocess, sys, zipfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
CAND=HERE/'Mpeg2BlockInspector_A3_APPLYABLE_CANDIDATE_v0_8.vcxproj'
A1=HERE/'Mpeg2BlockInspector_A1_BASELINE.vcxproj'
PIN=HERE/'StageA_A3_pin_table_v0_7.csv'
EXPECTED_CAND='30999ef34b9a38c4dbc2ad7b9ce7b1dcba0fe5f727c1963c9ba0dc2a4f5d52f3'
EXPECTED_A1='87acd9ad1c94e5545f84fe57857c076781ca499523d2a80545919ae571dc7a57'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def die(m): print('FAIL:',m); raise SystemExit(1)

if sha(CAND)!=EXPECTED_CAND: die(f'candidate SHA mismatch: {sha(CAND)}')
if sha(A1)!=EXPECTED_A1: die(f'A1 SHA mismatch: {sha(A1)}')
print('PASS: candidate and A1 SHA-256 values verified.')

wanted = {
 'StageA_A3_VS_rule_properties_generated_v0_3.csv': [
   PARENT/'StageA_A3_Q1_R1_S13_CLOSED_v0_1'/'StageA_A3_VS_rule_properties_generated_v0_3.csv',
   PARENT/'StageA_A3_Q1_R1_PLACEMENT_RESOLUTION_v0_1'/'StageA_A3_VS_rule_properties_generated_v0_3.csv'],
 'StageA_A3_checkpoint_tokens_generated_v0_4.csv': [
   PARENT/'StageA_A3_Q1_R4_TLOG_PARSER_FIX_v0_3'/'StageA_A3_checkpoint_tokens_generated_v0_4.csv'],
 'StageA_A3_tlog_pin_reconciliation_generated_v0_1.csv': [
   PARENT/'StageA_A3_Q1_R4_TLOG_PIN_RECONCILIATION_v0_1'/'StageA_A3_tlog_pin_reconciliation_generated_v0_1.csv'],
}

for name,cands in wanted.items():
    dst=HERE/name
    if dst.exists():
        print(f'EVIDENCE: using existing {dst}')
        continue
    src=next((p for p in cands if p.exists()),None)
    if src is None:
        matches=list(PARENT.rglob(name))
        # exclude current destination if it appears during weird filesystem refresh
        matches=[p for p in matches if p.resolve()!=dst.resolve()]
        if len(matches)==1: src=matches[0]
        elif len(matches)>1:
            print('Candidates for',name)
            for p in matches: print(' ',p)
            die(f'multiple {name} files found; copy the intended unchanged file into this directory')
    if src is None: die(f'local evidence file not found: {name}')
    shutil.copy2(src,dst)
    print(f'EVIDENCE: copied unchanged {src} -> {dst}')

# Preserve evidence hashes before any validator generates output.
evidence_names=list(wanted)
with open(HERE/'LOCAL_EVIDENCE_SHA256.txt','w',newline='\r\n',encoding='ascii') as f:
    for name in evidence_names:
        f.write(f'{sha(HERE/name)}  {name}\n')

def run(label,args,outname):
    cp=subprocess.run([sys.executable,*args],cwd=HERE,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    text=cp.stdout
    (HERE/outname).write_text(text,encoding='ascii',newline='\r\n')
    print(text,end='')
    if cp.returncode: die(f'{label} failed with RC={cp.returncode}')
    if 'PASS:' not in text: die(f'{label} produced no PASS line')
    return text

run('candidate structure',
    ['validate_StageA_A3_candidate_structure_v0_1.py',
     '--project',CAND.name,'--pin-table',PIN.name],
    'CANDIDATE_STRUCTURE_VALIDATOR_LOCAL_PASS.txt')
run('pin table',
    ['validate_StageA_A3_pin_table_v0_3.py','--pin-table',PIN.name],
    'PIN_TABLE_VALIDATOR_LOCAL_PASS.txt')
run('CNR3 reconciliation',
    ['validate_StageA_CNR3_reconciliation_v0_5.py'],
    'RECONCILIATION_VALIDATOR_LOCAL_PASS.txt')
run('strict v180 XML recognition',
    ['validate_StageA_A3_xml_recognition_v0_6.py',
     '--pin-table',PIN.name,
     '--rule-scan','StageA_A3_VS_rule_properties_generated_v0_3.csv'],
    'XML_RECOGNITION_VALIDATOR_LOCAL_PASS.txt')
run('tlog evidence',
    ['validate_StageA_A3_tlog_evidence_v0_4.py',
     '--tokens','StageA_A3_checkpoint_tokens_generated_v0_4.csv'],
    'TLOG_EVIDENCE_VALIDATOR_LOCAL_PASS.txt')

regen='StageA_A3_tlog_pin_reconciliation_regenerated_v0_1.csv'
run('tlog/pin reconciliation',
    ['validate_StageA_A3_tlog_pin_reconciliation_v0_1.py',
     '--tokens','StageA_A3_checkpoint_tokens_generated_v0_4.csv',
     '--pin-table',PIN.name,'--out',regen],
    'TLOG_PIN_RECONCILIATION_VALIDATOR_LOCAL_PASS.txt')

orig=HERE/'StageA_A3_tlog_pin_reconciliation_generated_v0_1.csv'
new=HERE/regen
if orig.read_bytes()!=new.read_bytes():
    die('regenerated tlog/pin reconciliation is not byte-identical to the prior local evidence CSV')
print('PASS: regenerated 86-row tlog/pin reconciliation is byte-identical to prior local evidence.')

# Final package manifest.
exclude={'PACKAGE_SHA256_READY.txt'}
entries=[]
for p in sorted(HERE.iterdir(),key=lambda p:p.name.lower()):
    if not p.is_file() or p.name in exclude or p.suffix.lower()=='.zip': continue
    entries.append((p.name,sha(p)))
with open(HERE/'PACKAGE_SHA256_READY.txt','w',newline='\r\n',encoding='ascii') as f:
    for n,h in entries: f.write(f'{h}  {n}\n')

zip_path=PARENT/'StageA_A3_v0_8_READY_FOR_CLAUDE.zip'
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(HERE.iterdir(),key=lambda p:p.name.lower()):
        if p.is_file() and p.suffix.lower()!='.zip':
            z.write(p,p.name)
print('PASS: READY package created:',zip_path)
print('READY ZIP SHA-256:',sha(zip_path))
