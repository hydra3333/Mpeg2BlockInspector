# Stage A A3 v0.8 - APPLYABLE CANDIDATE FOR COLD REVIEW

**Status:** Candidate is byte-copy applyable only after Claude cold review and Dave ratification. **DO NOT APPLY YET.**

**Candidate:** `Mpeg2BlockInspector_A3_APPLYABLE_CANDIDATE_v0_8.vcxproj`  
**Candidate SHA-256:** `30999ef34b9a38c4dbc2ad7b9ce7b1dcba0fe5f727c1963c9ba0dc2a4f5d52f3`  
**A1 baseline SHA-256:** `87acd9ad1c94e5545f84fe57857c076781ca499523d2a80545919ae571dc7a57`

## Closure carried into this candidate

Claude's 2026-10-10 closure review states Q1, R1 and R4 are closed by the supplied evidence. The candidate additionally carries Claude T1-T3:

- T1: `SpectreMitigation`, `CharacterSet`, `PreferredToolArchitecture`, and configuration-level `WholeProgramOptimization` are in the existing `Label="Configuration"` groups before the `Microsoft.Cpp.props` import.
- T2: whole-program optimization is explicit in both the Configuration and `ClCompile` representations: Debug false / Release true.
- T3: the default-library deliberate-exception reason states that unreferenced libraries cannot reach the image and the Release import gate (only KERNEL32 allowed) proves the outcome.

## Ratified build policy represented

- x64 only.
- `/arch:AVX2` Debug + Release.
- `/favor:blend` Debug + Release.
- `/GS`, CFG, CET, ASLR/High-Entropy VA, DEP/NX.
- Spectre mitigation explicitly Disabled; `/Qspectre` absent.
- inspector `/sdl` OFF.
- Debug `/MDd`; Release `/MT`.
- Release `/GL` + `/LTCG`.
- `/fp:precise`; `/fp:contract` absent.
- Release `/PDBALTPATH:%_PDB%`.
- SDK deliberately unpinned; toolset v145.
- Preferred tool host x64.

## No source change

The candidate retains exactly the A1 x64 source/header membership. Frozen C/H source and analyzer are not modified.

## Review boundary

Before Dave may ratify:

1. local generated rule/token/reconciliation CSVs must be copied unchanged into this package;
2. all local validators must PASS;
3. Claude must rerun recognition against the candidate itself and review the A1 diff and predicted deltas.

Only after Dave ratifies the exact candidate SHA may it be byte-copied over the repository project and subjected to the full A3 build/dumpbin/six-index gate.
