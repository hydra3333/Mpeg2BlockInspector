# Stage A A3 v0.8 - APPLYABLE CANDIDATE REVIEW PACKAGE

**DO NOT APPLY YET.**

This package contains the first A3 `.vcxproj` candidate intended to be byte-copy applyable only after:
1. Dave's three existing local evidence CSVs are added unchanged;
2. the complete local validator suite passes;
3. Claude cold-reviews this exact candidate;
4. Dave ratifies this exact candidate SHA-256.

Candidate:
`Mpeg2BlockInspector_A3_APPLYABLE_CANDIDATE_v0_8.vcxproj`
SHA-256 `30999ef34b9a38c4dbc2ad7b9ce7b1dcba0fe5f727c1963c9ba0dc2a4f5d52f3`

A1 baseline:
`Mpeg2BlockInspector_A1_BASELINE.vcxproj`
SHA-256 `87acd9ad1c94e5545f84fe57857c076781ca499523d2a80545919ae571dc7a57`

Claude's Q1/R1/R4 closure is carried, plus T1/T2/T3:
- T1: Configuration-labelled properties sit before `Microsoft.Cpp.props`; the candidate validator checks that order.
- T2: WholeProgramOptimization is explicit in both Configuration and ClCompile: Debug=false, Release=true.
- T3: default library lists remain deliberate exceptions because unreferenced libraries cannot reach the image; the Release import gate allowing only KERNEL32.dll proves the shipped outcome.

Already PASS in this package:
- `CANDIDATE_STRUCTURE_VALIDATOR_PASS.txt`
- `PIN_TABLE_VALIDATOR_PASS.txt`
- `RECONCILIATION_VALIDATOR_PASS.txt`

Three machine-generated local evidence files must be added unchanged:
- `StageA_A3_VS_rule_properties_generated_v0_3.csv`
- `StageA_A3_checkpoint_tokens_generated_v0_4.csv`
- `StageA_A3_tlog_pin_reconciliation_generated_v0_1.csv`

Extract this package as a sibling under the existing `A3_v0_7_PRE_CANDIDATE` tree, then run:
`ASSEMBLE_AND_VALIDATE_A3_v0_8_FOR_CLAUDE.bat`

The assembler searches the known sibling evidence directories, copies the exact local CSVs, reruns all validators, verifies the regenerated 86-row reconciliation is byte-identical to the prior local one, and creates:
`StageA_A3_v0_8_READY_FOR_CLAUDE.zip`

It does not modify the production repository.

The candidate is still unproven as a binary. After Claude review and Dave ratification, the full A3 build/dumpbin/import/warning/S15/six-index/frozen-source gate remains mandatory.
