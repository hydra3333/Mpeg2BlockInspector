# Stage A A3 v0.8 - Predicted CL/LINK delta

**Candidate SHA-256:** `30999ef34b9a38c4dbc2ad7b9ce7b1dcba0fe5f727c1963c9ba0dc2a4f5d52f3`  
**A1 SHA-256:** `87acd9ad1c94e5545f84fe57857c076781ca499523d2a80545919ae571dc7a57`

This is a prediction for review. The post-application tlogs and dumpbin outputs are authoritative. Any unexplained delta stops the gate.

## Tool host

Both Debug and Release:

```text
HostX86\x64 -> HostX64\x64
```

Target architecture remains x64.

## Debug CL

Measured checkpoint behavior retained unless listed below.

Deliberate/pinned changes:

```text
/ZI -> /Zi
add /Oi
add /Ot
add /Ob2
add /arch:AVX2
add /guard:cf
add /favor:blend
```

The candidate explicitly preserves `/MDd`, `/GS`, `/RTC1`, `/JMC`, `/Od`, `/fp:precise`, compile-as-C, warning/diagnostic switches, `/Zc:inline`, `/Fd`, and other measured behavior.

`/Qspectre` must remain absent. `/fp:contract` must remain absent.

## Release CL

Deliberate/pinned changes:

```text
/MD -> /MT
add /GL
add /arch:AVX2
add /guard:cf
add /favor:blend
```

The `/O2` component settings `/Oi /Ot /Ob2 /GF /Gy` are explicitly represented in the project. Their exact emitted spelling/order is verified from the post-A3 tlog.

`/Qspectre` must remain absent. `/fp:contract` must remain absent.

## Debug LINK

Deliberate/pinned changes:

```text
/DEBUG -> /DEBUG:FULL
add /GUARD:CF
add /CETCOMPAT
add explicit /HIGHENTROPYVA
```

The candidate explicitly preserves `/INCREMENTAL:NO`, `/MANIFEST`, `asInvoker`, `uiAccess=false`, `/manifest:embed`, the segment-heap manifest input, `/PDB`, `/SUBSYSTEM:CONSOLE`, `/TLBID:1`, `/DYNAMICBASE`, `/NXCOMPAT`, `/IMPLIB`, `/MACHINE:X64`, Large Address Aware, Terminal Server Aware, and Debug no-REF/no-ICF semantics.

The post-A3 tlog must show exactly one effective segment-heap `/manifestinput:` entry. Any duplication is a stop condition.

## Release LINK

Deliberate/pinned changes:

```text
/DEBUG -> /DEBUG:FULL
add /LTCG
add /GUARD:CF
add /CETCOMPAT
add explicit /HIGHENTROPYVA
add /PDBALTPATH:%_PDB%
```

Release retains `/OPT:REF` and `/OPT:ICF`.

## Default libraries

The measured default list remains deliberately unpinned as `AdditionalDependencies`:

```text
kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib
shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib
```

Reason: unreferenced libraries cannot reach the image. The Release standalone import gate, which allows only `KERNEL32.dll`, proves the shipped outcome.

## Release standalone dependency gate

The Release binary must contain none of:

```text
VCRUNTIME*
MSVCP*
api-ms-win-crt-*
ucrtbase*
CONCRT*
VCOMP*
MSVCR1*
```

Expected allowed Release dependency set:

```text
KERNEL32.dll
```

Any additional DLL stops the gate.

## PE/security gate

Post-A3 `dumpbin /headers /loadconfig /imports /dependents` must prove:

- x64 PE32+;
- Large Address Aware;
- High Entropy VA;
- Dynamic Base / ASLR;
- NX / DEP;
- full CFG image state, including non-zero Guard CF function table/count;
- CET compatible;
- security cookie retained;
- manifest present;
- Release CodeView PDB entry contains file name only under D6.

The project setting alone is not proof.
