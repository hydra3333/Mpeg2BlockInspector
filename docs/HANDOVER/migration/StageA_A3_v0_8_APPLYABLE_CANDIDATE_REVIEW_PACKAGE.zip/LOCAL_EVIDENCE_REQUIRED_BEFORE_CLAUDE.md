# Local evidence files intentionally absent from initial download

These three files were generated on Dave's VS2026 machine and already checked by Claude. ChatGPT does not recreate them:

- StageA_A3_VS_rule_properties_generated_v0_3.csv
- StageA_A3_checkpoint_tokens_generated_v0_4.csv
- StageA_A3_tlog_pin_reconciliation_generated_v0_1.csv

Run `ASSEMBLE_AND_VALIDATE_A3_v0_8_FOR_CLAUDE.bat` after extraction. It copies the existing local originals from sibling evidence directories and creates the READY zip after all validators pass.
