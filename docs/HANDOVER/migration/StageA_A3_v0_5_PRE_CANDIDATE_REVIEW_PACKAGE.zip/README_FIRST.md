# README FIRST - Stage A A3 v0.5 PRE-CANDIDATE

This package is intentionally **not applyable**. It carries the superseding A3 requirements after the previously missing Claude review and taxonomy review.

Why no `.vcxproj` candidate? S13 requires the exact VS2026 Property Pages XML to be observed on Dave's machine before the candidate is written. Guessing security/PDB property names would violate the no-defaults/content-verification policy.

Next local actions:

1. run `CHECK_A3_PREREQUISITES_v0_2.bat`;
2. perform `S13_VS2026_PROPERTY_PAGE_CAPTURE_v0_1.md`;
3. record `git ls-files vs` and confirm the committed README has been replaced by the no-Spectre correction;
4. preserve/time the pre-A3 LP executable three times;
5. return the evidence;
6. only then generate/review the final A3 `.vcxproj` candidate.

Do not apply A3 v0.1, v0.2 or v0.3.

Policy update: Dave deliberately removed Spectre mitigation from the required build policy. M7 Spectre-library/MSB8040 machinery is superseded. Retain /GS, CFG and CET; S13/S14/S15 still apply.
