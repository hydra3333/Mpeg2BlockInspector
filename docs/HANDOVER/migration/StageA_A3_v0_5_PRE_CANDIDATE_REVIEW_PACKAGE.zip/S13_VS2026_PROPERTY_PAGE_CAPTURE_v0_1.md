# S13 - VS2026 Property Pages Capture

Do this on a **scratch copy** of the current A1/A2 `Mpeg2BlockInspector.vcxproj`. Do not edit the live repository project.

1. Make two byte-identical scratch copies: BASE and WORK.
2. Open WORK in Visual Studio 2026.
3. For Debug|x64 and Release|x64 as required, set the intended values through Property Pages for:
   - Control Flow Guard;
   - CET compatibility / shadow-stack compatibility;
   - full-PDB/debug-information behavior;
   - any other A3 setting whose project XML spelling is still uncertain.
4. Save and close Visual Studio.
5. Produce an exact diff BASE -> WORK.
6. Return BASE, WORK and the diff to the migration ChatGPT/Claude review.

Rules:
- do not enable Spectre mitigation; `/Qspectre` is deliberately outside the accepted policy;
- use exactly what VS2026 writes where a dedicated element exists;
- do not hand-invent an XML element;
- use `AdditionalOptions` only where VS2026 provides no dedicated stable element and document why;
- this scratch experiment is evidence only and is never committed.
