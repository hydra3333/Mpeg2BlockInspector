@echo off
setlocal EnableExtensions

echo ============================================================
echo Stage A A3 v0.5 prerequisite check
echo ============================================================

set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
  echo FAIL: vswhere.exe not found: "%VSWHERE%"
  exit /b 1
)

set "VSINSTALL="
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.Component.MSBuild Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSINSTALL=%%i"
if not defined VSINSTALL (
  echo FAIL: no Visual Studio installation satisfies MSBuild + x64/x86 C++ tools.
  exit /b 1
)

set "MSBUILD="
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.Component.MSBuild Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -find MSBuild\**\Bin\MSBuild.exe`) do set "MSBUILD=%%i"
if not defined MSBUILD (
  echo FAIL: MSBuild.exe not found by the accepted vswhere criteria.
  exit /b 1
)

echo VSINSTALL=%VSINSTALL%
echo MSBUILD=%MSBUILD%
echo.
echo Spectre policy: NOT REQUIRED. No Spectre component is checked.
echo Required retained hardening for A3: /GS, CFG, CET.
echo Required CPU target for A3: /arch:AVX2.
echo.
echo PASS: base Visual Studio prerequisites found.
exit /b 0
