# Stage A A3 v0.5 - Superseding PRE-CANDIDATE Requirements

**Status:** REVIEW / LOCAL-CAPTURE package only. **NO APPLYABLE VCXPROJ IS INCLUDED.**

This package supersedes A3 v0.4 pre-candidate planning. It reflects Dave's later decision not to use Spectre mitigation. The final A3 project candidate is intentionally blocked until S13 is completed in Dave's VS2026 installation.

## Mandatory corrections carried

### Spectre policy - M7 superseded

Dave deliberately chose not to use Spectre mitigation. Therefore the final A3 candidate must have `/Qspectre` absent in Debug and Release, must not require Spectre-mitigated runtime libraries, must not add a Spectre component to `vswhere`, and must not add `MSB8040`-specific build handling.

### S12 - configurations

Both Debug and Release: `/arch:AVX2`, `/GS`, CFG and CET ON; Spectre mitigation deliberately NOT USED; inspector `/sdl` OFF. Debug `/MDd`; Release `/MT`.

### S13 - XML capture

Use VS2026 Property Pages on a scratch project and preserve the XML diff for new/uncertain settings before final candidate generation. Never guess property names.

### S14 - floating point

`/fp:precise`; `/fp:contract` absent in Debug and Release.

### S15 - timing

LP case three runs pre-A3 and three runs post-A3 on the same machine. Informational only.

### Optional

- O7: Debug `/favor:blend` remains open; Release `/favor:blend` is required.
- O8: `/guard:ehcont` is a Stage B plugin decision.

## 113-row reconciliation

The four CNR3 `EnableEnhancedInstructionSet=AdvancedVectorExtensions2` rows are now `REUSE UNCHANGED`. SDL rows remain deliberately different for the frozen-reference-decoder reason.

## Local evidence needed before final candidate

1. S13 scratch-project `.vcxproj` before/after copies and exact diff for CFG, CET and full-PDB/debug-information behavior.
2. Output from `CHECK_A3_PREREQUISITES_v0_1.bat`.
3. `git status --short -- README.md` and `git log -1 -- README.md`.
4. `git ls-files vs` output proving exact committed path case.
5. Pre-A3 LP timing (three runs) and preserved checkpoint Release EXE identity.

Once returned, generate the final A3 candidate, exact diff/hash, predicted command delta and READY evidence assembler.
