# Post-A3-v0.9-ratification migration documentation checkpoint

Read first:

1. `ChatGPT_Migration_Chat_Handover_v0_9.md`
2. `StageA_VS2026_MSBuild_Hard_Earned_Knowledge_v0_2.md`
3. `Claude_REVIEW_OF_ChatGPT_StageA_A3_v0_9_Candidate_v0_1.md`
4. `StageA_A3_v0_9_Ratification_Record_v0_1.md`
5. `Migration_Design_Record_D-C_CNR3_VS2026_Intent_v0_17.md`
6. `StageA_Visual_Studio_Normalization_Execution_Plan_v0_12.md`
7. `MPEG2_Deblocking_Developer_Handback_v0_11.md`

Exact ratified candidate SHA-256:

`ebfcde82405fd2dc25aa7a14a160f89375465d545927b3e4583e7a40fd1af668`

Current published repository baseline before application:

`34e8a46 Add vapoursynth include files ready for use with DLL building`

The next operation is A3 application and the full post-application gate. These documents do not assert that gate has passed.
