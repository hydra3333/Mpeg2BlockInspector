# Stage A A3 Q1 R1 placement resolution v0.1

This is tooling/evidence only. It is NOT an applyable A3 project candidate.

Dave's v180 rule scan established that LinkIncremental, GenerateManifest and
LinkControlFlowGuard all have property-level DataSource metadata:

- Rule: Link
- Persistence: ProjectFile
- ItemType: blank
- Label: blank
- HasConfigurationCondition: true
- Effective placement: PropertyGroup

Therefore these are configuration-conditioned project properties, not Link
ItemDefinitionGroup metadata.

The pin table now uses:

- Configuration/LinkIncremental=false
- Configuration/GenerateManifest=true
- Configuration/LinkControlFlowGuard=true

The validator accepts Configuration placement only when ItemType is blank and
either Label=Configuration or Persistence=ProjectFile plus
HasConfigurationCondition=true. This is evidence-backed, not a generic
relaxation.

## Run

Reuse the already-generated StageA_A3_VS_rule_properties_generated_v0_3.csv.
Copy it into this directory, then run:

python validate_StageA_A3_xml_recognition_v0_4.py --allow-s13-pending

If R1 placement is now fully resolved, the only remaining S13_PENDING rows
should be CLD_fd and CLR_fd.

Do not modify the repository project.
