# Stage A A3 Q1/R4 tlog-to-pin reconciliation v0.1

This package performs the final mechanical Q1/R4 accounting step.

## Why there are 82 native-tlog tokens but 86 checkpoint pin rows

The pin table contains:

- Debug CL: 26 rows
- Release CL: 24 rows
- Debug LINK: 17 rows
- Release LINK: 19 rows

Total: 86 checkpoint CL/LINK pin rows.

The preserved native `.command.1.tlog` evidence produced:

- Debug CL: 25 tokens
- Release CL: 23 tokens
- Debug LINK: 16 tokens
- Release LINK: 18 tokens

Total: 82 tokens.

The one omitted row in each group is the error-reporting switch:

- CLD_er `/errorReport:queue`
- CLR_er `/errorReport:queue`
- LD_err `/ERRORREPORT:QUEUE`
- LR_err `/ERRORREPORT:QUEUE`

Those four switches are present in the preserved detailed MSBuild checkpoint logs,
but the native `.command.1.tlog` payload records omit them.

Pin table v0.6 therefore corrects their evidence provenance. It does not remove
or weaken the pins.

## Validator rules

The reconciliation validator:

1. derives canonical expected tokens mechanically from the checkpoint pin-table
   `item` column;
2. requires every one of the 82 measured tlog tokens to map to exactly one
   checkpoint pin row;
3. rejects duplicate mappings;
4. requires every unmatched checkpoint row to be explicitly classified as
   detailed-MSBuild-log-only evidence;
5. requires those supplemental rows to be error-reporting pins;
6. requires exactly 82 native-tlog mappings + 4 detailed-log-only mappings =
   all 86 checkpoint CL/LINK rows;
7. writes a CRLF reconciliation CSV.

This replaces a hand-maintained expected-key list.

## Run

Copy the already generated:

`StageA_A3_checkpoint_tokens_generated_v0_4.csv`

into this directory.

Then run:

`python validate_StageA_A3_tlog_pin_reconciliation_v0_1.py --tokens "StageA_A3_checkpoint_tokens_generated_v0_4.csv" --pin-table "StageA_A3_pin_table_v0_6.csv"`

Return the complete output and retain the generated:

`StageA_A3_tlog_pin_reconciliation_generated_v0_1.csv`

for Claude's next review.

This is evidence tooling only. It does not modify the repository.
