# Stage A M3 checkpoint PE/load-config/import baseline

**Date:** 2026-10-09
**Purpose:** record the non-command-line-visible pre-A3 executable state measured with the matching VS2026 `dumpbin`.

## Checkpoint binaries

Debug expected SHA-256:

```text
66be0a77e21b34c9a92330c1752604b3be98d91deb6f133d37a1578361ea8bb9
```

Release expected SHA-256:

```text
d31fbad88f7cade245234c3fb81832e17ec9d2024e6c638ed8a033e3cc5bc6f8
```

## Measured PE state - both configurations

The supplied dumpbin captures show:

```text
machine x64
PE32+
Application can handle large (>2GB) addresses
High Entropy Virtual Addresses
Dynamic base
NX compatible
Terminal Server Aware
```

Neither image is marked CET Shadow Stack compatible.

The load configuration contains `CF instrumented` metadata from linked objects, but the image does not satisfy Microsoft's test for a fully CFG-enabled binary: there is no Guard image characteristic and no FID table present. A3 therefore pins project CFG off and linker `/GUARD:NO`.

## Debug dependency DLL names

```text
VCRUNTIME140D.dll
ucrtbased.dll
KERNEL32.dll
```

Debug remains `/MDd`; the post-A3 DLL-name set must remain the same.

## Release dependency DLL names before A3

```text
VCRUNTIME140.dll
api-ms-win-crt-stdio-l1-1-0.dll
api-ms-win-crt-filesystem-l1-1-0.dll
api-ms-win-crt-heap-l1-1-0.dll
api-ms-win-crt-string-l1-1-0.dll
api-ms-win-crt-math-l1-1-0.dll
api-ms-win-crt-runtime-l1-1-0.dll
api-ms-win-crt-convert-l1-1-0.dll
api-ms-win-crt-locale-l1-1-0.dll
KERNEL32.dll
```

Dave ratified Release `/MT` in consolidated A3. Therefore the post-A3 Release dependency-DLL rule is intentionally different:

Forbidden:

```text
VCRUNTIME*
MSVCP*
api-ms-win-crt-*
ucrtbase*
CONCRT*
VCOMP*
MSVCR1*
```

Allowed:

```text
KERNEL32.dll
```

Any additional DLL name stops the gate for review. Function-level KERNEL32 imports may grow because the statically linked runtime itself calls Windows APIs.

## A3 PE-state preservation gate

Apart from the deliberate Release runtime/import change, A3 must preserve:

```text
x64 PE32+
Large Address Aware
High Entropy VA
Dynamic Base
NX Compatible
no CET-compatible image flag
no fully enabled CFG image
manifest behaviour
Debug NOREF/NOICF semantics
full PDB generation
```

Do not compare timestamps, PDB GUIDs or section sizes as binary identity requirements.
