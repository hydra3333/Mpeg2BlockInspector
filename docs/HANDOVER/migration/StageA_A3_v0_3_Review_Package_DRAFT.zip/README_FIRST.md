# README FIRST - Stage A A3 v0.3 review package

This is a **DRAFT REVIEW PACKAGE**. Do not apply the candidate project file.

Candidate:

```text
Mpeg2BlockInspector_A3_PROPOSED_SETTINGS_v0_3.vcxproj
SHA-256 d7c6085f462927daa5e8f5128dac0b3e1f0d202f116b0ca9c8c4ca315bf51567
```

This revision incorporates:

- Claude A3 v0.2 review M3/S7-S9;
- Claude DR/plan review S10-S11;
- Dave D4 = NO: `/MT` consolidated into A3, no A4;
- Dave D5 = YES: future DLL `/MT`;
- Dave D6 = YES: Release `/PDBALTPATH:%_PDB%`;
- measured Debug/Release M3 dumpbin baseline;
- standalone Release dependency gate;
- enhanced 113-row validator with source-matrix cross-check.

## Review request

Claude should verify:

1. candidate XML and A1->A3 diff;
2. M3 pin implementation, especially `FullProgramDatabaseFile`, CFG-off, Spectre-off, `/HIGHENTROPYVA`, `/CETCOMPAT:NO`, `/GUARD:NO`;
3. Release `/MD -> /MT`;
4. Release `/PDBALTPATH:%_PDB%`;
5. predicted CL/LINK deltas;
6. standalone import gate;
7. reconciliation/validator;
8. DR v0.9 and Stage A plan v0.4 carry-forward;
9. READY evidence R1-R5 after Dave runs the assembly BAT.

No repository project setting should be changed until Claude approves and Dave ratifies this exact candidate.
