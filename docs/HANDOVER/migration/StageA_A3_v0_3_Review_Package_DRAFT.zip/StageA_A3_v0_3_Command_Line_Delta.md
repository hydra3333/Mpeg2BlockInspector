# Stage A A3 v0.3 - Pre-A3 Command Lines and Predicted Delta

## Measured pre-A3 checkpoint command lines

These are the checkpoint transcriptions. The READY-package assembly also copies the original UTF-16 CL/LINK command tlogs byte-for-byte for independent verification.

### Debug CL
```text
C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\HostX86\x64\CL.exe /c /ZI /JMC /nologo /W3 /WX- /diagnostics:column /sdl- /Od /D _CRT_SECURE_NO_WARNINGS /Gm- /EHsc /RTC1 /MDd /GS /fp:precise /Zc:wchar_t /Zc:forScope /Zc:inline /Fo"Mpeg2Blo.F4B1A357\x64\Debug\\" /Fd"Mpeg2Blo.F4B1A357\x64\Debug\vc145.pdb" /external:W3 /Gd /TC /FC /errorReport:queue ...all 16 C files...
```

### Debug LINK
```text
C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\HostX86\x64\link.exe /ERRORREPORT:QUEUE /OUT:"...\x64\Debug\Mpeg2BlockInspector.exe" /INCREMENTAL:NO /NOLOGO kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /MANIFEST /MANIFESTUAC:"level='asInvoker' uiAccess='false'" /manifest:embed /manifestinput:"...\Include\Manifest\segmentheap.manifest" /DEBUG /PDB:"...\x64\Debug\Mpeg2BlockInspector.pdb" /SUBSYSTEM:CONSOLE /TLBID:1 /DYNAMICBASE /NXCOMPAT /IMPLIB:"...\x64\Debug\Mpeg2BlockInspector.lib" /MACHINE:X64 ...
```

### Release CL
```text
C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\HostX86\x64\CL.exe /c /Zi /nologo /W3 /WX- /diagnostics:column /sdl- /O2 /D _CRT_SECURE_NO_WARNINGS /Gm- /EHsc /MD /GS /fp:precise /Zc:wchar_t /Zc:forScope /Zc:inline /Fo"Mpeg2Blo.F4B1A357\x64\Release\\" /Fd"Mpeg2Blo.F4B1A357\x64\Release\vc145.pdb" /external:W3 /Gd /TC /FC /errorReport:queue ...all 16 C files...
```

### Release LINK
```text
C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\HostX86\x64\link.exe /ERRORREPORT:QUEUE /OUT:"...\x64\Release\Mpeg2BlockInspector.exe" /INCREMENTAL:NO /NOLOGO kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /MANIFEST /MANIFESTUAC:"level='asInvoker' uiAccess='false'" /manifest:embed /manifestinput:"...\Include\Manifest\segmentheap.manifest" /DEBUG /PDB:"...\x64\Release\Mpeg2BlockInspector.pdb" /SUBSYSTEM:CONSOLE /OPT:REF /OPT:ICF /TLBID:1 /DYNAMICBASE /NXCOMPAT /IMPLIB:"...\x64\Release\Mpeg2BlockInspector.lib" /MACHINE:X64 ...
```

## Ratified deliberate A3 changes

- tool host: `HostX86\x64` -> `HostX64\x64`; target remains x64.
- Debug `/ZI` -> `/Zi`.
- Debug D3 pins speed/inlining/intrinsics.
- Release adds `/GL` + `/LTCG`.
- Dave D4 = NO: Release `/MD` -> `/MT` in the project file itself.
- Dave D6 = YES: Release linker adds `/PDBALTPATH:%_PDB%`.

## Explicit pins of already-effective behaviour

The candidate also makes previously implied/default behaviour explicit. The actual post-A3 tlogs remain authority for ordering and exact emitted syntax.

Compiler/project pins include:

```text
/diagnostics:column
/FC
/external:W3
/GS
/fp:precise
/TC
/Gd
/EHsc
/Zc:wchar_t
/Zc:forScope
/Zc:inline
/arch:SSE2
ControlFlowGuard=false
SpectreMitigation=false
```

Release `/O2` remains. Current Microsoft documentation states `/O2` includes `/Oi /Ot /Ob2 /GF /Gy` (plus x86-only `/Oy` and `/Og`), so those explicit Release values are pins rather than new D1 behaviour.

Link/manifest pins include:

```text
/MANIFEST
asInvoker + uiAccess=false
/DYNAMICBASE
/NXCOMPAT
/LARGEADDRESSAWARE
/HIGHENTROPYVA
/CETCOMPAT:NO
/GUARD:NO
/MACHINE:X64
/TLBID:1
```

Debug also pins the bare `/DEBUG` default semantics explicitly:

```text
/OPT:NOREF
/OPT:NOICF
full PDB
```

Release retains:

```text
/OPT:REF
/OPT:ICF
```

## Standalone Release import delta

Pre-A3 Release imports the dynamic VC/UCRT runtime. After `/MT`, the Release artifact must not depend on any DLL matching:

```text
VCRUNTIME*
MSVCP*
api-ms-win-crt-*
ucrtbase*
CONCRT*
VCOMP*
MSVCR1*
```

The currently measured allowed Release DLL-name set after removing runtime DLLs is `KERNEL32.dll`. Any additional DLL name stops the gate.

Debug remains `/MDd`; its dependency DLL-name set must remain `VCRUNTIME140D.dll`, `ucrtbased.dll`, `KERNEL32.dll`.

## Failure diagnosis if an index differs

Do not weaken the six-index gate. Build local, uncommitted variants in this order:

1. restore Release `/MD`;
2. then also remove `/GL` and `/LTCG`;
3. then also restore `PreferredToolArchitecture=x86`.

Return the attribution evidence to Claude and Dave before changing the reviewed design.

## Microsoft documentation checked 2026-10-09

- `/O1`, `/O2`: https://learn.microsoft.com/en-us/cpp/build/reference/o1-o2-minimize-size-maximize-speed
- `/GL`: https://learn.microsoft.com/en-us/cpp/build/reference/gl-whole-program-optimization
- `/arch` x64: https://learn.microsoft.com/en-us/cpp/build/reference/arch-x64
- `/MD`, `/MT`: https://learn.microsoft.com/en-us/cpp/build/reference/md-mt-ld-use-run-time-library
- `/DEBUG`: https://learn.microsoft.com/en-us/cpp/build/reference/debug-generate-debug-info
- `/HIGHENTROPYVA`: https://learn.microsoft.com/en-us/cpp/build/reference/highentropyva-support-64-bit-aslr
- `/CETCOMPAT`: https://learn.microsoft.com/en-us/cpp/build/reference/cetcompat
- `/GUARD`: https://learn.microsoft.com/en-us/cpp/build/reference/guard-enable-guard-checks
- MSBuild CL task: https://learn.microsoft.com/en-us/visualstudio/msbuild/cl-task
- MSBuild Link task: https://learn.microsoft.com/en-us/visualstudio/msbuild/link-task

## Post-A3 acceptance rule

Do not accept this prediction as proof. After application, compare exact post-A3 CL/LINK tlogs and dumpbin captures against the checkpoint evidence. Every semantic change must be either a ratified deliberate change above or an explicit pin of measured behaviour. Any other difference stops the gate.
