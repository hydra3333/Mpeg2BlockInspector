#!/usr/bin/env python3
import csv, sys
from pathlib import Path

ALLOWED = {
    "REUSE UNCHANGED",
    "REUSE WITH NAME/PATH ADJUSTMENT",
    "NOT APPLICABLE TO THIS PROJECT",
    "DELIBERATELY DIFFERENT",
    "DEFAULT IN CNR3 - LEAVE AT DEFAULT",
    "USER/MACHINE-LOCAL - RECORD BUT DO NOT COPY",
    "PROVISIONAL - TECHNICAL DEVELOPMENT DECISION NOT YET FINAL",
}

root = Path(__file__).resolve().parent
recon = root / "StageA_CNR3_113_row_reconciliation_v0_3.csv"
source = root / "StageA_CNR3_113_row_source_reference_v0_1.csv"

def read_csv(path):
    with path.open(encoding="ascii", newline="") as f:
        return list(csv.DictReader(f))

rows = read_csv(recon)
source_rows = read_csv(source)
errors = []

if len(rows) != 113:
    errors.append(f"expected 113 reconciliation rows, got {len(rows)}")
if len(source_rows) != 113:
    errors.append(f"expected 113 source-reference rows, got {len(source_rows)}")

counts = {"CNR3_selftest": 0, "CNR3_DLL": 0}
seen = set()
for n, r in enumerate(rows, 2):
    key = (r.get("project",""), r.get("source_line",""))
    if key in seen:
        errors.append(f"row {n}: duplicate key {key}")
    seen.add(key)
    if r.get("project") in counts:
        counts[r["project"]] += 1
    else:
        errors.append(f"row {n}: unexpected project {r.get('project')!r}")
    if not r.get("disposition"):
        errors.append(f"row {n}: blank disposition")
    elif r["disposition"] not in ALLOWED:
        errors.append(f"row {n}: invalid disposition {r['disposition']!r}")
    if not r.get("reason"):
        errors.append(f"row {n}: blank reason")
if counts != {"CNR3_selftest":56, "CNR3_DLL":57}:
    errors.append(f"wrong project counts: {counts}")

def norm_ref(r):
    return (
        r.get("project",""),
        r.get("source_line",""),
        r.get("configuration",""),
        r.get("tool_group",""),
        r.get("setting",""),
        r.get("cnr3_value",""),
    )

recon_ref = {norm_ref(r) for r in rows}
source_ref = {norm_ref(r) for r in source_rows}

missing = sorted(source_ref - recon_ref)
extra = sorted(recon_ref - source_ref)
if missing:
    errors.append(f"{len(missing)} CNR3 source rows missing from reconciliation")
    for x in missing[:10]:
        errors.append(f"  missing: {x}")
if extra:
    errors.append(f"{len(extra)} reconciliation rows do not match the CNR3 source reference")
    for x in extra[:10]:
        errors.append(f"  extra: {x}")

if errors:
    print("FAIL")
    for e in errors:
        print(e)
    sys.exit(1)

print("PASS: 113 CNR3 rows; 56 self-test + 57 DLL; "
      "all dispositions/reasons populated and vocabulary-valid; "
      "every project+line+setting+value matches the source-reference matrix.")
