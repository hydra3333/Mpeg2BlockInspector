#!/usr/bin/env python3
import argparse,csv
from collections import Counter
P='StageA_A3_pin_table_v0_1.csv'
E='StageA_A3_pin_table_expected_keys_v0_1.txt'
REQ=['key','source','configuration','item','checkpoint_value','a3_value','coverage_kind','xml_or_exception','evidence_source','notes']
KINDS={'XML','ADDITIONAL_OPTIONS','DELIBERATE_CHANGE','DELIBERATE_EXCEPTION','TOOL_SEMANTIC','S13_PENDING'}
def die(m): print('FAIL:',m); raise SystemExit(1)
a=argparse.ArgumentParser(); a.add_argument('--allow-s13-pending',action='store_true'); x=a.parse_args()
with open(P,newline='',encoding='ascii') as f:
    rr=csv.DictReader(f); rows=list(rr)
    if rr.fieldnames!=REQ: die(f'columns={rr.fieldnames!r}')
expected=[s.strip() for s in open(E,encoding='ascii') if s.strip()]
keys=[r['key'] for r in rows]
if len(keys)!=len(set(keys)): die('duplicate pin-table keys')
if len(expected)!=len(set(expected)): die('duplicate expected keys')
if set(keys)!=set(expected): die(f'key set differs: missing={sorted(set(expected)-set(keys))[:5]} extra={sorted(set(keys)-set(expected))[:5]}')
for r in rows:
    for c in REQ[:-1]:
        if not r[c].strip(): die(f'blank {c} for {r["key"]}')
    if r['coverage_kind'] not in KINDS: die(f'bad coverage_kind {r["key"]}: {r["coverage_kind"]}')
    if r['coverage_kind']=='S13_PENDING' and not x.allow_s13_pending: die(f'S13_PENDING remains: {r["key"]}')
print(f'PASS: {len(rows)} pin rows; exact expected-key set; no duplicates/blanks; '+('S13_PENDING allowed for pre-candidate.' if x.allow_s13_pending else 'no S13_PENDING rows.'))
