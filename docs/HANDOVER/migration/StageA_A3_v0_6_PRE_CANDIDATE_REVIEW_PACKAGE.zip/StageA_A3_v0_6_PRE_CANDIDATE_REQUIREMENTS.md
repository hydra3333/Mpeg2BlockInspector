# Stage A A3 v0.6 - PRE-CANDIDATE Requirements

**Status:** REVIEW / LOCAL-CAPTURE only. No applyable `.vcxproj` is included.

## Ratified direction

- x64 only.
- `/arch:AVX2` in Debug and Release.
- O7=YES: `/favor:blend` explicit in Debug and Release; Stage B follows.
- Debug `/MDd`; Release `/MT`.
- Release `/PDBALTPATH:%_PDB%`.
- `/GS`, CFG and CET ON in Debug and Release.
- N1: Spectre mitigation explicitly Disabled in Debug and Release; `/Qspectre` absent.
- inspector `/sdl` OFF as frozen-reference-decoder exception.
- `/fp:precise`; `/fp:contract` absent.

## S13

Capture exact VS2026 XML by Property Pages for CFG enabled, CET compatible enabled, Spectre mitigation Disabled, and Full-PDB/debug-information behaviour. Do not guess property names.

## P1 pin table

`StageA_A3_pin_table_v0_1.csv` enumerates every checkpoint CL/LINK switch and M3 semantic property, plus N1/O7. `StageA_A3_pin_table_expected_keys_v0_1.txt` is the expected-key set.

The final candidate validator must PASS with no `S13_PENDING`. The pre-candidate may run with `--allow-s13-pending` only to prove enumeration completeness.

## P3 dumpbin gate

Post-A3 evidence requires CFG in DLL characteristics, a present/non-zero Guard CF function table/count, CET compatibility, `/GS` evidence, Release RSDS/PDB file name only, Debug development PDB path allowed, and standalone Release dependency PASS. Exact accepted `dumpbin` wording is frozen from the first accepted post-A3 capture.

## P4 reconciliation validator

Reject duplicate keys, require 56 self-test + 57 DLL rows, cross-check key/setting/CNR3 value against source reference, and reject blank/unknown dispositions/reasons.

## P5/P6/N3/N5

- corrected duplicated/stale document text is in DR v0.14 / Plan v0.9 / Handback v0.8;
- prerequisite BAT is CRLF;
- stale BAT/vocabulary references are corrected;
- MSBuild is derived/verified under the same VS installation selected by vswhere.

## S14 / S15

- prove `/fp:contract` absent in both CL command lines;
- preserve/hash the pre-A3 Release EXE and time LP three times pre-A3 and three times post-A3; information only.

## O8

`/guard:ehcont` remains a Stage B plugin decision.
