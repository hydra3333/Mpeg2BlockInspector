# Stage A A3 v0.6 PRE-CANDIDATE review package

**Status:** REVIEW / LOCAL-CAPTURE ONLY. **NO APPLYABLE `.vcxproj` IS INCLUDED.**

This package supersedes A3 v0.5 pre-candidate planning. It carries Dave's O7=YES decision, Claude N1/P1/P3-P6/N3/N5, and the no-Spectre policy.

The final A3 project candidate remains blocked on S13 evidence from Dave's VS2026 Property Pages. Do not apply any project file from an older A3 package.

Required local sequence:

1. Run `CHECK_A3_PREREQUISITES_v0_3.bat`.
2. Run the S13 scratch-property capture in `S13_VS2026_PROPERTY_PAGE_CAPTURE_v0_2.md`.
3. Preserve BASE/WORK project copies and an exact diff.
4. Return that evidence to migration ChatGPT/Claude.
5. Only then generate the applyable A3 candidate.

Pre-candidate mechanical checks included here:

- `validate_StageA_CNR3_reconciliation_v0_5.py` must PASS.
- `validate_StageA_A3_pin_table_v0_1.py --allow-s13-pending` must PASS now.
- The same pin-table validator **without** `--allow-s13-pending` must PASS in the final candidate; any unresolved S13 row blocks application.

README timing N4: option (a). The corrected no-Spectre README may be committed now as offsite/public documentation backup.
