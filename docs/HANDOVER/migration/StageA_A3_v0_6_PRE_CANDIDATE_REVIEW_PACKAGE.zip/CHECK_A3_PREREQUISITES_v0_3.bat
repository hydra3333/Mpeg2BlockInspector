@echo off
setlocal EnableExtensions

echo ============================================================
echo Stage A A3 v0.6 prerequisite check
echo ============================================================

set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
  echo FAIL: vswhere.exe not found: "%VSWHERE%"
  exit /b 1
)

set "VSINSTALL="
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.Component.MSBuild Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSINSTALL=%%i"
if not defined VSINSTALL (
  echo FAIL: no Visual Studio installation satisfies MSBuild + x64/x86 C++ tools.
  exit /b 1
)

set "MSBUILD=%VSINSTALL%\MSBuild\Current\Bin\MSBuild.exe"
if not exist "%MSBUILD%" (
  echo FAIL: expected MSBuild.exe not found under selected VS installation:
  echo   VSINSTALL=%VSINSTALL%
  echo   MSBUILD=%MSBUILD%
  exit /b 1
)

echo VSINSTALL=%VSINSTALL%
echo MSBUILD=%MSBUILD%
echo.
echo PASS: MSBuild is under the same VS installation selected by vswhere.
echo Spectre policy: explicit Disabled project setting; no Spectre component required.
echo Required retained hardening for A3: /GS, CFG, CET.
echo Required CPU target for A3: /arch:AVX2.
echo O7: /favor:blend explicit in Debug and Release.
exit /b 0
