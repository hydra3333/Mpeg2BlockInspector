# Stage A A3 Q1/R4 tlog parser fix v0.3

This corrects one token-classification defect in v0.2.

## Defect

The extractor classified any LINK token ending in `.lib` as a default-library
operand before checking path-valued switches.

Therefore:

`/IMPLIB:<path>\Mpeg2BlockInspector.lib`

was incorrectly appended to the generated:

`LIBS=kernel32.lib;...;odbccp32.lib`

token.

## Fix

The extractor now:

1. recognizes and normalizes path-valued switches first, including `/IMPLIB:`;
2. only classifies a `.lib` token as a default library when it is a bare
   operand and does not begin with `/`.

Expected generated LINK tokens now include both:

`LIBS=kernel32.lib;...;odbccp32.lib`

and:

`/IMPLIB:<PATH>`

as separate entries.

## Run

python extract_StageA_A3_checkpoint_tlog_tokens_v0_4.py --debug-cl "%TEMP%\mpeg2deblock_stageA_checkpoint\evidence\Debug_CL.command.1.tlog" --release-cl "%TEMP%\mpeg2deblock_stageA_checkpoint\evidence\Release_CL.command.1.tlog" --debug-link "%TEMP%\mpeg2deblock_stageA_checkpoint\evidence\Debug_link.command.1.tlog" --release-link "%TEMP%\mpeg2deblock_stageA_checkpoint\evidence\Release_link.command.1.tlog" --out "StageA_A3_checkpoint_tokens_generated_v0_4.csv"

Then:

python validate_StageA_A3_tlog_evidence_v0_4.py --tokens "StageA_A3_checkpoint_tokens_generated_v0_4.csv"

Return both complete outputs.
