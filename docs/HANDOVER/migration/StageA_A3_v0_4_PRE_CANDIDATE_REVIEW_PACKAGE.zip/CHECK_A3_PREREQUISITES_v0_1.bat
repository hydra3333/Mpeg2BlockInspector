@echo off
setlocal EnableExtensions
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
  echo FAIL: vswhere not found: "%VSWHERE%"
  exit /b 1
)
set "VSINSTALL="
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.Component.MSBuild Microsoft.VisualStudio.Component.VC.Tools.x86.x64 Microsoft.VisualStudio.Component.VC.Runtimes.x86.x64.Spectre -property installationPath`) do set "VSINSTALL=%%i"
if not defined VSINSTALL (
  echo FAIL: No Visual Studio installation satisfies MSBuild + x64 C++ tools + x64/x86 Spectre runtime libraries.
  exit /b 1
)
echo PASS: VSINSTALL=%VSINSTALL%
set "MSBUILD=%VSINSTALL%\MSBuild\Current\Bin\MSBuild.exe"
if not exist "%MSBUILD%" (
  echo FAIL: MSBuild not found: "%MSBUILD%"
  exit /b 1
)
echo PASS: MSBUILD=%MSBUILD%
"%MSBUILD%" -version
exit /b %errorlevel%
