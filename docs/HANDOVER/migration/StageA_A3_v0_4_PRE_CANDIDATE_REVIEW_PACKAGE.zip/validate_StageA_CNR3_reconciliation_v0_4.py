import csv, sys
from pathlib import Path
p=Path(__file__).with_name("StageA_CNR3_113_row_reconciliation_v0_4.csv")
allowed={
"REUSE UNCHANGED","REUSE WITH NAME/PATH ADJUSTMENT","NOT APPLICABLE TO THIS PROJECT",
"DELIBERATELY DIFFERENT","DEFAULT IN CNR3 - LEAVE AT DEFAULT",
"USER/MACHINE-LOCAL - RECORD BUT DO NOT COPY","PROVISIONAL - TECHNICAL DEVELOPMENT DECISION NOT YET FINAL"}
with p.open(newline="",encoding="ascii") as f:
    rows=list(csv.DictReader(f))
errs=[]
if len(rows)!=113: errs.append(f"row count {len(rows)} != 113")
for i,r in enumerate(rows,2):
    if r["disposition"] not in allowed: errs.append(f"line {i}: bad disposition {r['disposition']!r}")
    if not r["reason"].strip(): errs.append(f"line {i}: blank reason")
avx=[r for r in rows if r["setting"]=="EnableEnhancedInstructionSet" and r["cnr3_value"]=="AdvancedVectorExtensions2"]
if len(avx)!=4: errs.append(f"AVX2 rows {len(avx)} != 4")
for r in avx:
    if r["disposition"]!="REUSE UNCHANGED" or r["inspector_v0_4_target_value"]!="AdvancedVectorExtensions2":
        errs.append(f"AVX2 row not reuse unchanged: {r}")
if errs:
    print("FAIL")
    print("\n".join(errs))
    sys.exit(1)
print("PASS: 113 rows; allowed dispositions/reasons; four AVX2 rows REUSE UNCHANGED.")
