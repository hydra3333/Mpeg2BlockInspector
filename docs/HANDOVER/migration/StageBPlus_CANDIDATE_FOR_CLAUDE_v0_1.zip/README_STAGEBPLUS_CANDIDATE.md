# Stage B+ applyable project candidate - v0.1 (for Claude review only)

**Date:** 2026-10-10
**Status:** DRAFT / NOT RATIFIED / NOT APPLIED / NOT BUILT.
**Authority:** Dave decides, Claude independently reviews, ChatGPT prepares.
**Source base:** the exact accepted Stage A3 v0.10 inspector and x64 solution, verified against Dave's SHA-256 identities after Windows CRLF normalisation.

## Scope

Four project/solution files and three new plugin scaffolding files, delivered FLAT (no nested ZIP). The new DLL has exactly one passthrough VapourSynth API4 function (`Identity`) with no frame processing. It is not Stage 2 technical implementation. O1-O7 dispositions are from living Migration_Status v0.5. No existing inspector C/H source or analyzer changes.

| Candidate file in this archive | Intended location in REPO (only after ratification) |
|---|---|
| `Mpeg2BlockInspector.vcxproj` | `vs\VapourSynth-mpeg2Deblock\Mpeg2BlockInspector.vcxproj` |
| `mpeg2Deblock.vcxproj` | `vs\VapourSynth-mpeg2Deblock\mpeg2Deblock.vcxproj` |
| `mpeg2Deblock.vcxproj.filters` | `vs\VapourSynth-mpeg2Deblock\mpeg2Deblock.vcxproj.filters` |
| `VapourSynth-mpeg2Deblock.slnx` | `vs\VapourSynth-mpeg2Deblock\VapourSynth-mpeg2Deblock.slnx` |
| `plugin.cpp`, `plugin_version.h`, `mpeg2Deblock.rc` | `src\mpeg2Deblock\` |

## Intended build changes

1. Inspector: two `PlatformToolset=v145` settings become `$(DefaultPlatformToolset)` (Debug+Release). Add a numeric MSBuild minimum v145 gate; use native MSBuild `VersionLessThan` which supports a leading v. Add `/guard:ehcont` to **both** compiler and linker options in both configs; preserve all other accepted flags.
2. DLL: copied from accepted inspector pin set; switch to C++20 DynamicLibrary; `/permissive-` (`ConformanceMode`), `/sdl` ON, no `_CRT_SECURE_NO_WARNINGS`; x64 AVX2, `/favor:blend`, Debug `/MDd`, Release `/MT`, `/GS`, CFG, CET, EHCONT, `/LARGEADDRESSAWARE`, `/fp:precise` without automatic FMA contraction. Remove exe-only Console, asInvoker/UAC, and SegmentHeap. DLL imports and export must be checked on Windows.
3. Version: `plugin_version.h` is the ONE authority for number fields, resource `mpeg2Deblock.rc` and C++ source include that header. Version `0.1.0.0` is **provisional scaffold version**; no public numbering policy or PyPI publication is implied. Both the VERSIONINFO numeric value and formatted version string derive automatically from the four version-number macros in the same header; no manually repeated version literal exists.
4. API: plugin name set per Dave O1; exports `VapourSynthPluginInit2`, registers `Identity(clip:vnode)->clip:vnode`. `Identity` only transfers a `VSNode` reference using VapourSynth's API functions. Header source is the **already vendored VapourSynth R78** under `third_party\vapoursynth\include`; no new API headers shipped or altered.
5. `.slnx`: registers second project. Same x64-only configuration. No separate DLL wheel, CPU-dispatch modules, or technical experimentation.

## REQUIRED Windows evidence BEFORE Gate acceptance

**These checks have NOT BEEN RUN by ChatGPT (no Visual Studio or VapourSynth runtime in the current environment).** Candidate is for Claude's *design/source review* first. Do not represent XML-parsing PASS as an MSBuild build PASS.

A. First independently verify `DefaultPlatformToolset` resolves to VS2026's current installed value in both project configurations **after** `Microsoft.Cpp.Default.props`. Validate the `v145` numeric guard with actual `v145`, a lower test value (in a disposable scratch copy), and the observed Visual Studio current value. This is a project setting candidate, **NOT yet locally proved**, notwithstanding external documentation supporting the mechanism. If it does not resolve before imports or the numeric guard does not execute in VS GUI, repair candidate BEFORE production application. Never silently fall back to v145 when undefined.

B. Establish proper recognition of the new `/guard:ehcont` CL/LINK flags from the current installed MSVC rule files/Property Pages; this candidate uses project-owned `AdditionalOptions` for each tool. Note legacy C Debug `/Gy-`; Microsoft documents some EH metadata scenarios that make the linker fail. Check complete actual invocations, successful links, and EH Continuation Table information via `dumpbin /loadconfig`. Do not assert a table if none was emitted; do not silently disable protection.

C. Compile inspector and DLL through VS2026 GUI (`Debug|x64` and `Release|x64`). Confirm full pin/checkpoint comparison: inspector settings delta versus A3 should contain ONLY the toolset mechanism and EHCONT switches; DLL gets independently reviewed actual CL/LINK expected sets. 113-token A3 baseline is immutable history. Do not manufacture a DLL token CSV until actual tlogs exist. Update the active CI expected-switch reference from *measured, reviewed* outputs, keeping the project files sole build-switch owner.

D. Inspect actual HostX64 CL/link, warning signatures, Release inspector `KERNEL32.dll` imports, DLL release imports (no dynamic VC/UCRT dependency under `/MT`), x64, /GS, CFG, CET, LAA, ASLR, NX, PDB basename, segment heap **EXE only**; verify API4 export `VapourSynthPluginInit2`. Check `VERSIONINFO` in actual DLL; no additional distributed resource file.

E. With locally installed VapourSynth, load DLL in Python and invoke `core.mpeg2deblock.Identity(core.std.BlankClip())`; ensure an output frame is retrievable and the input clip remains valid. No algorithm work. The sample identity invocation is a staging gate, not a shipping API specification.

F. Run **all six** inspector index regressions **locally**, because inspector `.vcxproj` is edited, regardless of whether selected exact compiler happens to be unchanged. O7: no such testing in GitHub Actions. A3 v0.10 waiver remains WAIVED, not a PASS.

G. Existing manual-only GitHub proving workflow will need its two-project token logic/expected data amended and re-proved for the resulting Stage B+ inspector + DLL commands. This candidate DOES NOT modify the current YAML or expected CSV, because their correct values depend on locally measured actual switches. Stage 3 subsequently completes release-triggered one-file workflow and S4-S6; do not accidentally enable release triggers during B+.

## Source/review caveats (candidates for Claude disposition)

- `PlatformToolset=$(DefaultPlatformToolset)` and `VersionLessThan('v###','v145')` are externally documented but **unverified in Dave's VS2026 GUI**. Note Microsoft documentation says selecting the current default toolset does not itself install updates. No explicit `VCToolsVersion` pin is added.
- `/guard:ehcont` may reveal C/C++ linker incompatibility; full build/gate results must distinguish support from mere switch presence. Dave chose to skip a separate O2 experimental campaign, **not** to label the mandatory Stage B+ acceptance regressions PASS if omitted.
- The plugin version has four numeric fields in its one header; its string is generated by macro stringification. `VS_MAKE_VERSION` supports major/minor only for VapourSynth configPlugin, so patch/build components intentionally do not appear there; version header remains canonical.
- `.vcxproj.filters` controls only Solution Explorer grouping, not build semantics. The previously accepted inspector `.filters` is UNCHANGED.
- Candidate exports API4 entrypoint via documented `VS_EXTERNAL_API`, but exact MSVC mangling/export spelling MUST be verified on Windows.
- Review the plugin project for C++ exceptions/RTTI policy, actual `.rc` compilation, build warnings, and CNR3 project differences; the accepted baseline zip does not include the complete CNR3 `.vcxproj`. Claims of 57-row CNR3 reconciliation are NOT made here.
- The original accepted inspector/solution SHA identities were verified from `VapourSynth-mpeg2Deblock-main.zip`, which predates the Step 1/Step 1 gate-document commits but includes the identical accepted project and solution. No assumption is made that the local repo currently has already installed this candidate.

## References

- Living Migration_Status.md v0.5; Claude_RESPONSE_TO_ChatGPT_Agreed_Remaining_Plan_v0_1.md (G2/G9/G10).
- Microsoft: https://learn.microsoft.com/en-us/cpp/build/reference/guard-enable-eh-continuation-metadata
- Microsoft: https://learn.microsoft.com/en-us/visualstudio/msbuild/property-functions
- VapourSynth API4: https://www.vapoursynth.com/doc/api/vapoursynth4.h.html
