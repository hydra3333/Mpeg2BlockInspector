# Stage A A3 Q1 R1 placement scanner fix v0.1

This is a tooling correction only. It is NOT an applyable A3 candidate.

## Defect in prior scanner

`scan_VS2026_rule_properties_v0_2.py` looked only for a direct child named
`DataSource`.

Visual Studio rule XAML normally wraps DataSource elements, for example:

`<Rule.DataSource><DataSource .../></Rule.DataSource>`

and property-level overrides can appear as:

`<BoolProperty.DataSource><DataSource .../></BoolProperty.DataSource>`

Therefore the v0.2 scan found the property names but emitted
`placement=UNSPECIFIED` for nearly every property. The strict validator
correctly rejected those unresolved placements.

## Fix

`scan_VS2026_rule_properties_v0_3.py` now:

- reads DataSource through the XAML `.DataSource` wrapper nodes;
- distinguishes rule-level inherited DataSource from property-level overrides;
- records Persistence, ItemType, Label, HasConfigurationCondition,
  SourceType and effective placement;
- retains toolset folder and exact rule/tool information.

The accompanying strict validator accepts only:

- toolset folder `v180`;
- the correct rule/tool and placement;
- exact property name;
- valid enum or bool value.

## Run from ordinary cmd.exe

Keep `StageA_A3_pin_table_v0_3.csv` in the same directory.

Run:

`python scan_VS2026_rule_properties_v0_3.py --vs-install "C:\Program Files\Microsoft Visual Studio\18\Community"`

Then run:

`python validate_StageA_A3_xml_recognition_v0_3.py --allow-s13-pending`

Return the complete output from both commands.

Do not modify the repository project.
