# A3 v0.10 - Claude final gate review package

Date: 2026-10-10
Status: Candidate evidence for Claude independent review (not ratified close-out)

Read A3_v0_10_FINAL_GATE_SUMMARY_v0_1.md first.
The user's A3_v0_10_CLAUDE_EVIDENCE.zip is copied BYTE-FOR-BYTE into Evidence.
The latest H1-corrected controlling documents are under Documents.
The three Claude document reviews and ChatGPT cold review are under Reviews.

Key decision: Dave waived the v0.10-only six-index rerun; it must NOT be
labelled PASS. The v0.9 six-index regression passed; its raw evidence is
not inside this archive. Please review this exception explicitly.

All newly generated Markdown/text files use ASCII with CRLF endings.
The original evidence ZIP and prior reviewed documents are not edited.
PACKAGE_SHA256.txt lists SHA256 of all other packaged files.
