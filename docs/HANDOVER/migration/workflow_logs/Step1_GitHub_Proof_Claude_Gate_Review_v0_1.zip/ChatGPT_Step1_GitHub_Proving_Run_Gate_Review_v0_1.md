# Step 1 GitHub Actions proving run - independent evidence assessment

**File:** `ChatGPT_Step1_GitHub_Proving_Run_Gate_Review_v0_1.md`  
**Version / date:** v0.1 / 2026-10-10  
**Author:** ChatGPT (migration)  
**Status:** Automated checks PASS; Claude gate review and Dave acceptance pending. This is not Stage B+ authorisation.  
**Reviewed evidence:** `job-logs.txt` (GitHub Actions job log), `stage-a3-project-owned-msbuild-proof.zip` (16 artifacts) and accepted local `A3_v0_10_CLAUDE_EVIDENCE.zip` for comparison. No builds or source audits were repeated.

## 1. Result

**The proving workflow accomplishes Step 1's core objective:** it discovers the released Visual Studio installation, invokes x64 MSBuild against the committed `.slnx` and its `.vcxproj`, rebuilds Debug and Release x64, checks the resulting compiler/linker switches against the accepted 113-token baseline, and validates actual HostX64 invocations and the Release PE requirements. All programmed checks report PASS and the artifact was successfully uploaded.

**This is not a claim that the GitHub-built EXE has byte-identical code or PE structure to Dave's local Stage A3 EXE.** The binary captures have material layout differences. They are documented below for Claude's evaluation. There is no newly executed six-index regression in this evidence.

## 2. Identity and build result

| Item | Result / evidence |
|---|---|
| Repo/commit | `hydra3333/VapourSynth-mpeg2Deblock` at `bf2412593e0dd3a93f7b1f0d958e596f9b9abdf5` |
| Actions run | `https://github.com/hydra3333/VapourSynth-mpeg2Deblock/actions/runs/38034308907` |
| Runner | Windows Server 2025; image `windows-2025-vs2026`, version `20260925.250.1` |
| VS | Visual Studio Enterprise 2026, released channel, installation `18.10.12217.157` (local Stage A: Community) |
| MSBuild | `18.10.1.42706`; selected from `...\18\Enterprise\MSBuild\Current\Bin\amd64\MSBuild.exe`; separate live project probe prints `MSBUILD_IS64=True` |
| MSVC | `v145`, tools directory `14.51.36231`, actual compiler and linker under `HostX64\x64`; CL file version `19.51.36260.0`, LINK and DUMPBIN file version `14.51.36260.0` |
| Windows SDK | Runner selects `10.0.26100.0`; Dave's Stage A3 local build selected `10.0.28000.0` |
| Build result | Debug and Release build succeeded, each 17 warnings and zero errors |
| Diagnostic signatures | The 17 unique warnings in each runner build match the accepted local A3 v0.10 captures by code, C filename, line, column **and complete message**; legacy unchanged: C4013 x8, C4101 x1, C4996 x8 |
| Uploaded artifact | 16 files, original artifact `stage-a3-project-owned-msbuild-proof.zip`; ZIP CRC integrity PASS |

The checked-out commit is the accepted `main` commit. A detached HEAD inside `actions/checkout` when pinning a commit hash is normal and **does not create a development branch**.

## 3. Switch and isolation gates

| Configuration | Tool | Actual / accepted tokens | Outcome |
|---|---|---:|---|
| Debug x64 | CL | 33 / 33 | PASS |
| Debug x64 | LINK | 23 / 23 | PASS |
| Release x64 | CL | 32 / 32 | PASS |
| Release x64 | LINK | 25 / 25 | PASS |

I independently parsed the attached `actual_switches.csv` and compared it against the accepted local Stage A3 CSV using the agreed `(configuration, tool, ordinal)` keys. **All 113 tokens match**, with CL case-sensitive and LINK case-insensitive as reviewed. Raw CSV files are **not byte-identical** because the groups are emitted in a different order and `/manifestinput:` is lowercase on the runner while `/MANIFESTINPUT:` is uppercase in the reference. These are not missing or additional effective switches. Neither build has `/LTCGOUT`; Release retains `/GL`, `/LTCG`, `/MT`, AVX2, CFG, CET and basename-only PDB path.

The log records successful environment/implicit-input isolation, approved single-installation `vswhere` discovery, actual x64 MSBuild process, and 1 CL plus 1 LINK invocation line per configuration from the selected `HostX64\x64` tool directory. Only project-defined compiler/linker settings were used; no handwritten execution flag map.

## 4. Release PE and binary checks

The workflow's dumpbin/manifest checks PASS: x64 PE32+, LAA, HEVA, ASLR, NX, CFG, CET, TSA, nonzero security cookie, CFG table and recognized flags, basename-only RSDS PDB name, `KERNEL32.dll` as the only imported DLL/dependency, and embedded `asInvoker` / `SegmentHeap` manifest.

**Local Stage A3 versus GitHub Actions output (both Debug/Release switch sets match):**

| Release PE fact | Local A3 v0.10 | Actions runner |
|---|---:|---:|
| Code size (PE `/headers`, hex) | `28C00` | `28800` |
| Initialized data size (hex) | `16E00` | `16A00` |
| `.text` virtual size (hex) | `28B00` | `28760` |
| `.rdata` virtual size (hex) | `D494` | `D1DC` |
| Entry-point RVA | `EDE0` | `EDE0` |
| Guard CF function count | `37` | `37` |
| Guard Flags | `10017500` | `10017500` |
| Imported DLLs | `KERNEL32.dll` only | `KERNEL32.dll` only |
| Imported KERNEL32 API names | 81, same order | 81, same order |
| Embedded manifest text | Identical | Identical |

Further structural differences include the exception-directory size and some load-configuration table entries/addresses. Thus the Release binaries are not structurally identical even though the same MSVC tools directory and CL/LINK switch sets were used. The different selected SDK (`10.0.28000.0` vs `10.0.26100.0`), different machine environments and possibly static runtime libraries are plausible contributors; **cause has not been isolated** and no claim of identical machine code can be made. The executable binaries themselves were not included in this proof artifact, so they cannot be byte-compared.

**Disposition proposed:** The difference does not invalidate the Step 1 goal (prove project-file-owned CI builds and effective settings). It is useful evidence that same switches/compiler do not guarantee binary identity across hosts/SDKs. Ask Claude whether additional requirements should be carried into the final Release gate; do not invent an automatic exemption or a new mandatory six-index rule without Dave's decision.

## 5. Observations, non-blocking

- Filenames `MSBuild_*_x64_diagnostic.log` are historical names: the actual file logging is `Verbosity=detailed` (the reviewed S2 fix).
- The Actions cleanup prints Node.js 20 deprecation notices for `actions/checkout@v4` and `actions/upload-artifact@v4`; these are action-maintenance warnings, not MSVC build warnings and did not affect PASS.
- The original GitHub artifact and job log are provided unchanged to support an independent Claude gate review.
- The accepted Stage A3 six-index status stays **WAIVED for A3 v0.10, NOT PASS**. This workflow test is not a replacement functional regression.

## 6. Recommendation and next step

**Recommend Claude accept Step 1's proving-workflow gate** based on the complete execution evidence, with the code/data/SDK differences acknowledged. Do not automatically progress to Stage B+ until Claude has reviewed the run and Dave has accepted the Step 1 gate. Retain the decisions to require all six indexes for the upcoming inspector `.vcxproj` change in Stage B+ and on future toolset/exact compiler changes. No automatic update of the expected-switch reference is justified by this run: all 113 reviewed switches PASS.

Then update only the living `Migration_Status.md` at the agreed process checkpoint (P1). Do not initiate another five-document version cascade or redesign the workflow on the basis of this successful proof.
