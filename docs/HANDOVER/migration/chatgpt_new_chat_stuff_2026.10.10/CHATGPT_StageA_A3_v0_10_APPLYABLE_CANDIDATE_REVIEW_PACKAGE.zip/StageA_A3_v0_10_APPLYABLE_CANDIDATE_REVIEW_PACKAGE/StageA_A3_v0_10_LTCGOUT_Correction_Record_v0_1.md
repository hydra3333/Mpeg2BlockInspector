# Stage A A3 v0.10 LTCGOUT Correction Record

**Filename:** `StageA_A3_v0_10_LTCGOUT_Correction_Record_v0_1.md`
**Version:** 0.1
**Date:** 2026-10-10
**Status:** Candidate-review record. Production remains on applied v0.9 until Claude accepts and Dave ratifies v0.10.

## Finding

Mechanical W1 reconciliation of applied v0.9 found `/LTCGOUT:<...Mpeg2BlockInspector.iobj>` as the only unpredicted token in both Debug and Release LINK lines. All CL reconciliation passed exactly.

The checkpoint contained no `/LTCGOUT`. The v0.9 project had no explicit `LinkTimeCodeGenerationObjectFile`; VS2026 v180 supplied a default `.iobj` path and the Link task emitted `/LTCGOUT` once `LinkTimeCodeGeneration` was explicitly written.

## Proven correction

Scratch experiment B added exactly:

```xml
<LinkTimeCodeGenerationObjectFile />
```

after each Debug and Release `LinkTimeCodeGeneration` setting. Debug and Release both built successfully; `/LTCGOUT:` was absent from both actual linker lines; Release retained plain `/LTCG`.

Claude cold review `Claude_REVIEW_OF_ChatGPT_StageA_A3_W1_LTCGOUT_and_v0_10_Proposal_v0_1.md` agreed with the two-line correction and required X1 pin ownership plus X2 full-gate rerun.

## Candidate

`Mpeg2BlockInspector_A3_APPLYABLE_CANDIDATE_v0_10.vcxproj`

SHA-256: `73e9019cda7d1061ecdb06526c60f4ee84baa4c385b7ca0dde4269544e4fdb46`

Relative to ratified/applied v0.9, the project diff is exactly two added self-closing `LinkTimeCodeGenerationObjectFile` elements and no removals or other changes.

## X1 ownership

Pin table v0.9 adds `LD_ltcgout` and `LR_ltcgout`, both targeting `Link/LinkTimeCodeGenerationObjectFile=`. The value is intentionally empty. Recognition must treat an explicit empty Link StringProperty as a valid value, not as a missing pin. Expected counts: 143 pin rows, 140 candidate pin applications, 134 strict XML targets.

## X2 post-ratification gate

After Claude accepts and Dave ratifies the exact v0.10 SHA, run a clean `/t:Rebuild` for Debug and Release and repeat the full A3 gate. W1 checker remains byte-unchanged. Required W1 counts remain Debug CL 33, Release CL 32, Debug LINK 23, Release LINK 25. S15 timing need not be repeated.

After clean rebuild, also check for stray untracked `*.iobj` and `*.ipdb`.

## Carry-forward

Stage B plugin: use the same explicit empty pin under the present non-incremental-LTCG policy. Stage C/D command-line checks: reject unexpected `/LTCGOUT:`. Revisit only if `/LTCG:INCREMENTAL` is deliberately adopted.
