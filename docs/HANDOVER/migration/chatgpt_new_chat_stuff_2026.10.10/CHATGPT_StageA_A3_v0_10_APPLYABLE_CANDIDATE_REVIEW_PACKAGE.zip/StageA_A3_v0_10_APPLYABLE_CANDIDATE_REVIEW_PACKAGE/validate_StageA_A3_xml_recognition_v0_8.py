#!/usr/bin/env python3
import argparse, csv, re
from collections import defaultdict

def die(msg):
    print("FAIL:", msg)
    raise SystemExit(1)

ap = argparse.ArgumentParser(
    description="Strict A3 XML recognition validator: v180 + rule/tool + exact name + enum/bool value + evidence-backed MSBuild placement."
)
ap.add_argument("--pin-table", default="StageA_A3_pin_table_v0_9.csv")
ap.add_argument("--rule-scan", default="StageA_A3_VS_rule_properties_generated_v0_3.csv")
ap.add_argument("--toolset-folder", default="v180")
ap.add_argument("--allow-s13-pending", action="store_true")
args = ap.parse_args()

rows = list(csv.DictReader(open(args.pin_table, newline="", encoding="ascii")))
rules = list(csv.DictReader(open(args.rule_scan, newline="", encoding="utf-8")))

rules = [r for r in rules if r["toolset_folder"].lower() == args.toolset_folder.lower()]
if not rules:
    die(f"no rule rows for required toolset folder {args.toolset_folder}")

index = defaultdict(list)
for r in rules:
    index[r["property_name"]].append(r)

def placement_ok(group, r):
    if group == "ClCompile":
        return r["rule_name"] == "CL" and r["item_type"].lower() == "clcompile"
    if group == "Link":
        return r["rule_name"] == "Link" and r["item_type"].lower() == "link"
    if group == "Manifest":
        return r["item_type"].lower() == "manifest" and r["rule_file"].lower().replace("/", "\\").endswith("\\mt.xml")
    if group == "Configuration":
        # Configuration-scoped project properties are persisted in a
        # configuration-conditioned PropertyGroup. The installed v180 rules
        # show two accepted forms: Label=Configuration, or property-level
        # Persistence=ProjectFile with HasConfigurationCondition=true.
        # Item metadata is never accepted here.
        if r["item_type"]:
            return False
        if r["label"].lower() == "configuration":
            return True
        return (
            r["persistence"].lower() == "projectfile"
            and r["has_configuration_condition"].lower() == "true"
        )
    return False

unresolved = []
checked = 0

for row in rows:
    kind = row["coverage_kind"]

    if kind == "S13_PENDING":
        if not args.allow_s13_pending:
            unresolved.append((row["key"], row["xml_or_exception"], "S13_PENDING remains"))
        continue

    if kind != "XML":
        continue

    spec = row["xml_or_exception"]
    parts = re.split(r";\s*(?=[A-Za-z]+/)", spec)

    for part in parts:
        if "/" not in part:
            unresolved.append((row["key"], part, "no Group/Property form"))
            continue

        group, rest = part.split("/", 1)
        group = group.strip()

        if " includes " in rest:
            prop, value = rest.split(" includes ", 1)
            mode = "includes"
        elif "=" in rest:
            prop, value = rest.split("=", 1)
            mode = "equals"
        else:
            prop, value, mode = rest, None, "exists"

        prop = prop.strip()
        value = value.strip() if value is not None else None

        candidates = [r for r in index.get(prop, []) if placement_ok(group, r)]

        if not candidates:
            seen = index.get(prop, [])
            details = "; ".join(
                f"{r['rule_name']}@{r['placement']}:{r['property_type']}[{r['datasource_scope']}]"
                for r in seen[:12]
            ) or "property absent"
            unresolved.append((
                row["key"], part,
                f"no {args.toolset_folder} match for required {group} placement; seen {details}"
            ))
            continue

        value_ok = False
        reasons = []

        for r in candidates:
            ptype = r["property_type"]
            enums = [v for v in r["enum_values"].split(";") if v]

            if mode in ("exists", "includes"):
                value_ok = True
                break

            if ptype == "EnumProperty":
                if value in enums:
                    value_ok = True
                    break
                reasons.append(f"enum={enums}")
            elif ptype == "BoolProperty":
                if value.lower() in ("true", "false"):
                    value_ok = True
                    break
                reasons.append("bool requires true/false")
            else:
                # For String/StringList/Int, rule XML proves recognition and
                # placement; the exact evaluated build value is proved elsewhere.
                # Explicit empty value is valid only for a recognized StringProperty.
                if value == "" and ptype != "StringProperty":
                    reasons.append(f"empty value requires StringProperty, got {ptype}")
                    continue
                value_ok = True
                break

        if not value_ok:
            unresolved.append((
                row["key"], part,
                f"value {value!r} invalid for matched property ({'; '.join(reasons)})"
            ))
            continue

        checked += 1

if unresolved:
    for key, spec, why in unresolved:
        print("UNRESOLVED:", key, spec, why, sep=" | ")
    die(f"{len(unresolved)} strict XML recognition/placement items unresolved")

print(
    f"PASS: {checked} XML pin targets recognized in {args.toolset_folder} "
    "with correct rule/tool, exact property name, enum/bool value and DataSource placement."
)
