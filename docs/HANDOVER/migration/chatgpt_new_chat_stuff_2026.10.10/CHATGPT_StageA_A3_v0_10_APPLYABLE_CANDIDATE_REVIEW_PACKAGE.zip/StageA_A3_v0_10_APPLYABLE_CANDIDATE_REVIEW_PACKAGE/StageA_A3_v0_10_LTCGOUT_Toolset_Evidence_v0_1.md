# Stage A A3 v0.10 LTCGOUT Toolset Evidence

**Filename:** `StageA_A3_v0_10_LTCGOUT_Toolset_Evidence_v0_1.md`
**Version:** 0.1
**Date:** 2026-10-10
**Source:** Dave's installed Visual Studio 2026 v180 files and command output.
**Status:** Evidence/provenance for the v0.10 correction; not repository product authority.

## Installed v180 evidence

`Microsoft.Cpp.Common.props:259` imports `Microsoft.Link.Common.props`.

`Microsoft.Link.Common.props:63` contains:

```xml
<LinkTimeCodeGenerationObjectFile Condition="'%(Link.LinkTimeCodeGenerationObjectFile)' == ''">$(IntDir)$(TargetName).iobj</LinkTimeCodeGenerationObjectFile>
```

The condition does not mention `LinkTimeCodeGeneration`.

`v180\1033\link.xml:914-919` identifies `LinkTimeCodeGenerationObjectFile` as the Link Time Code Generation Object File StringProperty; line 918 maps it to `Switch="LTCGOUT:"`.

`Microsoft.CppCommon.targets:1253-1254` passes:

```text
LinkTimeCodeGeneration           = "%(Link.LinkTimeCodeGeneration)"
LinkTimeCodeGenerationObjectFile = "%(Link.LinkTimeCodeGenerationObjectFile)"
```

to the Link task. Corresponding handoffs also occur later in the same targets file.

The installed props/targets search found `LinkTimeCodeGeneration` setters/tests in PGO/WPO/use-dynamic-debugging files and `Microsoft.CppCommon.targets`, including `Microsoft.Cpp.WholeProgramOptimization.props:24-26` and `Microsoft.CppCommon.targets:1140`. It did not expose a props/targets condition tying the line-63 `.iobj` default itself to `LinkTimeCodeGeneration`.

## Measured boundary

- Preserved A1/checkpoint LINK tlogs: no `/LTCGOUT` in Debug or Release.
- A1 project: neither `LinkTimeCodeGeneration` nor `LinkTimeCodeGenerationObjectFile` is explicitly written.
- Applied v0.9: explicit Debug `LinkTimeCodeGeneration=Default` and Release `UseLinkTimeCodeGeneration`; `/LTCGOUT` appears in both linker lines.
- Scratch A: remove only Debug `LinkTimeCodeGeneration=Default`; Debug builds and `/LTCGOUT` disappears.
- Scratch B: restore v0.9 and add explicit empty `LinkTimeCodeGenerationObjectFile` in both configurations; both build, `/LTCGOUT` is absent from both, and Release retains plain `/LTCG`.

## Safe conclusion

The explicit `LinkTimeCodeGeneration` setting changes Link-task command-line emission behavior for the separately defaulted object-file property on this installed toolset. The visible props default does not encode that relationship. Record the empirical behavior; do not invent an unseen MSBuild condition.
