# Stage A A3 v0.10 - APPLYABLE CANDIDATE FOR COLD REVIEW

**Status:** Candidate is byte-copy applyable only after Claude cold review and Dave ratification. **DO NOT APPLY YET.**

**Candidate:** `Mpeg2BlockInspector_A3_APPLYABLE_CANDIDATE_v0_10.vcxproj`
**Candidate SHA-256:** `73e9019cda7d1061ecdb06526c60f4ee84baa4c385b7ca0dde4269544e4fdb46`
**A1 baseline SHA-256:** `87acd9ad1c94e5545f84fe57857c076781ca499523d2a80545919ae571dc7a57`
**Ratified/applied v0.9 SHA-256:** `ebfcde82405fd2dc25aa7a14a160f89375465d545927b3e4583e7a40fd1af668`

## v0.9 -> v0.10 project change

Exactly two lines are added, one per configuration: `<LinkTimeCodeGenerationObjectFile />`. They immediately follow the existing Debug `LinkTimeCodeGeneration=Default` and Release `LinkTimeCodeGeneration=UseLinkTimeCodeGeneration` elements. No v0.9 project line is removed or otherwise changed.

## Claude X1

Pin table `StageA_A3_pin_table_v0_9.csv` adds `LD_ltcgout` and `LR_ltcgout`, both XML-owned by `Link/LinkTimeCodeGenerationObjectFile=`. The structure validator expects the explicit empty elements, and strict XML recognition v0.8 treats an empty value as valid only for a recognized StringProperty. Expected local counts are 140 candidate pin applications, 143 structural pin rows, and 134 strict XML targets.

The preserved checkpoint tlog-to-pin reconciliation remains 82 native tokens + 4 detailed-log-only rows = 86 because the two new W1-correction rows are not checkpoint CL/LINK rows.

## Claude X2

After ratification/application, rerun the full A3 gate from clean `/t:Rebuild` Debug and Release builds. W1 checker is unchanged. W2 raw PE evidence, imports, D6, six indexes, warning counts and frozen-source hashes must be regenerated/confirmed. S15 timing does not need repeating. Check for stray untracked `*.iobj` / `*.ipdb` after the rebuild.

## X3/X4/X5

The corrected causal wording, general cross-property-emission lesson, incremental-LTCG caveat, Stage B carry-forward and Stage C/D no-`/LTCGOUT` check are recorded in `StageA_VS2026_MSBuild_Hard_Earned_Knowledge_v0_3.md` and `StageA_A3_v0_10_LTCGOUT_Correction_Record_v0_1.md`.

## Review boundary

Before Dave may ratify: local generated rule/token/reconciliation CSVs must be copied unchanged into this package; all local validators must PASS; Claude must verify the v0.9 -> v0.10 project diff is exactly two added lines, re-run strict recognition, and review X1/X3-X5 evidence. Only after Dave ratifies the exact candidate SHA may it be byte-copied over the production project.
