#!/usr/bin/env python3
import argparse,csv,re,xml.etree.ElementTree as ET
def die(m): print('FAIL:',m); raise SystemExit(1)
ap=argparse.ArgumentParser()
ap.add_argument('--project',default='Mpeg2BlockInspector_A3_APPLYABLE_CANDIDATE_v0_10.vcxproj')
ap.add_argument('--pin-table',default='StageA_A3_pin_table_v0_9.csv')
a=ap.parse_args()

NS='http://schemas.microsoft.com/developer/msbuild/2003'
Q=lambda n:f'{{{NS}}}{n}'
tree=ET.parse(a.project); root=tree.getroot()
top=list(root)

# x64-only configurations.
pc=[x.attrib.get('Include','') for x in root.findall(f'.//{Q("ProjectConfiguration")}')]
if pc != ['Debug|x64','Release|x64']:
    die(f'project configurations are not exact x64-only pair: {pc!r}')
xml_text=open(a.project,encoding='ascii').read()
# Historical <Keyword>Win32Proj</Keyword> is retained from the project template
# and is not a build platform. Reject actual Win32 configuration/condition use.
for e in root.iter():
    for av in e.attrib.values():
        if 'Win32' in av:
            die(f'Win32 configuration/condition remains: {av}')

# Import position for configuration-labelled properties (Claude T1).
cpp_props_idx=None
for i,e in enumerate(top):
    if e.tag==Q('Import') and e.attrib.get('Project','').endswith('Microsoft.Cpp.props'):
        cpp_props_idx=i; break
if cpp_props_idx is None: die('Microsoft.Cpp.props import not found')

cfg_groups={}
for i,e in enumerate(top):
    if e.tag==Q('PropertyGroup') and e.attrib.get('Label')=='Configuration':
        c=e.attrib.get('Condition','')
        if 'Debug|x64' in c: cfg_groups['Debug|x64']=(i,e)
        elif 'Release|x64' in c: cfg_groups['Release|x64']=(i,e)
for cfg in ('Debug|x64','Release|x64'):
    if cfg not in cfg_groups: die(f'missing Label=Configuration group: {cfg}')
    idx,e=cfg_groups[cfg]
    if idx >= cpp_props_idx:
        die(f'{cfg} Label=Configuration group occurs after Microsoft.Cpp.props')
    expected={
        'Debug|x64':{
            'CharacterSet':'NotSet','SpectreMitigation':'false',
            'PreferredToolArchitecture':'x64','WholeProgramOptimization':'false'},
        'Release|x64':{
            'CharacterSet':'NotSet','SpectreMitigation':'false',
            'PreferredToolArchitecture':'x64','WholeProgramOptimization':'true'},
    }[cfg]
    for n,v in expected.items():
        x=e.find(Q(n))
        if x is None or (x.text or '')!=v: die(f'{cfg} configuration {n} expected {v!r}')

# T2: both Configuration and ClCompile WPO explicit.
def idg(cfg):
    for e in root.findall(Q('ItemDefinitionGroup')):
        if cfg in e.attrib.get('Condition',''): return e
    return None
for cfg,val in [('Debug|x64','false'),('Release|x64','true')]:
    g=idg(cfg)
    if g is None: die(f'missing ItemDefinitionGroup {cfg}')
    cc=g.find(Q('ClCompile'))
    if cc is None: die(f'missing ClCompile {cfg}')
    w=cc.find(Q('WholeProgramOptimization'))
    if w is None or (w.text or '')!=val: die(f'{cfg} ClCompile WholeProgramOptimization expected {val}')

# Conditioned PropertyGroup placements from v180 DataSource.
for cfg in ('Debug|x64','Release|x64'):
    found=None
    for e in root.findall(Q('PropertyGroup')):
        if cfg in e.attrib.get('Condition','') and e.attrib.get('Label')!='Configuration':
            if all(e.find(Q(n)) is not None for n in ('LinkIncremental','GenerateManifest','LinkControlFlowGuard')):
                found=e; break
    if found is None: die(f'missing conditioned linker PropertyGroup pins for {cfg}')
    vals={'LinkIncremental':'false','GenerateManifest':'true','LinkControlFlowGuard':'true'}
    for n,v in vals.items():
        if (found.find(Q(n)).text or '')!=v: die(f'{cfg} {n} expected {v}')

# No invented HighEntropyVA property.
if root.find(f'.//{Q("HighEntropyVA")}') is not None:
    die('invented HighEntropyVA XML element present')

# Source/header membership must equal frozen A1 list.
expected_c=[
'..\\..\\src\\Mpeg2BlockInspector\\display.c','..\\..\\src\\Mpeg2BlockInspector\\getbits.c',
'..\\..\\src\\Mpeg2BlockInspector\\getblk.c','..\\..\\src\\Mpeg2BlockInspector\\gethdr.c',
'..\\..\\src\\Mpeg2BlockInspector\\getpic.c','..\\..\\src\\Mpeg2BlockInspector\\getvlc.c',
'..\\..\\src\\Mpeg2BlockInspector\\idct.c','..\\..\\src\\Mpeg2BlockInspector\\idctref.c',
'..\\..\\src\\Mpeg2BlockInspector\\motion.c','..\\..\\src\\Mpeg2BlockInspector\\mpeg2dec.c',
'..\\..\\src\\Mpeg2BlockInspector\\recon.c','..\\..\\src\\Mpeg2BlockInspector\\spatscal.c',
'..\\..\\src\\Mpeg2BlockInspector\\store.c','..\\..\\src\\Mpeg2BlockInspector\\subspic.c',
'..\\..\\src\\Mpeg2BlockInspector\\systems.c','..\\..\\src\\Mpeg2BlockInspector\\verify.c']
expected_h=[
'..\\..\\src\\Mpeg2BlockInspector\\config.h','..\\..\\src\\Mpeg2BlockInspector\\getvlc.h',
'..\\..\\src\\Mpeg2BlockInspector\\global.h','..\\..\\src\\Mpeg2BlockInspector\\mpeg2dec.h']
got_c=[e.attrib['Include'] for e in root.findall(f'.//{Q("ClCompile")}[@Include]')]
got_h=[e.attrib['Include'] for e in root.findall(f'.//{Q("ClInclude")}[@Include]')]
if got_c!=expected_c: die('frozen C source membership/order changed')
if got_h!=expected_h: die('frozen header membership/order changed')

# Apply every XML/AdditionalOptions pin against candidate.
rows=list(csv.DictReader(open(a.pin_table,newline='',encoding='ascii')))
def tool_elem(cfg,group):
    g=idg(cfg)
    if g is None:return None
    return g.find(Q(group))
def config_values(cfg,prop):
    vals=[]
    for e in root.findall(Q('PropertyGroup')):
        if cfg in e.attrib.get('Condition',''):
            x=e.find(Q(prop))
            if x is not None: vals.append((x.text or '',e.attrib.get('Label','')))
    return vals
def split_specs(s):
    return re.split(r';\s*(?=[A-Za-z]+/)',s)
checked=0
for r in rows:
    kind=r['coverage_kind']
    if kind not in ('XML','ADDITIONAL_OPTIONS'): continue
    cfg=r['configuration']; spec=r['xml_or_exception']
    for part in split_specs(spec):
        if kind=='ADDITIONAL_OPTIONS':
            # Accept either "Group/AdditionalOptions includes X" or bare D6 prose.
            if 'AdditionalOptions' not in part:
                continue
        if '/' not in part: continue
        group,rest=part.split('/',1); group=group.strip()
        if ' includes ' in rest:
            prop,val=rest.split(' includes ',1); mode='includes'
        elif '=' in rest:
            prop,val=rest.split('=',1); mode='equals'
        else:
            prop,val,mode=rest,None,'exists'
        prop=prop.strip(); val=val.strip() if val is not None else None

        if group=='Configuration':
            matches=config_values(cfg,prop)
            if not matches: die(f'{r["key"]}: missing Configuration/{prop}')
            if mode=='equals' and not any(v==val for v,l in matches):
                die(f'{r["key"]}: Configuration/{prop} does not equal {val!r}: {matches!r}')
        elif group in ('ClCompile','Link','Manifest'):
            te=tool_elem(cfg,group)
            if te is None: die(f'{r["key"]}: missing {group} block')
            x=te.find(Q(prop))
            if x is None: die(f'{r["key"]}: missing {group}/{prop}')
            actual=x.text or ''
            if val=='<checkpoint segmentheap manifest>':
                ok=('$(VCToolsInstallDir)' in actual and actual.lower().endswith(r'include\manifest\segmentheap.manifest'))
            elif mode=='includes':
                # %(AdditionalOptions) may be included in the stated pin; check each
                # non-inheritance token independently.
                toks=[t for t in val.split() if t!='%(AdditionalOptions)']
                ok=all(t in actual for t in toks)
            elif mode=='equals':
                ok=(actual==val)
            else: ok=True
            if not ok: die(f'{r["key"]}: {group}/{prop} actual {actual!r}, expected {mode} {val!r}')
        checked+=1

# Exact explicit tool-setting maps: candidate should not drift silently.
expected_cl = {
    'Debug|x64': {
      'PreprocessorDefinitions':'_CRT_SECURE_NO_WARNINGS;%(PreprocessorDefinitions)',
      'SuppressStartupBanner':'true','WarningLevel':'Level3','TreatWarningAsError':'false',
      'DiagnosticsFormat':'Column','ExternalWarningLevel':'Level3','UseFullPaths':'true',
      'SDLCheck':'false','ControlFlowGuard':'Guard','PrecompiledHeader':'NotUsing',
      'Optimization':'Disabled','FavorSizeOrSpeed':'Speed','InlineFunctionExpansion':'AnySuitable',
      'IntrinsicFunctions':'true','FunctionLevelLinking':'false','StringPooling':'false',
      'WholeProgramOptimization':'false','DebugInformationFormat':'ProgramDatabase',
      'FloatingPointModel':'Precise','RuntimeLibrary':'MultiThreadedDebugDLL',
      'BufferSecurityCheck':'true','BasicRuntimeChecks':'EnableFastChecks','SupportJustMyCode':'true',
      'CompileAs':'CompileAsC','LanguageStandard_C':'Default',
      'EnableEnhancedInstructionSet':'AdvancedVectorExtensions2','ExceptionHandling':'Sync',
      'CallingConvention':'Cdecl','MinimalRebuild':'false','TreatWChar_tAsBuiltInType':'true',
      'ForceConformanceInForLoopScope':'true','RemoveUnreferencedCodeData':'true',
      'ObjectFileName':'$(IntDir)','ProgramDataBaseFileName':'$(IntDir)vc$(PlatformToolsetVersion).pdb',
      'ErrorReporting':'Queue','AdditionalOptions':'/favor:blend %(AdditionalOptions)',
    },
    'Release|x64': {
      'PreprocessorDefinitions':'_CRT_SECURE_NO_WARNINGS;%(PreprocessorDefinitions)',
      'SuppressStartupBanner':'true','WarningLevel':'Level3','TreatWarningAsError':'false',
      'DiagnosticsFormat':'Column','ExternalWarningLevel':'Level3','UseFullPaths':'true',
      'SDLCheck':'false','ControlFlowGuard':'Guard','PrecompiledHeader':'NotUsing',
      'Optimization':'MaxSpeed','FavorSizeOrSpeed':'Speed','InlineFunctionExpansion':'AnySuitable',
      'IntrinsicFunctions':'true','FunctionLevelLinking':'true','StringPooling':'true',
      'WholeProgramOptimization':'true','DebugInformationFormat':'ProgramDatabase',
      'FloatingPointModel':'Precise','RuntimeLibrary':'MultiThreaded',
      'BufferSecurityCheck':'true','BasicRuntimeChecks':'Default','SupportJustMyCode':'false',
      'CompileAs':'CompileAsC','LanguageStandard_C':'Default',
      'EnableEnhancedInstructionSet':'AdvancedVectorExtensions2','ExceptionHandling':'Sync',
      'CallingConvention':'Cdecl','MinimalRebuild':'false','TreatWChar_tAsBuiltInType':'true',
      'ForceConformanceInForLoopScope':'true','RemoveUnreferencedCodeData':'true',
      'ObjectFileName':'$(IntDir)','ProgramDataBaseFileName':'$(IntDir)vc$(PlatformToolsetVersion).pdb',
      'ErrorReporting':'Queue','AdditionalOptions':'/favor:blend %(AdditionalOptions)',
    },
}
expected_link = {
    'Debug|x64': {
      'LinkErrorReporting':'QueueForNextLogin','SuppressStartupBanner':'true',
      'ManifestEmbed':'true',
      'GenerateDebugInformation':'DebugFull','ProgramDatabaseFile':'$(OutDir)$(TargetName).pdb',
      'SubSystem':'Console','OutputFile':'$(OutDir)$(TargetName)$(TargetExt)',
      'LinkTimeCodeGeneration':'Default','LinkTimeCodeGenerationObjectFile':'','OptimizeReferences':'false','EnableCOMDATFolding':'false',
      'EnableUAC':'true','UACExecutionLevel':'AsInvoker','UACUIAccess':'false',
      'RandomizedBaseAddress':'true','DataExecutionPrevention':'true','LargeAddressAware':'true',
      'TerminalServerAware':'true','TargetMachine':'MachineX64','TypeLibraryResourceID':'1',
      'ImportLibrary':'$(OutDir)$(TargetName).lib','CETCompat':'true',
      'AdditionalOptions':'/HIGHENTROPYVA %(AdditionalOptions)',
    },
    'Release|x64': {
      'LinkErrorReporting':'QueueForNextLogin','SuppressStartupBanner':'true',
      'ManifestEmbed':'true',
      'GenerateDebugInformation':'DebugFull','ProgramDatabaseFile':'$(OutDir)$(TargetName).pdb',
      'SubSystem':'Console','OutputFile':'$(OutDir)$(TargetName)$(TargetExt)',
      'LinkTimeCodeGeneration':'UseLinkTimeCodeGeneration','LinkTimeCodeGenerationObjectFile':'','OptimizeReferences':'true',
      'EnableCOMDATFolding':'true','EnableUAC':'true','UACExecutionLevel':'AsInvoker',
      'UACUIAccess':'false','RandomizedBaseAddress':'true','DataExecutionPrevention':'true',
      'LargeAddressAware':'true','TerminalServerAware':'true','TargetMachine':'MachineX64',
      'TypeLibraryResourceID':'1','ImportLibrary':'$(OutDir)$(TargetName).lib','CETCompat':'true',
      'AdditionalOptions':'/HIGHENTROPYVA /PDBALTPATH:%_PDB% %(AdditionalOptions)',
    },
}
for cfg in ('Debug|x64','Release|x64'):
    g=idg(cfg)
    man=g.find(Q('Manifest'))
    if man is None or man.find(Q('EnableSegmentHeap')) is None or (man.find(Q('EnableSegmentHeap')).text or '')!='true':
        die(f'{cfg}: EnableSegmentHeap=true not retained')
    lk=g.find(Q('Link'))
    if lk is not None and lk.find(Q('ManifestInput')) is not None:
        die(f'{cfg}: duplicate segment-heap owner: Link/ManifestInput must be absent')
    for group, expected in [('ClCompile',expected_cl[cfg]),('Link',expected_link[cfg])]:
        te=g.find(Q(group))
        actual={child.tag.rsplit('}',1)[-1]:(child.text or '') for child in list(te)}
        if actual != expected:
            missing={k:v for k,v in expected.items() if actual.get(k)!=v}
            extra={k:v for k,v in actual.items() if k not in expected}
            die(f'{cfg} {group} exact map mismatch; differing={missing!r}; extra={extra!r}')

# Hard policy guards.
for cfg in ('Debug|x64','Release|x64'):
    cc=tool_elem(cfg,'ClCompile'); lk=tool_elem(cfg,'Link')
    if (cc.find(Q('EnableEnhancedInstructionSet')).text or '')!='AdvancedVectorExtensions2':
        die(f'{cfg}: AVX2 not explicit')
    if (cc.find(Q('BufferSecurityCheck')).text or '')!='true': die(f'{cfg}: /GS not explicit')
    if (cc.find(Q('ControlFlowGuard')).text or '')!='Guard': die(f'{cfg}: compiler CFG not explicit')
    if (lk.find(Q('CETCompat')).text or '')!='true': die(f'{cfg}: CET not explicit')
    if '/HIGHENTROPYVA' not in (lk.find(Q('AdditionalOptions')).text or ''):
        die(f'{cfg}: explicit /HIGHENTROPYVA absent')
    if '/favor:blend' not in (cc.find(Q('AdditionalOptions')).text or ''):
        die(f'{cfg}: /favor:blend absent')
    if '/Qspectre' in xml_text: die('/Qspectre text present')

rel=tool_elem('Release|x64','ClCompile')
if (rel.find(Q('RuntimeLibrary')).text or '')!='MultiThreaded': die('Release /MT not explicit')
rel_l=tool_elem('Release|x64','Link')
if '/PDBALTPATH:%_PDB%' not in (rel_l.find(Q('AdditionalOptions')).text or ''):
    die('Release /PDBALTPATH:%_PDB% absent')

print(f'PASS: candidate structure, T1 import position, T2 dual WPO pins, frozen membership and {checked} pin applications verified.')
