# Local evidence files intentionally absent from initial download

These three files were generated on Dave's VS2026 machine and already checked during v0.9 candidate review. ChatGPT does not recreate them:

- StageA_A3_VS_rule_properties_generated_v0_3.csv
- StageA_A3_checkpoint_tokens_generated_v0_4.csv
- StageA_A3_tlog_pin_reconciliation_generated_v0_1.csv

Run `ASSEMBLE_AND_VALIDATE_A3_v0_10_FOR_CLAUDE.bat` after extraction as a sibling under the existing `A3_v0_7_PRE_CANDIDATE` evidence tree. It copies the unchanged local originals, runs the v0.10 validators, and creates the READY zip only after all checks pass.
