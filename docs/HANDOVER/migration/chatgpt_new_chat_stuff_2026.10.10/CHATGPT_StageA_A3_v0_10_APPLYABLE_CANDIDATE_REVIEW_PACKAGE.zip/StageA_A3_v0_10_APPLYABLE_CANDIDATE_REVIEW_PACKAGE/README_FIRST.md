# Stage A A3 v0.10 - LTCGOUT CORRECTIVE CANDIDATE REVIEW PACKAGE

**DO NOT APPLY YET. Production remains on applied v0.9 until Claude accepts and Dave ratifies this exact candidate.**

Candidate: `Mpeg2BlockInspector_A3_APPLYABLE_CANDIDATE_v0_10.vcxproj`
SHA-256: `73e9019cda7d1061ecdb06526c60f4ee84baa4c385b7ca0dde4269544e4fdb46`

Relative to v0.9, the project diff is exactly two added `<LinkTimeCodeGenerationObjectFile />` lines and no removals. The existing Debug `Default` and Release `UseLinkTimeCodeGeneration` pins remain unchanged.

Expected local validator counts: structure 140 pin applications; pin table 143 rows; strict v180 recognition 134 targets; CNR3 113 rows; tlog evidence 82 tokens; tlog-pin reconciliation 82+4=86.

Extract this package as a sibling under the existing `A3_v0_7_PRE_CANDIDATE` tree and run `ASSEMBLE_AND_VALIDATE_A3_v0_10_FOR_CLAUDE.bat`. No production repository file is changed. Send the resulting exact READY ZIP to Claude.

The candidate is not authorized for production application until Claude cold-reviews it and Dave ratifies its exact SHA-256.

The exact ratified v0.9 candidate is retained as `Mpeg2BlockInspector_A3_APPLYABLE_CANDIDATE_v0_9.vcxproj` (SHA-256 `ebfcde82405fd2dc25aa7a14a160f89375465d545927b3e4583e7a40fd1af668`) so Claude can independently verify that the v0.9 -> v0.10 project diff is exactly two added empty `LinkTimeCodeGenerationObjectFile` elements.
