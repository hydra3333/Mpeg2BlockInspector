# Stage A A3 v0.10 - Predicted CL/LINK delta

**Candidate SHA-256:** `73e9019cda7d1061ecdb06526c60f4ee84baa4c385b7ca0dde4269544e4fdb46`
**A1 SHA-256:** `87acd9ad1c94e5545f84fe57857c076781ca499523d2a80545919ae571dc7a57`

This is a prediction for review. The post-application tlogs and dumpbin outputs are authoritative. Any unexplained delta stops the gate.

## Tool host

Both Debug and Release:

```text
HostX86\x64 -> HostX64\x64
```

Target architecture remains x64.

## Debug CL

Measured checkpoint behavior retained unless listed below.

Deliberate/pinned changes:

```text
/ZI -> /Zi
add /Oi
add /Ot
add /Ob2
add /arch:AVX2
add /guard:cf
add /favor:blend
add /Gy-
add /GF-
```

The candidate explicitly preserves `/MDd`, `/GS`, `/RTC1`, `/JMC`, `/Od`, `/fp:precise`, compile-as-C, warning/diagnostic switches, `/Zc:inline`, `/Fd`, and other measured behavior.

`/Qspectre` must remain absent. `/fp:contract` must remain absent.

## Release CL

Deliberate/pinned changes:

```text
/MD -> /MT
add /GL
add /arch:AVX2
add /guard:cf
add /favor:blend
```

The `/O2` component settings `/Oi /Ot /Ob2 /GF /Gy` are explicitly represented in the project. Their exact emitted spelling/order is verified from the post-A3 tlog.

`/Qspectre` must remain absent. `/fp:contract` must remain absent.

## Debug LINK

Deliberate/pinned changes:

```text
/DEBUG -> /DEBUG:FULL
add /GUARD:CF
add /CETCOMPAT
add explicit /HIGHENTROPYVA
add /OPT:NOREF
add /OPT:NOICF
add /LARGEADDRESSAWARE
add /TSAWARE
```

The candidate explicitly pins `LinkTimeCodeGenerationObjectFile` empty, so `/LTCGOUT:` must be absent. It also explicitly preserves `/INCREMENTAL:NO`, `/MANIFEST`, `asInvoker`, `uiAccess=false`, `/manifest:embed`, the segment-heap manifest input, `/PDB`, `/SUBSYSTEM:CONSOLE`, `/TLBID:1`, `/DYNAMICBASE`, `/NXCOMPAT`, `/IMPLIB`, `/MACHINE:X64`, Large Address Aware, Terminal Server Aware, and Debug no-REF/no-ICF semantics.

`Manifest/EnableSegmentHeap=true` is the single project owner of the segment-heap input. The post-A3 tlog must show exactly one effective `/manifestinput:` entry resolving to `segmentheap.manifest`. Any duplication is a stop condition.

## Release LINK

Deliberate/pinned changes:

```text
/DEBUG -> /DEBUG:FULL
add /LTCG
add /GUARD:CF
add /CETCOMPAT
add explicit /HIGHENTROPYVA
add /PDBALTPATH:%_PDB%
add /LARGEADDRESSAWARE
add /TSAWARE
```

Release retains `/OPT:REF` and `/OPT:ICF`. `LinkTimeCodeGeneration=UseLinkTimeCodeGeneration` still emits plain `/LTCG`, while explicit empty `LinkTimeCodeGenerationObjectFile` requires `/LTCGOUT:` to be absent.

## Default libraries

The measured default list remains deliberately unpinned as `AdditionalDependencies`:

```text
kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib
shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib
```

Reason: unreferenced libraries cannot reach the image. The Release standalone import gate, which allows only `KERNEL32.dll`, proves the shipped outcome.

## Release standalone dependency gate

The Release binary must contain none of:

```text
VCRUNTIME*
MSVCP*
api-ms-win-crt-*
ucrtbase*
CONCRT*
VCOMP*
MSVCR1*
```

Expected allowed Release dependency set:

```text
KERNEL32.dll
```

Any additional DLL stops the gate.

## PE/security gate

Post-A3 `dumpbin /headers /loadconfig /imports /dependents` must prove:

- x64 PE32+;
- Large Address Aware;
- High Entropy VA;
- Dynamic Base / ASLR;
- NX / DEP;
- full CFG image state, including non-zero Guard CF function table/count;
- CET compatible;
- security cookie retained;
- manifest present;
- Release CodeView PDB entry contains file name only under D6.

The project setting alone is not proof.

## Explicit default-enum non-emission

The following values are explicitly pinned but are expected to emit no switch of their own:

```text
Debug LINK: LinkTimeCodeGeneration=Default (no switch of its own)
Release CL: BasicRuntimeChecks=Default
```

The post-A3 tlogs are authoritative. In v0.10, `/LTCGOUT:` must be absent from both Debug and Release. The explicit empty `LinkTimeCodeGenerationObjectFile` pin suppresses the VS2026 toolset default `.iobj` path while preserving Release plain `/LTCG`. If `/LTCGOUT:` or any other unexpected switch appears, stop and reconcile it rather than treating it as harmless noise.

## Claude v0.8 U2 provenance

The newly listed `/Gy-`, `/GF-`, `/OPT:NOREF`, `/OPT:NOICF`, `/LARGEADDRESSAWARE`, and `/TSAWARE` spellings were derived by Claude from the installed v180 rule XML. They make existing intended behavior explicit; they are not newly adopted product behavior.


## v0.10 W1 correction provenance

W1 on applied v0.9 found `/LTCGOUT:<...Mpeg2BlockInspector.iobj>` as the only unpredicted token in each LINK line. Installed VS2026 v180 evidence showed:

- `Microsoft.Cpp.Common.props:259` imports `Microsoft.Link.Common.props`;
- `Microsoft.Link.Common.props:63` supplies `$(IntDir)$(TargetName).iobj` when `%(Link.LinkTimeCodeGenerationObjectFile)` is empty;
- `v180\1033\link.xml:914-919` defines `LinkTimeCodeGenerationObjectFile` as a Link `StringProperty` with `Switch="LTCGOUT:"`;
- `Microsoft.CppCommon.targets:1253-1254` passes `LinkTimeCodeGeneration` and `LinkTimeCodeGenerationObjectFile` to the Link task.

The line-63 default condition itself is not conditioned on `LinkTimeCodeGeneration`. A search of the installed v180 props/targets found `LinkTimeCodeGeneration` setters/tests elsewhere (including `Microsoft.Cpp.WholeProgramOptimization.props:24-26` and `Microsoft.CppCommon.targets:1140`) but no visible props/targets condition that explains `/LTCGOUT` emission. Controlled scratch tests proved that explicitly pinning `LinkTimeCodeGenerationObjectFile` empty suppresses `/LTCGOUT:` in both configurations while Release retains plain `/LTCG`.

The precise emission/suppression rule is therefore attributed only to measured Link-task command-line generation. Do not claim a nonexistent MSBuild condition.

If `/LTCG:INCREMENTAL` is ever adopted, revisit the empty object-file pin.
