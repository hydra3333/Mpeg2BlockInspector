#!/usr/bin/env python3
import argparse,csv,os
from pathlib import Path
import xml.etree.ElementTree as ET

def local(tag): return tag.rsplit('}',1)[-1]

a=argparse.ArgumentParser(description='Scan installed VS/MSBuild Visual C++ rule XML for recognized property names and enum values.')
a.add_argument('--vs-install',required=True)
a.add_argument('--out',default='StageA_A3_VS_rule_properties_generated.csv')
x=a.parse_args()
root=Path(x.vs_install)/'MSBuild'/'Microsoft'/'VC'
if not root.is_dir(): raise SystemExit(f'FAIL: VC MSBuild rule root not found: {root}')
rows=[]
for p in root.rglob('*.xml'):
    try: tree=ET.parse(p)
    except Exception: continue
    rr=tree.getroot(); rule_name=rr.attrib.get('Name','') if local(rr.tag)=='Rule' else ''
    for e in rr.iter():
        ln=local(e.tag)
        if not ln.endswith('Property') or 'Name' not in e.attrib: continue
        name=e.attrib['Name']; vals=[]
        for c in e:
            if local(c.tag)=='EnumValue' and c.attrib.get('Name'): vals.append(c.attrib['Name'])
        rows.append({'rule_file':str(p),'rule_name':rule_name,'property_type':ln,'property_name':name,'enum_values':';'.join(vals)})
if not rows: raise SystemExit('FAIL: no property definitions found in rule XML')
with open(x.out,'w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n'); w.writeheader(); w.writerows(rows)
print(f'PASS: wrote {len(rows)} recognized property definitions from {root} to {x.out}')
