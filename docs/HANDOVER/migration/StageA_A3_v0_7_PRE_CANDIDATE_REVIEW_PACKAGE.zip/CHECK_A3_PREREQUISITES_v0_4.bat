@echo off
setlocal EnableExtensions

echo ============================================================
echo Stage A A3 v0.7 prerequisite check
echo ============================================================

rem Q3: deliberately derive MSBuild under the VS installation selected by vswhere.
rem Do not use an independent -find lookup for Stage A.
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
  echo FAIL: vswhere.exe not found: "%VSWHERE%"
  exit /b 1
)
set "VSINSTALL="
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.Component.MSBuild Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSINSTALL=%%i"
if not defined VSINSTALL (
  echo FAIL: no Visual Studio installation satisfies MSBuild + x64/x86 C++ tools.
  exit /b 1
)
set "MSBUILD=%VSINSTALL%\MSBuild\Current\Bin\MSBuild.exe"
if not exist "%MSBUILD%" (
  echo FAIL: expected MSBuild.exe not found under selected VS installation.
  echo VSINSTALL=%VSINSTALL%
  echo MSBUILD=%MSBUILD%
  exit /b 1
)
echo VSINSTALL=%VSINSTALL%
echo MSBUILD=%MSBUILD%
echo PASS: same-installation MSBuild derivation.
echo Spectre policy: project setting explicitly Disabled; /Qspectre absent.
echo Required retained hardening: /GS, CFG, CET.
echo Required CPU target: /arch:AVX2.
echo /favor:blend: explicit in Debug and Release.
echo.
echo NEXT: run scan_VS2026_rule_properties_v0_1.py and S13 capture.
exit /b 0
