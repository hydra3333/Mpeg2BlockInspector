#!/usr/bin/env python3
import argparse,csv
P='StageA_A3_pin_table_v0_2.csv'
REQ=['key','source','configuration','item','checkpoint_value','a3_value','coverage_kind','xml_or_exception','evidence_source','notes']
KINDS={'XML','ADDITIONAL_OPTIONS','DELIBERATE_CHANGE','DELIBERATE_EXCEPTION','TOOL_SEMANTIC','S13_PENDING'}
def die(m): print('FAIL:',m); raise SystemExit(1)
a=argparse.ArgumentParser(); a.add_argument('--allow-s13-pending',action='store_true'); x=a.parse_args()
with open(P,newline='',encoding='ascii') as f:
    rr=csv.DictReader(f); rows=list(rr)
    if rr.fieldnames!=REQ: die(f'columns={rr.fieldnames!r}')
keys=[r['key'] for r in rows]
if len(keys)!=len(set(keys)): die('duplicate pin-table keys')
for r in rows:
    for c in REQ[:-1]:
        if not r[c].strip(): die(f'blank {c} for {r["key"]}')
    if r['coverage_kind'] not in KINDS: die(f'bad coverage_kind {r["key"]}: {r["coverage_kind"]}')
    if r['coverage_kind']=='S13_PENDING' and not x.allow_s13_pending: die(f'S13_PENDING remains: {r["key"]}')
print(f'PASS: {len(rows)} structural pin rows; no duplicate keys/blanks; '+('S13_PENDING allowed for pre-candidate.' if x.allow_s13_pending else 'no S13_PENDING rows.'))
