#!/usr/bin/env python3
import argparse,csv,re
from collections import defaultdict

def die(s): print('FAIL:',s); raise SystemExit(1)
a=argparse.ArgumentParser()
a.add_argument('--pin-table',default='StageA_A3_pin_table_v0_2.csv')
a.add_argument('--rule-scan',default='StageA_A3_VS_rule_properties_generated.csv')
a.add_argument('--allow-local-evidence-pending',action='store_true')
x=a.parse_args()
rows=list(csv.DictReader(open(x.pin_table,newline='',encoding='ascii')))
try: rules=list(csv.DictReader(open(x.rule_scan,newline='',encoding='utf-8')))
except FileNotFoundError:
    if x.allow_local_evidence_pending:
        print('PASS-PRE-CANDIDATE: rule scan not present; local Q1 evidence pending.'); raise SystemExit(0)
    die('rule-scan evidence missing')
props=defaultdict(list)
for r in rules: props[r['property_name']].append(r)
unresolved=[]
for r in rows:
    if r['coverage_kind']!='XML': continue
    spec=r['xml_or_exception']
    # multiple targets may be separated by '; Link/' etc.
    parts=re.split(r';\s*(?=[A-Za-z]+/)',spec)
    for part in parts:
        if '/' not in part: unresolved.append((r['key'],part,'no Group/Property form')); continue
        grp,rest=part.split('/',1)
        if ' includes ' in rest: prop,val=rest.split(' includes ',1); enum=None
        elif '=' in rest: prop,val=rest.split('=',1); enum=val.strip()
        else: prop=rest.strip(); enum=None
        prop=prop.strip()
        matches=props.get(prop,[])
        if not matches:
            unresolved.append((r['key'],part,'property not found in installed rule XML; resolve by S13'))
            continue
        # Only enforce enum spelling when rule declares EnumValue names. Bool/string/macro values need property recognition only.
        enums=set()
        for m in matches:
            enums.update(v for v in m['enum_values'].split(';') if v)
        if enums and enum is not None and enum not in enums:
            unresolved.append((r['key'],part,f'enum value {enum!r} not in installed rule values {sorted(enums)}; resolve by S13'))
if unresolved:
    for u in unresolved: print('UNRESOLVED:',*u,sep=' | ')
    if not x.allow_local_evidence_pending: die(f'{len(unresolved)} XML recognition items unresolved')
    print(f'PASS-PRE-CANDIDATE: {len(unresolved)} XML items require S13/local resolution.')
else:
    print('PASS: every XML property/enum used by the pin table is recognized by installed rule XML.')
