# Stage A A3 v0.7 - PRE-CANDIDATE Requirements

**Status:** REVIEW / LOCAL-EVIDENCE only. No applyable `.vcxproj` is included.

## Ratified direction

- x64 only; `/arch:AVX2` Debug+Release.
- `/favor:blend` explicit Debug+Release.
- Debug `/MDd`; Release `/MT`; Release `/PDBALTPATH:%_PDB%`.
- `/GS`, CFG and CET ON Debug+Release.
- Spectre mitigation explicitly Disabled Debug+Release; `/Qspectre` absent.
- inspector `/sdl` OFF; plugin later `/sdl` ON.
- `/fp:precise`; `/fp:contract` absent.

## Q1 - final remaining MUST

The final candidate must prove two independent things mechanically:

1. **XML recognition.** Every property name and enumeration value used by an `XML` pin row is recognized by the installed VS2026/MSBuild rule XML or was written by VS2026 in the S13 scratch capture. Unknown metadata is not accepted merely because MSBuild ignores it quietly.
2. **Measured command coverage.** The expected CL/LINK evidence comes from the four byte-copied checkpoint command tlogs. The hand-written expected-key file from v0.6 is retired. The default Windows library list is part of the measured LINK evidence and is represented in the v0.2 pin table as a deliberate exception plus command/import gates.

The final candidate is blocked until recognition, tlog coverage and S13 all pass with no waiver.

## Local sequence

1. Run `CHECK_A3_PREREQUISITES_v0_4.bat`.
2. Run `scan_VS2026_rule_properties_v0_1.py --vs-install "<VSINSTALL>"`.
3. Run the S13 v0.3 scratch capture; resolve every unrecognized/pending property/value empirically.
4. Run `extract_StageA_A3_checkpoint_tlog_tokens_v0_1.py` against the four preserved checkpoint command tlogs.
5. Run the structural, recognition, tlog-evidence and CNR3 reconciliation validators.
6. Return all generated CSVs plus S13 BASE/WORK/diff.
7. Only then may ChatGPT generate an applyable A3 `.vcxproj`.

## P3/P4/S14/S15

The previous exact dumpbin criteria, strict 113-row reconciliation, `/fp:contract` absence and LP timing requirements remain unchanged.
