#!/usr/bin/env python3
import argparse,csv,ctypes,os,re,shlex
from pathlib import Path

def decode(p):
    b=Path(p).read_bytes()
    if b.startswith(b'\xff\xfe'): return b[2:].decode('utf-16le','replace')
    if b.startswith(b'\xfe\xff'): return b[2:].decode('utf-16be','replace')
    if b[:200].count(0)>20: return b.decode('utf-16le','replace')
    for e in ('utf-8','cp1252'):
        try:return b.decode(e)
        except UnicodeDecodeError: pass
    return b.decode('latin1','replace')

def argv_win(s):
    if os.name!='nt': return shlex.split(s,posix=False)
    n=ctypes.c_int(); p=ctypes.windll.shell32.CommandLineToArgvW(s,ctypes.byref(n))
    if not p: raise OSError('CommandLineToArgvW failed')
    try:return [p[i] for i in range(n.value)]
    finally:ctypes.windll.kernel32.LocalFree(p)

def command_line(path,exe):
    lines=[l.strip().lstrip('\ufeff') for l in decode(path).splitlines() if l.strip() and not l.startswith('^')]
    c=[l for l in lines if exe.lower() in l.lower()]
    if not c: raise SystemExit(f'FAIL: no {exe} command line found in {path}')
    return max(c,key=len)

def norm(tool,args):
    out=[]; libs=[]; i=0
    while i<len(args):
        a=args[i].strip('"')
        lo=a.lower()
        if lo.endswith(('cl.exe','link.exe')): i+=1; continue
        if tool=='CL' and lo=='/d' and i+1<len(args): out.append('/D '+args[i+1].strip('"')); i+=2; continue
        if tool=='LINK' and lo.endswith('.lib'): libs.append(a.lower()); i+=1; continue
        if lo.endswith(('.c','.cpp','.obj','.res')) or ('\\' in a and not a.startswith('/')): i+=1; continue
        repl=None
        for pfx in ['/fo','/fd','/out:','/pdb:','/implib:','/manifestinput:']:
            if lo.startswith(pfx): repl=pfx.upper().replace('/FO','/Fo').replace('/FD','/Fd')+'<PATH>'; break
        if repl: out.append(repl)
        else: out.append(a)
        i+=1
    if libs: out.insert(next((j for j,v in enumerate(out) if v.upper()=='/MANIFEST'),len(out)), 'LIBS='+';'.join(libs))
    return out

a=argparse.ArgumentParser()
for n in ('debug_cl','release_cl','debug_link','release_link'): a.add_argument('--'+n.replace('_','-'),required=True)
a.add_argument('--out',default='StageA_A3_checkpoint_tokens_generated.csv')
x=a.parse_args(); jobs=[('Debug|x64','CL',x.debug_cl,'cl.exe'),('Release|x64','CL',x.release_cl,'cl.exe'),('Debug|x64','LINK',x.debug_link,'link.exe'),('Release|x64','LINK',x.release_link,'link.exe')]
rows=[]
for cfg,tool,path,exe in jobs:
    args=argv_win(command_line(path,exe))
    for j,t in enumerate(norm(tool,args),1): rows.append({'configuration':cfg,'tool':tool,'ordinal':j,'token':t})
with open(x.out,'w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=['configuration','tool','ordinal','token'],lineterminator='\n'); w.writeheader();w.writerows(rows)
print(f'PASS: wrote {len(rows)} measured checkpoint command tokens to {x.out}')
