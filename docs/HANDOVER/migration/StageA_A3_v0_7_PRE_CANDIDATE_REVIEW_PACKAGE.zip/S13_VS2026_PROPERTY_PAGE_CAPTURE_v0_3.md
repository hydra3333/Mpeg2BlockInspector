# S13 - VS2026 Property Pages Capture v0.2

Do this on a **scratch copy** of the current A1/A2 `Mpeg2BlockInspector.vcxproj`. Do not edit the live repository project.

1. Make byte-identical scratch copies: `BASE` and `WORK`.
2. Open `WORK` in Visual Studio 2026.
3. For Debug|x64 and Release|x64 as applicable, set through Property Pages:
   - Control Flow Guard = enabled;
   - CET / shadow-stack compatibility = enabled;
   - Spectre mitigation = **Disabled** (N1; explicit no-defaults pin);
   - Full-PDB/debug-information behaviour intended by A3;
   - any other pin-table row marked `S13_PENDING`.
4. Save and close Visual Studio.
5. Produce an exact BASE -> WORK diff.
6. Return BASE, WORK and diff to migration ChatGPT/Claude.

Rules:

- use exactly the XML VS2026 writes where a dedicated element exists;
- do not hand-invent an XML element;
- use `AdditionalOptions` only where VS2026 supplies no dedicated stable element and document why;
- Spectre is explicitly Disabled, not merely omitted; `/Qspectre` must remain absent;
- this scratch experiment is evidence only and is never committed.


## Q1 extension - rule recognition

Before changing the scratch project, run `scan_VS2026_rule_properties_v0_1.py --vs-install "<VSINSTALL>"`. Then run `validate_StageA_A3_xml_recognition_v0_1.py --allow-local-evidence-pending`. Any XML property/value that the installed rule files do not recognize must be added to the empirical Property Pages capture below. Do not infer a property merely from its command-line spelling.

Return the generated rule-scan CSV with BASE, WORK and the diff. The final candidate validator will require every XML target to be recognized either by this scan or by explicit S13 evidence.
