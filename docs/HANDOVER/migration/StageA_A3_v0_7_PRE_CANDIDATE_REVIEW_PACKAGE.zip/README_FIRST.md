# Stage A A3 v0.7 PRE-CANDIDATE review package

This package is NOT APPLYABLE. It contains no proposed `.vcxproj`.

Purpose: close Claude Q1 before the final A3 candidate exists. It adds:

- installed-VS rule-file recognition scanning for XML property names/enum values;
- S13 v0.3 instructions for anything not mechanically recognized;
- checkpoint command-tlog token extraction;
- explicit default-library-list coverage;
- structural pin-table v0.2 validation without a hand-written expected-key authority;
- DR v0.15 / Plan v0.10 / Handback v0.9 / ChatGPT migration handover v0.6.

The final A3 package must pass all local evidence checks without `allow`/pending switches.
