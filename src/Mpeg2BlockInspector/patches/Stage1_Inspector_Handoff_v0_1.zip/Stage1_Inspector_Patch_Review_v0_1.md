# Stage 1 Inspector Patch Review

**Filename:** `Stage1_Inspector_Patch_Review_v0_1.md`
**Version:** 0.1
**Date:** 2026-10-06
**Author:** ChatGPT
**Status:** Implementation handoff / pre-user-run evidence.
**Design authority for this patch:** `Stage1_Inspector_Instrumentation_Design_v0_3.md`

## 1. Result

The Stage 1 v0.1 implementation has been applied to the pristine reference decoder.

Mechanical comparison against `REFERENCE-mpeg2dec-src.zip` confirms that exactly two original
source/header files differ:

```text
getpic.c
mpeg2dec.c
```

All other original `.c` and `.h` files are byte-identical to the pristine reference source.

The edited C files retain the pristine LF line endings. No whole-file CRLF conversion or source
reformatting was performed.

## 2. Implemented design

The patch implements the reviewed Stage 1 design, including:

- metadata slots mirroring forward-reference, backward-reference and B/auxiliary frame buffers;
- record emission at the three existing `Write_Frame()` call sites;
- independent output-emission ordinal;
- FRAME/FIELD/NONE semantics based on applicable coded residual transform geometry;
- effective derived quantiser scale plus macroblock-QUANT update diagnostic;
- effective coded block pattern;
- raw motion diagnostics normalised later in Python;
- matrix-in-effect diagnostics derived from matrix-array comparisons;
- exactly-once per-picture macroblock coverage as the primary validity gate;
- MPEG-1, scalable/two-stream, non-4:2:0 and field-picture rejection for temporary format v1;
- invalidation on incompatible mid-sequence geometry/chroma changes;
- safe `.s1tmp` write then rename-on-success publication;
- Windows `-b -` stdin support and new `-m <metadata-file>` option;
- no binary metadata on stdout.

## 3. Local compile checks

The complete modified source tree compiles under GCC in GNU89 mode.

No new compile error was observed. Warnings are predominantly existing warnings from the old
reference decoder. The patched `mpeg2dec.c` additionally has the pre-existing-style local `ret`
set-but-not-used warning in `main`; it is not a functional failure.

A second build used:

```text
-fsanitize=address,undefined
```

Both supplied test samples completed with exit code 0 and no sanitizer diagnostic.

This is useful implementation evidence but does not replace the required Windows / Visual Studio
build on Dave's system.

## 4. Local sample runs

Both supplied MPEG program streams were demultiplexed to MPEG-2 elementary video with ffmpeg and
piped into the patched decoder.

### TEST_4A_A003.mpg

```text
Stage 1 records:       300
Dimensions:            720x576
Macroblock grid:       45x36
Picture structures:    300 FRAME, 0 field pictures
I / P / B:             26 / 76 / 198
FRAME MBs:             94,741  (19.49%)
FIELD MBs:            333,986  (68.72%)
NONE MBs:              57,273  (11.78%)
Mixed FRAME/FIELD:     299/300 frames
Effective QP:          min 2, max 36, mean 14.455, median 14
Custom intra matrix:   0 frames
Custom non-intra:      300 frames
```

### TEST_4A_A003_blocky.mpg

```text
Stage 1 records:       300
Dimensions:            720x576
Macroblock grid:       45x36
Picture structures:    300 FRAME, 0 field pictures
I / P / B:             26 / 75 / 199
FRAME MBs:             56,235  (11.57%)
FIELD MBs:             35,243  (7.25%)
NONE MBs:             394,522  (81.18%)
Mixed FRAME/FIELD:     300/300 frames
Effective QP:          62 for every MB in this sample
Custom intra matrix:   0 frames
Custom non-intra:      0 frames
```

These are Stage 1 evidence observations, not yet repository knowledge or deblocking conclusions.

## 5. Analyzer self-checks

`Stage1_Inspector_Analyzer_v0_1.py` parsed both generated index files as valid.

The validation includes the v0.3 duplicated/cross-field rules, including:

- quantiser-inherited flag agrees with `macroblock_quant_update`;
- prediction-derived flag agrees with `motion_source`;
- SKIPPED -> NONE;
- SKIPPED has no macroblock QUANT update and no dct_type-read flag;
- inherited motion occurs only for skipped B macroblocks;
- no-motion source has zero direction bits;
- dct_type-read is restricted to the proper frame-picture context;
- FIELD requires a real dct_type-read context;
- non-intra CBP zero -> NONE;
- all macroblock positions valid exactly once;
- record and file reserved fields are zero;
- output ordinals are contiguous.

No validation failure occurred on either sample.

## 6. Independent frame-count observation

`ffprobe -count_frames` reports 300 video frames for each supplied MPG, matching the inspector's
300 records.

This is encouraging only. It is **not** the required BestSource correspondence gate.

Dave must still obtain the BestSource/VapourSynth `num_frames` for each test sample and require:

```text
inspector record count == BestSource frame count
```

A mismatch blocks Stage 1 interpretation until explained.

## 7. Files supplied

- `getpic.c` - patched pristine source
- `mpeg2dec.c` - patched pristine source
- `Stage1_Inspector_Source_Patch_v0_1.diff` - unified diff against pristine
- `Stage1_Inspector_Analyzer_v0_1.py` - temporary-index validator/analyzer
- `Stage1_Inspector_Instrumentation_Design_v0_3.md` - approved working design
- `Stage1_Inspector_Patch_Review_v0_1.md` - this review

## 8. Windows run sequence

Build the patched source in the existing Visual Studio project/environment. No project-file change
is intended by this patch.

For the original test sample, the intended command shape is:

```bat
"C:\SOFTWARE\ffmpeg\ffmpeg.exe" -v error -i "TEST_4A_A003.mpg" -c:v copy -an -f mpeg2video - | Mpeg2BlockInspector.exe -b - -m "TEST_4A_A003.stage1.idx"
```

For the blockier sample:

```bat
"C:\SOFTWARE\ffmpeg\ffmpeg.exe" -v error -i "TEST_4A_A003_blocky.mpg" -c:v copy -an -f mpeg2video - | Mpeg2BlockInspector.exe -b - -m "TEST_4A_A003_blocky.stage1.idx"
```

Then validate:

```bat
python Stage1_Inspector_Analyzer_v0_1.py summary "TEST_4A_A003.stage1.idx" --expected-frames <BESTSOURCE_FRAME_COUNT>
python Stage1_Inspector_Analyzer_v0_1.py summary "TEST_4A_A003_blocky.stage1.idx" --expected-frames <BESTSOURCE_FRAME_COUNT>
```

Compare the two:

```bat
python Stage1_Inspector_Analyzer_v0_1.py compare "TEST_4A_A003.stage1.idx" "TEST_4A_A003_blocky.stage1.idx"
```

Useful inspection commands:

```bat
python Stage1_Inspector_Analyzer_v0_1.py frame "TEST_4A_A003.stage1.idx" 0
python Stage1_Inspector_Analyzer_v0_1.py mb "TEST_4A_A003.stage1.idx" 0 0 0
python Stage1_Inspector_Analyzer_v0_1.py dump-frame "TEST_4A_A003.stage1.idx" 0
```

## 9. Acceptance before deeper analysis

Do not treat the Stage 1 statistics as accepted project evidence until Dave has confirmed:

1. Visual Studio build succeeds from the patched pristine source;
2. both sample runs exit successfully and publish the final index rather than leaving `.s1tmp`;
3. analyzer validation passes for both;
4. BestSource frame count equals inspector record count for both.

After those four checks, the next step is to inspect/analyse the real metadata distributions and
decide what they imply for the Stage 2 experiment.
